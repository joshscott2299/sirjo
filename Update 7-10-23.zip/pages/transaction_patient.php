<?php 
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];	

include('../dist/includes/dbcon.php');

	date_default_timezone_set('Asia/Manila');
	$dates = $_POST['dates'];
	$cid = $_POST['cid'];
	$qty_ward_id = $_POST['qty_ward_id'];
	$qty = $_POST['qty'];
	$issue = "Patient";
	$issues = "Patient";
		
		$query=mysqli_query($con,
			"select * 
			from qty_ward 
			where qty_ward_id='$qty_ward_id'") 
			or die(mysqli_error($con));

		$row=mysqli_fetch_array($query);
		$price=$row['price'];
		$desc=$row['item'];
		$stock=$row['reorder'];
		$code=$row['serial'];
		$category=$row['cat_id'];
		$remain=$row['qty'];
		$sup=$row['supplier_id'];
		$current=$row['qty'];
		$unit=$row['unit_id'];
		$batch=$row['batch'];
		$pr=$row['pr'] ?? 0;
		$po=$row['po'] ?? 0;
		$iar=$row['iar'] ?? 0;
		$item=$row['item'];
		$expiry=$row['expiry'] ?? 'NA';
		// kaloy 2022-07-08
		$prod_id = $row['prod_id']; // actual product_id

		if(intval($qty) > intval($current)) {
			echo "<script>
            alert('Enter quantity lesser than or equal to $current');
            document.location = 'patient_issue.php';           
			</script>";
			die();
		}

		$query3=mysqli_query($con,"select temp_id,branch_to from temp_dept where temp_id='$issue'") 
			or die(mysqli_error($con));
		$row=mysqli_fetch_array($query3);
		// $to=$row['branch_id'];
		
		
		// $query1=mysqli_query($con,
		// 	"select * from temp_trans_patient_phar 
		// 	where prod_id='$qty_ward_id' and branch_id_from='$branch' and e_user='$id'") 
		// 	or die(mysqli_error($con));
		// $count=mysqli_num_rows($query1);

		$query1=mysqli_query($con,
			"select * from temp_trans_patient_phar 
			where temp_trans_id='$qty_ward_id' and branch_id_from='$branch' and e_user='$id'") 
			or die(mysqli_error($con));
		$count=mysqli_num_rows($query1);
		
		$total=$price*$qty;


     if ($qty == 0 )
  {
    ?>
            <script type="text/javascript">
            alert("Enter quantity greater than 0!");
            window.location = "patient_issue.php";           
            </script>
            
<?php
  }
		
	else if ($count>0){
			mysqli_query($con,"update temp_trans_patient_phar set qty=qty+'$qty', initial_qty=initial_qty+'$qty' where temp_trans_id='$qty_ward_id' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error($con));
			mysqli_query($con,"UPDATE qty_ward SET qty=qty-'$qty' where qty_ward_id='$qty_ward_id' and branch_id='$branch'") or die(mysqli_error($con)); 	

			// mysqli_query($con,"update temp_trans_patient_phar set qty=qty+'$qty', initial_qty=initial_qty+'$qty' where prod_id='$prod_id' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error($con));
		}
		else{
			mysqli_query($con,"UPDATE qty_ward SET qty=qty-'$qty' where qty_ward_id='$qty_ward_id' and branch_id='$branch'") or die(mysqli_error($con)); 
			mysqli_query($con,"INSERT INTO temp_trans_patient_phar(temp_trans_id,prod_id,qty,price,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,rec_qty,branch_receive) VALUES('$qty_ward_id',$prod_id,'$qty','$price','$branch','$desc','$issue','$code','$stock','$category','$qty','$dates','$sup','$current','$id','$issues','$unit','$batch','$pr','$po','$iar','$expiry','$item','$current','$branch')")or die(mysqli_error($con));

			// mysqli_query($con,"INSERT INTO temp_trans_patient_phar(prod_id,qty,price,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,rec_qty,branch_receive) VALUES('$prod_id)','$qty','$price','$branch','$desc','$issue','$code','$stock','$category','$qty','$dates','$sup','$current','$id','$issues','$unit','$batch','$pr','$po','$iar','$expiry','$item','$current','$branch')")or die(mysqli_error($con));
		}
	
		echo "<script>document.location='patient_issue.php?cid=$cid'</script>";  
	
?>