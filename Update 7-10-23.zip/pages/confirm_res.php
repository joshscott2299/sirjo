<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<?php

	include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	$id=$_SESSION['id'];
	
	$rid=$_GET['id'];
	
	$riscode=$_POST['riscode'];
	
	$h=mysqli_query($con,"select * from branch where branch_id='$branch'");
	$jo=mysqli_fetch_array($h);
	$deps=$jo['branch_name'];
	
	$a=mysqli_query($con,"select * from request_itemmacro where requestid='$rid' and branch_id_to='$branch'");
	$b=mysqli_fetch_array($a);
	
	if ($b['ris_code']!=$riscode){
	?>
		<script>
			window.alert('RIS No. did not much!');
			window.history.back();
		</script>
	<?php
	}
	else{
	
	$c=mysqli_query($con,"select * from request_detailmacro where requestid='$rid'");
	$arr=array();
	
	while($d=mysqli_fetch_array($c)){
		$arr[]=$d['detail_id'];
	}
	
	foreach($arr as $resid):
		$e=mysqli_query($con,"select * from request_detailmacro where detail_id='$resid'");
		$f=mysqli_fetch_array($e);
		$item=$f['stock_name'];
		$req=$f['request_qty'];
		$me=$f['branch_refer'];
		$car=$f['temp_trans_id'];
		$tos=$f['branch_id_tos'];
		
		$b=mysqli_query($con,"select * from qty_general where item='$item'");
		$j=mysqli_fetch_array($b);
		$una=$j['ID'];
		$stock=$j['item'];
		$serial=$j['serial'];
		$price=$j['price'];
		$cat=$j['cat_id'];
		$bar=$j['barcode'];
		$desc=$j['description'];
		$unit=$j['unit_id'];
		$reorder=$j['reorder'];
		$supp=$j['supplier_id'];
		$remain=$j['qty'];
		
		$c=mysqli_query($con,"select * from branch where branch_id='$me'");
		$d=mysqli_fetch_array($c);
		$depart=$d['branch_name'];
		
		
		mysqli_query($con,"update qty_general set qty=qty - '$req' where item='$item' and branch_id='$branch'");
		mysqli_query($con,"update product_dept set qty=qty + '$req', initial_qty=initial_qty+'$req' where product_name='$item' and branch_id_to='$me'");
		
		mysqli_query($con,"INSERT INTO issue_item_supply(prod_id,price,qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,product_name,ris,rec_qty,branch_receive)
			VALUES('$una','$price','$req','$tos','$desc','$me','$serial','$reorder','$cat',NOW(),'$supp','$remain','$id','$depart','$unit','$item','$riscode','$req','$tos')")or die(mysqli_error($con));
		mysqli_query($con,"INSERT INTO issue_item_supply_issuance(prod_id,price,qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,product_name,ris,rec_qty,branch_receive)
			VALUES('$una','$price','$req','$tos','$desc','$me','$serial','$reorder','$cat',NOW(),'$supp','$remain','$id','$depart','$unit','$item','$riscode','$req','$tos')")or die(mysqli_error($con));
		mysqli_query($con,"INSERT INTO issue_item_general_issuance(prod_id,price,qty,branch_id,description,branch_id_to,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,product_name,ris,rec_qty,branch_receive)
			VALUES('$una','$price','$req','$tos','$desc','$me','$serial','$reorder','$cat',NOW(),'$supp','$remain','$id','$depart','$unit','$item','$riscode','$req','$me')")or die(mysqli_error($con));
		
		
	endforeach;
	
	
	mysqli_query($con,"update request_itemmacro set request_status='Confirmed', action_date=NOW() where ris_code='$riscode' and branch_id_to='$branch'");

	
	?>
		<script>
			window.alert('Request Item Confirmed!');
			window.history.back();
		</script>
	<?php
	}
?>