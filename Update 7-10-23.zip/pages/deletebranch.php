<?php
include("../dist/includes/dbcon.php");

if ($_POST)

{
	 mysqli_query($con,'INSERT into tbl_generalitems Select * from tbl_tempgeneralitems');
	  mysqli_query($con,'DELETE FROM tbl_tempgeneralitems');
  mysqli_query($con,'DELETE FROM tbl_tempiteminfo');

}
  mysqli_close($con); 
	
echo "<script>document.location='transaction.php?cid=$cid'</script>";  
?>