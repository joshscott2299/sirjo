<div x-data>
  <?php
  $where = "";
  $catid = $_GET['categorys'] ?? 0;
  // echo $catid;
  if ($catid == 0) {
    $where = " WHERE ";
  } else {
    $where = " WHERE i.request_from_branch_id = $catid AND ";
    }

  $requests_query = mysqli_query($con, "
                        SELECT 
                          i.*,
                          b.branch_id, b.branch_name
                        FROM itemreturn_head i 
                        LEFT JOIN branch b ON b.branch_id=i.request_from_branch_id 
                        $where i.status='Declined' ORDER BY i.decline_date DESC
                      ");
  ?>

  <table width="100%" class="table table-bordered table-hover" id="DeclinedTable">
    <thead>
      <tr>
        <th>ID</th>
        <th>Date Requested</th>
        <th>Date Declined</th>
        <th>Request From</th>
        <th>Remarks</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = mysqli_fetch_array($requests_query)): ?>
        <tr>
          <td><?php echo $row['itemreturn_head_id'] ; ?></td>
          <td><?php echo date('M d, Y H:i:s', strtotime($row['request_date'])) ; ?></td>
          <td><?php echo date('M d, Y H:i:s', strtotime($row['decline_date'])) ; ?></td>
          <td><?php echo $row['branch_name'] ; ?></td>
          <td><?php echo $row['remarks'] ; ?></td>
          <td>
            <button
              class="btn btn-sm btn-primary"
              data-toggle="modal" data-target="#ward_req_view_declined_modal"
              @click="$dispatch('view-declined-modal',<?php echo $row['itemreturn_head_id']; ?>)"
            >View Details</button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
