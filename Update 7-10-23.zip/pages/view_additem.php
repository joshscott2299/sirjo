<?php 
session_start();
$branch=$_SESSION['branch'];
include('../dist/includes/dbcon.php');

	$name = $_POST['prod_name'];
	$price = $_POST['prod_price'];
	$desc = $_POST['prod_desc'];
	$supplier = $_POST['supplier'];
	$reorder = $_POST['reorder'];
	$category = $_POST['category'];
	$serial = $_POST['serial'];
	$po = $_POST['po'];
	$qty = $_POST['qty'];
	
	$query2=mysqli_query($con,"select * from product where supplier_id='$supplier' and serial='$serial'")or die(mysqli_error($con));
		$count=mysqli_num_rows($query2);

		if ($count>0)
		{
			echo "<script type='text/javascript'>alert('Product already exist!');</script>";
			echo "<script>document.location='product.php'</script>";  
		}
		else
		{	

			mysqli_query($con,"INSERT INTO product(prod_name,prod_price,prod_desc,cat_id,prod_qty,reorder,supplier_id,branch_id,serial,po)
			VALUES('$name','$price','$desc','$category','$qty','$reorder','$supplier','$branch','$serial','$po')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new product!');</script>";
					  echo "<script>document.location='product.php'</script>";  
		}
?>