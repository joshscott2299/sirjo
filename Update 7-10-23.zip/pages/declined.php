<br>
<table width="100%" class="table table-striped table-bordered table-hover" id="DeclineTable">
    <thead>
        <tr>
           <th>Date Requested</th>
			<th>Date Declined</th>
			<th>RIS NO.</th>
			<th>Status</th>
			<th>From</th>
			<th>Action</th>
        </tr>
    </thead>
    <tbody>
		<?php
		include('../dist/includes/dbcon.php');
			$rq=mysqli_query($con,"select * from request_itemmacro natural join branch where request_status='Declined' order by action_date desc");
			while($rqrow=mysqli_fetch_array($rq)){
				$rid=$rqrow['requestid'];
			?>
			<tr>
			<td><?php echo date("M d, Y ", strtotime($rqrow['request_date'])); ?></td>
			<td><?php echo date("M d, Y ", strtotime($rqrow['action_date'])); ?></td>
				<td><?php echo ucwords($rqrow['ris_code']); ?></td>
				<td><?php echo ucwords($rqrow['request_status']); ?></td>
				<td><?php echo ucwords($rqrow['branch_name']); ?></td>
				
				<td><a href="#reserve_detail<?php echo $rid; ?>" data-toggle="modal" class="btn btn-info btn-sm"><i class="glyphicon glyphicon-search"></i> View</a>
					<?php include ('r_modal.php'); ?>
				</td>
				
			</tr>
			<?php
			}
		?>
    </tbody>
</table>
<!-- /.table-responsive -->