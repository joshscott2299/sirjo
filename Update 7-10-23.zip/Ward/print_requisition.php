<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
if(empty($_SESSION['branch'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Stock Card | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    
    <style type="text/css">
      tr td{
        padding-top:-10px!important;
        border: 1px solid #000;
      }
      @media print {
          .btn-print {
            display:none !important;
		  }
		  .main-footer	{
			display:none !important;
		  }
		  .main-title	{
			display:none !important;
		  }
		  .box.box-primary angel {
			  border-top:none !important;
		  }
		  
          
      }
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
    <div class="wrapper">
      
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">

          <section class="content">
            <div class="row">
	      <div class="col-md-12">
              <div class="col-md-12">

              </div>
                
                <div class="box-body">

                  <!-- Date range -->
                  <form method="post" action="">
<?php
include('../dist/includes/dbcon.php');
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
    $queryb=mysqli_query($con,"select * from branch where branch_id='$branch'")or die(mysqli_error());
  
        $rowb=mysqli_fetch_array($queryb);
        
?>	
<?php
include('../dist/includes/dbcon.php');

$branch=$_SESSION['branch'];
$user=$_SESSION['id'];
$prod=$_GET['id'];

$query5=mysqli_query($con,"select * from request_itemmacro natural join branch where requestid='$prod' and branch_id='$branch'")or die(mysqli_error($con));
  $row5=mysqli_fetch_array($query5);
           $code=$row5['ris_code'];
		   $name=$row5['branch_name'];
		    
			
?>
                 


                   <table class="table">
                    <thead>
                      
                      <center>
                     <h6>Republic of the Philippines</h6>
            <h6>Department of Health</h6>
            <h6>Regional Office No. VII</h6>
            <h6><b>GOV. CELESTINO GALLARES MEMORIAL HOSPITAL</b></h6>
            <h6>Miguel Parras St. Tagbilaran city, 6300, Bohol</h6>
			<h6>Tel. No.,(038)411-48687(038)411-4869</h6>
			<h6><u>email.gcgmh_bohol@yahoo.com.ph</u></h6>
						</center>
						
                        <th></th>
                     
                      
                    </thead>
                    <thead cellspacing="0">
						
						<tr style="font-size:10px" cellspacing="0">
						<th>
						Entity Name:<u>GOV. GALLARES MEMORIAL HOSPITAL</u></th>
						</tr>
                      <tr style="font-size:10px">
                        
                        <th style="font-size:10px">Division:____________________</th>
                        
                         <th>Responsibility Code:_________</th>
                      </tr>
					  <tr style="font-size:10px">
					  <th>Office: <u><?php echo $name;?></u></th>
					  <th>RIS Name Name No.: <u><?php echo $code;?></u></th>
					  </tr>
                     
                      
                    </thead>
                  </table>
                  <table class="table" class="display" width="100%" cellspacing="0">
                    <thead>
						
						<tr style="border: solid 1px #000">
						 <td colspan="4" class="text-center" style="font-size:11px"><b>Requisition</b></td>
						  <td colspan="2" class="text-center" style="font-size:11px"><b>Stock Available?</b></td>
						  <td colspan="2" class="text-center" style="font-size:11px"><b>Issue</b></td>
						</tr>
                      <tr style="border: solid 1px #000">
                        <td class="text-center" style="font-size:0.7em">Stock No.</td>
						 <td class="text-center" style="font-size:0.7em">Unit</td>
                        <td class="text-center" style="font-size:0.7em">Item Description</td>
						<td class="text-center" style="font-size:0.7em">Quantity</td>
						<td class="text-center" style="font-size:0.7em">Yes</td>
                        <td class="text-center" style="font-size:0.7em">No</td>
						<td class="text-center" style="font-size:0.7em">Quantity</td>
						<td class="text-center" style="font-size:0.7em">Remarks</td>		
                      </tr>
                    </thead>
                    <tbody>
<?php
		$branch=$_SESSION['branch'];
		$user=$_SESSION['id'];
		$prod=$_GET['id'];
		
		$query=mysqli_query($con,"select * from request_detailmacro  natural join product_dept natural join unit_measure where requestid='$prod' and branch_refer='$branch'")or die(mysqli_error($con));
			
		while($row=mysqli_fetch_array($query)){
				//$id=$row['temp_trans_id'];
				
        
?>
                      <tr>
									 <td style="text-align:center" style="font-size:8px"><?php echo $row['serial'];?></td>
									  <td style="text-align:center" style="font-size:8px"><?php echo $row['unit_name'];?></td>
									 <td style="text-align:center" style="font-size:8px"><?php echo $row['product_name'].",".$row['description'];?></td>
									  <td style="text-align:center" style="font-size:8px"><?php echo $row['request_qty'];?></td>
									  <td style="text-align:center" style="font-size:8px"></td>
											<td style="text-align:center"></td>
									 <td style="text-align:center"></td>
            						<td style="text-align:center"></td>
                                    
                      </tr>
					  

<?php }?>					
                    
                     
                     
                     <tr>
					  <td colspan="8"></td>
					 </tr>
                     
                       <tr style="border: solid 1px #000" class="footer">
					 
						 <td colspan="2" class="text-center" style="font-size:9px"><b>Requested by:</b></td>
						 
                        <td colspan="1" class="text-center" style="font-size:9px"><b>Approved by:</b></td>
						<td colspan="3" class="text-center" style="font-size:9px"><b>Issued by:</b></td>
						<td colspan="2" class="text-center" style="font-size:9px"><b>Received by:</b></td>
                        	
                      </tr>
                     
                    </tbody>
					   <tr style="border: solid 1px #000" class="footer">
					 
						 <td colspan="2" class="text-left" style="font-size:9px"><b>Printed Name:</b></td>
						 
                        <td colspan="1" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="3" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="2" class="text-left" style="font-size:9px"><b></b></td>
                        	
                      </tr>
					   <tr style="border: solid 1px #000" class="footer">
					 
						 <td colspan="2" class="text-left" style="font-size:9px"><b>Designation:</b></td>
						 
                        <td colspan="1" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="3" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="2" class="text-left" style="font-size:9px"><b></b></td>
                        	
                      </tr>
					   <tr style="border: solid 1px #000" class="footer">
					 
						 <td colspan="2" class="text-left" style="font-size:9px"><b>Date:</b></td>
						 
                        <td colspan="1" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="3" class="text-left" style="font-size:9px"><b></b></td>
						<td colspan="2" class="text-left" style="font-size:9px"><b></b></td>
                        	
                      </tr>
					   <th colspan="3" style="font-size:9px" class="footer">EFFECTIVITY DATE:04/01/2017</th>
                        
						<th colspan="3" style="font-size:9px" class="footer">REV.NO.0</th>
						<th colspan="2" style="font-size:9px" class="footer">GCGMH-F-MMS-36</th>
                  </table>
                </div><!-- /.box-body -->
				</div>  
				</form>	
                </div><!-- /.box-body -->
               
                <a class = "btn btn-primary btn-print" href = "request_history.php"><i class ="glyphicon glyphicon-arrow-left"></i> Back</a>
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
           
          </div><!-- /.row -->
	  
             
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->
	
	
	<script type="text/javascript" src="autosum.js"></script>
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<script src="../dist/js/jquery.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
   <script>
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
  });
</script>
  </body>
</html>
