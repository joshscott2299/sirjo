<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Ward Stock Card | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../plugins/select2/select2.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">

  <style type="text/css">
    tr td {
      padding-top: -10px !important;
      border: 1px solid #000;
    }

    @media print {
      .btn-print {
        display: none !important;
      }
      .main-footer {
        display: none !important;
      }
      .main-title {
        display: none !important;
      }
      .box.box-primary angel {
        border-top: none !important;
      }
    }
  </style>
  <style>
    table, td, th {
      border: 0.2px ;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
  </style>
</head>

<body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
  <div class="wrapper">
    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">
        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <a class="btn btn-primary btn-print" href="stockcard_search.php">
                <i class="glyphicon glyphicon-arrow-left"></i> Back
              </a>
              <div class="box-body">
                <!-- Date range -->
                <form method="post" action="">
                  <?php
                    include_once('../dist/includes/dbcon.php');
                    $id = $_SESSION['id'];
                    $branch = $_SESSION['branch'];
                    $queryb = mysqli_query($con, "select * from branch where branch_id='$branch'") 
                      or die(mysqli_error($con));

                    $rowb = mysqli_fetch_array($queryb);
                    $branch_name = $rowb['branch_name'];
                  ?>
                  <?php
                    include_once('../dist/includes/dbcon.php');

                    $branch = $_SESSION['branch'];
                    $user = $_SESSION['id'];
                    $prod_id = $_POST['prod_name'];
                    
                    $query5 = mysqli_query($con, 
                      "Select * 
                        from qty_ward 
                        natural join unit_measure 
                         where prod_id='$prod_id' 
                         AND branch_id='$branch'"
                    ) or die(mysqli_error($con));

                    $row5 = mysqli_fetch_array($query5);
                    $item = $row5['item'];
                    $ser = $row5['serial'];
                    $desc = $row5['description'];
                    $level = $row5['reorder'];
                    $price = $row5['price'];
                    $uom = $row5['unit_name'];
                  ?>

                  <table class="table">
                    <thead>
                      <div style="display: flex;">
                        <img src="/img/gcgmmc.png" style="width:150px; height:50px;">
                      </div>
                    </thead>
                    <div class="row">
                      <div class="col-xs-12">
                        <div class="row">
                          <div class="col-xs-12">
                              <label><h3>STOCKCARD </h3><br>
                                General Form NO.77
                              </label>
                          </div>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="row">
                          <div class="col-xs-12">
                            <label>Unit Price: 
                              <span><?php echo $price; ?></span>
                            </label>
                          </div>
                          <div class="col-xs-12">
                            <label>Product Name: 
                              <span><?php echo $item; ?></span>
                            </label>
                          </div>
                          <div class="col-xs-12">
                            <label>Description: 
                              <span><?php echo $desc; ?></span>
                            </label>
                          </div>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="row">
                          <div class="col-xs-12 pull-right">
                            <label class="pull-rightx">Stock Number: 
                              <span><?php echo $ser; ?></span>
                            </label>
                          </div>
                          <div class="col-xs-12 pull-right">
                            <label class="pull-rightx">Quantity Unit: 
                              <span><?php echo $uom; ?></span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </table>
                  <table style="table">
                    <thead>
                      <tr style="border: solid 1px">
                         <th style="font-size:10px"><center>Date Received or Issued</center></th>
                         <th style="font-size:10px"><center>Requisition or Issue Order Number</center></th>
                         <th style="font-size:10px"><center>For Whom Received ot to Whom Issued</center></th>
                         <th style="font-size:10px"><center>Quantity Received</center></th>
                         <th style="font-size:10px"><center>Quantity Issued</center></th>
                         <th style="font-size:10px"><center>Quantity on Hand</center></th>
                         <th style="font-size:10px"><center>Receiving Office</center></th>
                         <th style="font-size:10px"><center>Remarks</center></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $branch = $_SESSION['branch'];
                      $user = $_SESSION['id'];
                      $query = mysqli_query($con, 
                        "Select * 
                          from issuances_wards 
                          natural join category 
                          natural join unit_measure 
                          where serial='$ser' 
                          and (branch_id_from='$branch' OR branch_id_to='$branch') 
                          ORDER BY issue_date DESC") 
                        or die(mysqli_error($con));

                      $total_received = 0;

                      while ($row = mysqli_fetch_array($query)) {

                          $mode = $row['mode'];
                          $issue_date = $row['issue_date'];
                          $branch_id_from = $row['branch_id_from'];
                          $branch_id_to = $row['branch_id_to'];
                          $qty = $row['qty'];
                          $prev_stock_qty = $row['prev_stock_qty'];
                          $patient_name = $row['patient_name'];
                          $new_balance_qty = 0;
                          if($mode=='in') {
                            $new_balance_qty = $prev_stock_qty + $qty;
                          } else {
                            $new_balance_qty = $prev_stock_qty - $qty;
                          }
                         
                          // branch_name_from ================================================
                          $branch_name_from = "";
                          $branch_name_to = "";
                          $temp_bid = $mode=='in' ? $branch_id_from : $branch_id_to;

                          $csq1 = mysqli_query($con,
                          "SELECT *
                            FROM branch 
                            WHERE (branch_id='$branch_id_from' OR branch_id='$branch_id_to')
                          ");
                          foreach($csq1 as $r1) { 
                            $branches = $r1['branch_id'];
                            if($branches==$branch_id_from) { 
                              $branch_name_from = $r1['branch_name']; 
                            } else {
                              $branch_name_to = $r1['branch_name'];
                            }
                          }

                        ?>
                        <tr>
                          <td style="font-size:9px"><center><?php echo $issue_date; ?></center></td>
                          <td style="font-size:11px"><center><?php echo $row['temp_reference_no']; ?></center></td>
                          <td style="font-size:11px"><center><?php echo $branch_name_from; ?></center></td>
                          <td style="font-size:11px"><center><?php echo $prev_stock_qty; ?></center></td>
                          <td style="font-size:11px"><center><?php echo $qty; ?></center></td>
                          <td style="font-size:11px"><center><?php echo $new_balance_qty; ?></center></td>
                          <td style="font-size:11px">
                            <center>
                              <?php echo $mode=='out' ? $branch_name_to : $patient_name; ?>
                              <?php echo $mode=='in' ? $branch_name : $patient_name; ?>
                            </center>
                          </td>
                          <td style="font-size:11px"><center><?php echo ''; ?></center></td>
                       <!--   <td style="text-align:center"></td>-->
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                  <br>
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="row">
                        <div class="col-xs-6">
                          <label>EFFECTIVITY DATE:03/04/2020
                          </label>
                        </div>
                        <div class="col-xs-3">
                          <label>REV.NO.0 
                          </label>
                        </div>
                        <div class="col-xs-3">
                          <label>GCGMH-F-NUR-72
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div><!-- /.box-body -->
            </div>
          </div><!-- /.box-body -->
        </section><!-- /.content -->
      </div><!-- /.box -->
    </div><!-- /.col (right) -->
  </div><!-- /.row -->

  <script type="text/javascript" src="autosum.js"></script>
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $(".select2").select2();

      //Datemask dd/mm/yyyy
      $("#datemask").inputmask("dd/mm/yyyy", {
        "placeholder": "dd/mm/yyyy"
      });
      //Datemask2 mm/dd/yyyy
      $("#datemask2").inputmask("mm/dd/yyyy", {
        "placeholder": "mm/dd/yyyy"
      });
      //Money Euro
      $("[data-mask]").inputmask();

      //Date range picker
      $('#reservation').daterangepicker();
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        format: 'MM/DD/YYYY h:mm A'
      });
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
      );

      //Date picker
      $('#datepicker').datepicker({
        autoclose: true
      });

      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      });
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      });
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      });

      //Colorpicker
      $(".my-colorpicker1").colorpicker();
      //color picker with addon
      $(".my-colorpicker2").colorpicker();

      //Timepicker
      $(".timepicker").timepicker({
        showInputs: false
      });
    });
  </script>
</body>

</html>