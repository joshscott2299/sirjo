
<?php
	
	include('../dist/includes/dbcon.php');

	if(isset($_POST['prodid'])){
		$to = $_POST['names'];
		$quantity=array();
		$newq=array();
		$url=array();
		foreach($_POST['prodid'] as $info):
		$infopro=explode("||",$info);
		$temp_trans_id=$infopro[0];
		$iterate=$infopro[1];
		$a=mysqli_query($con,"select * from product_dept where temp_trans_id='$temp_trans_id'");
		$b=mysqli_fetch_array($a);
		
		
		
		if (isset($_POST['quantity_'.$iterate])){
			
			if (!empty($_POST['quantity_'.$iterate]==false)){
				?>
					<script>
						window.alert('The quantity of selected product must not be empty!');
						window.location.href='reorder.php';
					</script>
				<?php
					
				exit();
			}
				
			
			
			$myarray[]=array('product_macro' => $temp_trans_id, 'qty' => $_POST['quantity_'.$iterate], 'to' => $to);
		}
		endforeach;
		
		
		
			
			$encode = json_encode($myarray);
			$data = 'myarray=' . rawurlencode($encode);
			header('location:confirm_request.php?'.$data);
			
		
	}
	else{
		?>
		<script>
			window.alert('You must select product and input quantity first!');
			window.location.href='reorder.php';
		</script>
		<?php
	}
?>