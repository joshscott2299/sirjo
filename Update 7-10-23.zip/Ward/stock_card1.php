<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
if(empty($_SESSION['branch'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Stock Card | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    
    <style type="text/css">
      tr td{
        padding-top:-10px!important;
        border: 1px solid #000;
      }
      @media print {
          .btn-print {
            display:none !important;
		  }
		  .main-footer	{
			display:none !important;
		  }
		  .main-title	{
			display:none !important;
		  }
		  .box.box-primary angel {
			  border-top:none !important;
		  }
		  
          
      }
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
    <div class="wrapper">
      
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">

          <section class="content">
            <div class="row">
	      <div class="col-md-12">
              <div class="col-md-12">

              </div>
                
                <div class="box-body">

                  <!-- Date range -->
                  <form method="post" action="">
<?php
include('../dist/includes/dbcon.php');
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
    $queryb=mysqli_query($con,"select * from branch where branch_id='$branch'")or die(mysqli_error());
  
        $rowb=mysqli_fetch_array($queryb);
        
?>	
<?php
include('../dist/includes/dbcon.php');

$branch=$_SESSION['branch'];
$user=$_SESSION['id'];
$name = $_POST['prod_name'];

$query5=mysqli_query($con,"select * from product_dept where temp_trans_id='$name'")or die(mysqli_error($con));
  $row5=mysqli_fetch_array($query5);
           $branch_names=$row5['product_name'];
		   $ser=$row5['serial'];
		    $desc=$row5['description'];
			 $level=$row5['reorder'];
			 $price=$row5['price'];
?>
                 


                   <table class="table">
                    <thead>
                      
                      <center>
                     
                        <h6><b>STOCK CARD</b></h6>
						<h6>GOV. CELESTINO GALLARES MEMORIAL HOSPITAL</h6>
						<h5>Agency</h5>
						</center>
						
                        <th></th>
                     
                      
                    </thead>
                    <thead>

                      <tr>
                        
                        <th>Item: <u><?php echo $branch_names;?></u></th>
                        
                         <th>Stock No.: <u><?php echo $ser;?></u></th>
                      </tr>
					  <tr>
					  <th>Description: <u><?php echo $desc;?></u></th>
					  <th>Re-Order Point: <u><?php echo $level;?></u></th>
					  </tr>
                     
                      
                    </thead>
                  </table>
                  <table class="table">
                    <thead>
					
                      <tr style="border: solid 1px #000">
                        <td class="text-center">Date Received or Issued</td>
						 <td class="text-center">Requisition or Issue Order No.</td>
                        <td class="text-center">From Whom Recieved or To Whom Issued </td>
						<td class="text-center">Qty Recieved/On hand</td>
						<td class="text-center">Qty Issued</td>
                        <td class="text-center">Qty on Hand</td>
						
                      </tr>
                    </thead>
                    <tbody>
<?php
		$branch=$_SESSION['branch'];
		$user=$_SESSION['id'];
		
		$query=mysqli_query($con,"select * from issue_item_issuance natural join branch  natural join category natural join unit_measure natural join supplier where serial='$ser' and product_name='$branch_names' and branch_id='$branch' ORDER BY date_issue ASC")or die(mysqli_error($con));
			
		while($row=mysqli_fetch_array($query)){
				//$id=$row['temp_trans_id'];
				$total= $row['rec_qty']-$row['initial_qty'];
				
        
?>
                      <tr>
									 <td style="text-align:center"><?php echo $row['date_issue'];?></td>
									  <td style="text-align:center"><?php echo $row['ris'];?></td>
									 <td style="text-align:center"><?php echo $row['branch_name']." -> ".$row['branch_id_toname'];?></td>
									  <td style="text-align:center"><?php echo $row['rec_qty'];?></td>
									   <td style="text-align:center"><?php echo $row['initial_qty'];?></td>
									   
											
									 
            						<td style="text-align:center"><?php echo number_format($total);?></td>
                                    
                      </tr>
					  

<?php }?>					
                    
                     
                     
                     
                     
                      
                     
                    </tbody>
                      <th colspan="2" style="font-size:9px">EFFECTIVITY DATE:11/01/2014</th>
                        
						<th colspan="2" style="font-size:9px">REV.NO.0</th>
						<th colspan="2" style="font-size:9px">GCGMH-F-MMS-12</th>
                  </table>
                </div><!-- /.box-body -->
				</div>  
				</form>	
                </div><!-- /.box-body -->
               
                <a class = "btn btn-primary btn-print" href = "search_stock_issuance.php"><i class ="glyphicon glyphicon-arrow-left"></i> Back</a>
              </div><!-- /.box -->
            </div><!-- /.col (right) -->
           
          </div><!-- /.row -->
	  
             
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->
	
	
	<script type="text/javascript" src="autosum.js"></script>
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<script src="../dist/js/jquery.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
   <script>
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
  });
</script>
  </body>
</html>
