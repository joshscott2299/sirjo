<br>
<div x-data>
	<table width="100%" class="table table-striped table-bordered table-hover" id="PendingTable">
		<thead>
			<tr>
				<th>Date Requested</th>
				<th>Patient Name</th>
				<th>STATUS</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody >
			<?php
			$branch = $_SESSION['branch'];
			echo $branch;
			include_once('../dist/includes/dbcon.php');
			// $rq=mysqli_query($con,"select * from request_itemmicro natural join branch where request_status='Pending' and branch_id_to='$branch' order by request_date desc");
			$rq = mysqli_query(
				$con,
				"select * from itemrequests_head1 
				left join branch on itemrequests_head1.request_from_branch_id=branch.branch_id
				where status='Pending' and request_from_branch_id='$branch'
				ORDER BY itemrequests_head1.itemrequests_head_id DESC;"
			);
			while ($rqrow = mysqli_fetch_array($rq)) {

				$rid = $rqrow['itemrequests_head_id'];
				?>
				<tr>
					<td><?php echo date("M d, Y ", strtotime($rqrow['request_date'])); ?></td>
					<td><?php echo ucwords($rqrow['ris']); ?></td>
					<td><?php echo ucwords($rqrow['status']); ?></td>

					<td>
						<?php
							$tempRIS = "'". $rqrow['ris']. "'";
						?>
							<!-- <a href="#item_requests_view_modal" data-toggle="modal"
								x-on:mousedown="$dispatch('trigger-get-items','111')"
							>Details</a> -->
							
							
							<!-- onclick="window.tempRIS=<?php echo($tempRIS); ?>" -->
							<!-- onclick="document.getElementById('#item_requests_view_modal')".dispatchEvent(new CustomEvent('getItems2',{detail: {}, bubbles:true})) -->
						<button data-toggle="modal" data-target="#item_requests_view_modal1"
							@click="$dispatch('trigger-get-items',<?php echo($tempRIS); ?>)"
							class="btn btn-sm btn-success"
						>View Details</button>
						<button 
							onclick="pending.deleteRequest(<?php echo($tempRIS); ?>)"
							class="btn btn-sm btn-danger"
						>x</button>
					</td>
				</tr>
			<?php
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->

<script>
/**
Testing ra ni (LOL):
Encapsulate vars and methods for pending into a single object 
to avoid conflicts on method names and other variables.
*/
let pending = {
	deleteRequest(ris) {
		if(confirm('Delete request?')) {
			$.post('item_requests_delete1.php', {
				ris: ris
			}).done(response => {
				window.location.reload(true);
			});
		} else {

		}
	},
}


</script>