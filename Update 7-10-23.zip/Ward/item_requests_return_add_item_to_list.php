<?php
// header('Content-Type:application/json');
include('../dist/includes/dbcon.php');

$item_id = $_GET['item_id'] ?? '';
$item_id = htmlspecialchars(trim($item_id));

$quantity = $_GET['quantity'] ?? '';
$quantity = htmlspecialchars(trim($quantity));

$query = mysqli_query(
  $con,
  "SELECT * FROM qty_ward 
    natural join unit_measure
    WHERE prod_id = '$item_id'
    LIMIT 1
  "
) or die(mysqli_error($con));

$temp['data'] = [];

while ($row = mysqli_fetch_array($query)) {
   if($quantity <= $row['qty']) {
    $temp['success'] = true;
    $temp['data'][] = [
      'id' => $row['prod_id'],
      'serial' => $row['serial'],
      'item' => $row['item'],
      'unit' => $row['unit_name'],
      'unit_id' => $row['unit_id'],
      'quantity' => $quantity,
    ];
   } else {
     $temp['success'] = false;
   }
}

echo json_encode($temp);