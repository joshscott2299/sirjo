<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;
?>
<?php
include('../dist/includes/dbcon.php');

$branch = $_SESSION['branch'];
$user = $_SESSION['id'];
// $query5 = mysqli_query($con, "select * from temp_dept where branch_from='$branch' and e_user='$user'") or die(mysqli_error($con));
// $row5 = mysqli_fetch_array($query5);
// $branch_names = $row5['branch_to_id'];

// get patient name from POST and assign to SESSION to retain it
$issue_to_patient_name = $_POST['issue_to_patient_name'] ?? '';
if ($issue_to_patient_name != '') {
  $_SESSION['issue_to_patient_name'] = $issue_to_patient_name;
} else {
  $issue_to_patient_name = $_SESSION['issue_to_patient_name'];
}

if ($issue_to_patient_name == '') {
  echo "<script>
    alert('No patient is specified!');
    document.location='patient_select.php';
  </script>";
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Issue Item | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../plugins/select2/select2.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <script src="../dist/js/jquery.min.js"></script>
  <script language="JavaScript">
    javascript: window.history.forward(1);
  </script>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-<?php echo $_SESSION['skin']; ?> layout-top-nav" onload="myFunction()">
  <div class="wrapper">
    <?php include('../dist/includes/header_csr.php'); ?>
    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <a class="btn btn-lg btn-warning" href="home.php">Back</a>

          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Product</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-9">
              <div class="box box-primary">
                <div class="box-header">

                  <h3 class="box-title">Issue Item Transaction--->(<?php
                                                                    echo $issue_to_patient_name;
                                                                    ?>)</h3>
                </div>
                <input type="hidden" class="form-control" for="date" name="me" value=" <?php echo $_SESSION['id']; ?>" required>

                <div class="box-body">
                  <!-- Date range -->
                  <form method="post" action="transaction_patient.php">
                    <div class="row" style="min-height:400px">
                      <?php
                      $branch = $_SESSION['branch'];

                      include('../dist/includes/dbcon.php');
                      $query3 = mysqli_query($con, 
                        "SELECT * FROM temp_dept where branch_from='$branch'") or die(mysqli_error($con));
                      while ($row1 = mysqli_fetch_array($query3)) {
                      ?>

                        <input type="hidden" class="form-control pull-right" id="date" name="branch_name" tabindex="2" value="<?php echo $row1['branch_to']; ?>">
                        <input type="hidden" class="form-control pull-right" id="date" name="branch_names" tabindex="2" value="<?php echo $row1['branch_to_id']; ?>">
                      <?php } ?>


                      <div class="col-md-5">
                        <div class="form-group">
                          <label for="date">Date Issue:(yyyy-mm-dd)</label>
                          <input type="text" class="form-control" id="date" name="dates" value="<?php echo date("Y-m-d"); ?>" data-mask required>
                        </div>
                      </div>

                      <div class="col-md-8">
                        <div class="form-group">
                          <label for="date">Product Name</label>

                          <select class="form-control select2" id="selProduct" name="qty_ward_id" tabindex="1" autofocus required>
                            <?php
                            $branch = $_SESSION['branch'];
                            $cid = $_REQUEST['cid'];
                            include('../dist/includes/dbcon.php');
                            // $query2 = mysqli_query(
                            //   $con,
                            //   "select * from product_dept 
                            //   natural join unit_measure 
                            //   natural join supplier 
                            //   where branch_id_to='$branch' AND qty > 0
                            //   order by product_name, qty"
                            // )
                            //   or die(mysqli_error($con));

                            $query2 = mysqli_query(
                              $con,
                              "select * from qty_ward 
                              natural join unit_measure 
                              where branch_id = '$branch' AND qty > 0
                              order by item"
                            )
                              or die(mysqli_error($con));

                            while ($row = mysqli_fetch_array($query2)) {

                            ?>
                              <option available_qty="<?php echo $row['qty']; ?>" value="<?php echo $row['qty_ward_id']; ?>" <?php
                                                                                                                              if ($row['qty'] == 0) {
                                                                                                                                //do nothing
                                                                                                                              }
                                                                                                                              ?>><?php echo $row['item'] . "," . $row['description'] . " " . $row['unit_name'] . " &nbsp;&nbsp; Stock#(" . $row['serial'] . ") &nbsp;&nbsp;Qty[" . $row['qty'] . "]&nbsp;&nbsp;"; ?></option>
                            <?php } ?>
                          </select>
                          <input type="hidden" class="form-control" name="cid" value="<?php echo $cid; ?>" required>
                          <input type="hidden" class="form-control" id="date" name="codex" value="<?php echo $row['serial']; ?>" required>
                        </div><!-- /.form group -->
                      </div>
                      <div class=" col-md-2">
                        <div class="form-group">
                          <label for="date">Quantity</label>
                          <div class="input-group">
                            <!-- <input type="number" class="form-control pull-right" id="date" name="qty" placeholder="Quantity" tabindex="2" value="1" required> -->
                            <input type="number" class="form-control pull-right" id="txt_qty" name="qty" placeholder="Quantity" tabindex="2" value="1" required>
                          </div><!-- /.input group -->
                        </div><!-- /.form group -->
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <label for="date"></label>
                          <div class="input-group">
                            <button class="btn btn-lg btn-success" type="submit" tabindex="3" name="addtocart">+</button>
                          </div>
                        </div>
                  </form>
                </div>
                <div class="col-md-12">

                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Qty</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Issue To</th>
                        <th>Total</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php
                      $id = $_SESSION['id'];

                      $query = mysqli_query(
                        $con,
                        "select * from temp_trans_patient_phar  
                        where branch_id_from='$branch' and e_user='$id'"
                      )
                        or die(mysqli_error($con));
                      $grand = 0;
                      $grand1 = 0;
                      while ($row = mysqli_fetch_array($query)) {
                        $id = $row['temp_trans_id'];
                        $total = $row['qty'] * $row['price'];
                        $grand = $grand + $total;
                        $grand1 += $row['qty'];
                      ?>
                        <tr>
                          <td><?php echo $row['qty']; ?></td>
                          <td class="record"><?php echo $row['product_name']; ?></td>
                          <td><?php echo number_format($row['price'], 2); ?></td>
                          <td><?php echo $row['branch_id_toname']; ?></td>
                          <td><?php echo number_format($total, 2); ?></td>
                          <td>
                            <a href="#delete<?php echo $row['temp_trans_id']; ?>" data-target="#delete<?php echo $row['temp_trans_id']; ?>" data-toggle="modal" title="click to delete" style="color:#fff;" class="small-box-footer"><i class="glyphicon glyphicon-trash text-red"></i></a>
                          </td>
                        </tr>
                        <div id="updateordinance<?php echo $row['temp_trans_id']; ?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                          <div class="modal-dialog">
                            <div class="modal-content" style="height:auto">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">×</span></button>
                                <h4 class="modal-title">Update Sales Details</h4>
                              </div>
                              <div class="modal-body">
                                <form class="form-horizontal" method="post" action="transaction_update.php" enctype='multipart/form-data'>
                                  <input type="hidden" class="form-control" name="cid" value="<?php echo $cid; ?>" required>
                                  <input type="hidden" class="form-control" id="price" name="id" value="<?php echo $row['temp_trans_id']; ?>" required>
                                  <div class="form-group">
                                    <label class="control-label col-lg-3" for="price">Qty</label>
                                    <div class="col-lg-9">
                                      <input type="text" class="form-control" id="price" name="qty" value="<?php echo $row['qty']; ?>" required>
                                    </div>
                                  </div>

                              </div><br>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save changes</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                              </form>
                            </div>

                          </div>
                          <!--end of modal-dialog-->
                        </div>
                        <!--end of modal-->
                        <div id="delete<?php echo $row['temp_trans_id']; ?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                          <div class="modal-dialog">
                            <div class="modal-content" style="height:auto">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">×</span></button>
                                <h4 class="modal-title">Delete Item</h4>
                              </div>
                              <div class="modal-body">
                                <form class="form-horizontal" method="post" action="patient_del.php" enctype='multipart/form-data'>
                                  <input type="hidden" class="form-control" name="cid" value="<?php echo $cid; ?>" required>
                                  <input type="hidden" class="form-control" name="qty" value="<?php echo $row['qty']; ?>" required>
                                  <input type="hidden" class="form-control" name="temp_trans_id" value="<?php echo $row['temp_trans_id']; ?>" required>
                                  <p>Are you sure you want to remove <?php echo $row['product_name']; ?>?</p>
                              </div><br>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Delete</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                              </form>
                            </div>

                          </div>
                          <!--end of modal-dialog-->
                        </div>
                        <!--end of modal-->
                      <?php } ?>
                    </tbody>

                  </table>
                </div><!-- /.box-body -->

              </div>



              </form>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
      </div><!-- /.col (right) -->

      <div class="col-md-3">
        <div class="box box-primary">

          <div class="box-body">
            <!-- Date range -->
            <form method="post" name="autoSumForm" action="patient_issuance.php" onsubmit="return validateForm()">
              <div class="row">
                <div class="col-md-12">

                  <?php
                  $branch = $_SESSION['branch'];

                  include('../dist/includes/dbcon.php');
                  $query2 = mysqli_query($con, 
                    "SELECT * FROM temp_dept where branch_from='$branch'") or die(mysqli_error($con));
                  while ($row = mysqli_fetch_array($query2)) {
                  ?>

                    <input type="hidden" class="form-control pull-right" id="date" name="branch_name" tabindex="2" value="<?php echo $row['branch_to']; ?>">
                  <?php } ?>

                  <div class="form-group">
                    <label for="date">Total</label>

                    <input type="text" style="text-align:right" class="form-control" id="total" name="total" placeholder="Total" value="<?php echo $grand; ?>" onFocus="startCalc();" onBlur="stopCalc();" tabindex="5" readonly>

                  </div><!-- /.form group -->
                  <div class="form-group">
                    <label for="date">Total Qty</label>

                    <input type="text" style="text-align:right" class="form-control" id="total1" name="total1" placeholder="Total" value="<?php echo $grand1; ?>" onFocus="startCalc();" onBlur="stopCalc();" tabindex="5" readonly>

                  </div><!-- /.form group -->
                  <div class="form-group">


                    <input type="hidden" class="form-control text-right" id="discount" name="discount" value="0" tabindex="6" placeholder="Discount (Php)" onFocus="startCalc();" onBlur="stopCalc();">
                    <input type="hidden" class="form-control text-right" id="cid" name="cid" value="<?php echo $cid; ?>">
                  </div><!-- /.form group -->
                  <div class="form-group">


                    <input type="hidden" style="text-align:right" class="form-control" id="amount_due" name="amount_due" placeholder="Amount Due" value="<?php echo number_format($grand, 2); ?>" readonly>

                  </div><!-- /.form group -->


                  <div class="form-group" id="tendered">

                    <input type="hidden" style="text-align:right" class="form-control" onFocus="startCalc();" onBlur="stopCalc();" id="cash" name="tendered" placeholder="Cash Tendered" value="0">
                  </div><!-- /.form group -->
                  <div class="form-group" id="change">

                    <input type="hidden" style="text-align:right" class="form-control" id="changed" name="change" placeholder="Change">
                  </div><!-- /.form group -->
                </div>



              </div>

              <button class="btn btn-lg btn-block btn-success" id="daterange-btn" name="cash" type="submit" tabindex="7">
                Process Issue Item's
              </button>

            </form>
            </br>
            <form method="post" name="autoSumForm" action="cancel.php" onsubmit="return validateForm1()">
              <button class="btn btn-lg btn-block btn-danger" id="daterange-btn" name="cancel" type="submit" tabindex="7">
                Cancel
              </button>
            </form>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col (right) -->


    </div><!-- /.row -->


    </section><!-- /.content -->
  </div><!-- /.container -->
  </div><!-- /.content-wrapper -->
  <?php include('../dist/includes/footer.php'); ?>
  </div><!-- ./wrapper -->
  <script type="text/javascript">
    function validateForm() {
      var a = document.forms["autoSumForm"]["total1"].value;
      if (a == 0 || a == "") {
        alert("Select Item to Issue first!");
        return false;
      }

    }
  </script>
  <script type="text/javascript">
    function validateForm1() {
      var a = document.forms["autoSumForm"]["total1"].value;
      if (a == 1 || a == "1") {
        alert("Select Item to Issue first!");
        return false;
      }

    }
  </script>

  <script>
    $("#cash").click(function() {
      $("#tendered").show('slow');
      $("#change").show('slow');
    });

    $(function() {

      $(".btn_delete").click(function() {
        var element = $(this);
        var id = element.attr("id");
        var dataString = 'id=' + id;
        if (confirm("Sure you want to delete this item?")) {
          $.ajax({
            type: "GET",
            url: "temp_trans_del.php",
            data: dataString,
            success: function() {

            }
          });

          $(this).parents(".record").animate({
              backgroundColor: "#fbc7c7"
            }, "fast")
            .animate({
              opacity: "hide"
            }, "slow");
        }
        return false;
      });

    });
  </script>

  <script type="text/javascript" src="autosum.js"></script>
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>



  <script src="../plugins/input-mask/jquery.inputmask.js"></script>
  <script src="../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
  <script src="../plugins/input-mask/jquery.inputmask.extensions.js"></script>

  <script>
    function txtQtyChangeCallback() {
      let dat = $('#selProduct').select2('data');
      console.log(dat[0]);
    }
    $('#txt_qty').on('keyup', txtQtyChangeCallback);
    $('#txt_qty').on('change', txtQtyChangeCallback);
  </script>

  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,

        "info": true,
        "autoWidth": false
      });
    });
  </script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $(".select2").select2();
    });
  </script>
</body>

</html>