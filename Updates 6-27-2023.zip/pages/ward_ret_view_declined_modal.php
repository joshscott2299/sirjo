<div class="modal fade" id="ward_req_view_declined_modal" 
	tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
	x-data="viewDeclinedRequestState()"
	@view-declined-modal.window="getItems($event.detail)">
	<?php
		$branch = $_SESSION['branch'];
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">
					Item Return Request 
					<span class="badge badge-danger" x-text="status"></span>
				</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-12">
								<label>Request To: <span x-text="request_to"></span></label>
							</div>
							<div class="col-sm-12">
								<label>Request Date: <span x-text="request_date"></span></label>
							</div>
							<div class="col-sm-12">
								<label>Ward/Unit: <span x-text="request_from"></span></label>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-12">
								<div class="col-sm-12">
									<label class="pull-right">RIS NO: <span x-text="ris"></span></label>
								</div>
								<div class="col-sm-12">
									<label class="pull-right">Issue Date: <span x-text="issue_date"></span></label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12" style="border-top:1px solid #f3f3f3;">
						<center>
							<h6 style="padding:0;margin-top:8px;">
								<strong>RETURN SLIP</strong>
							</h6>
						</center>
					</div>
					<div class="col-sm-12">
						<em x-show="items.length<1">No items to display...</em>
						<table class="table table-bordered table-hover" 
							x-show="items.length > 0">
							<thead>
								<tr>
									<th>Item</th>
									<th>Unit</th>
									<th>Qty. Returned</th>
									<th>Qty. Received</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<template x-for="item in items" :key="item.prod_id">
									<tr>
										<td x-text="item.unit_name"></td>
										<td x-text="item.item"></td>
										<td>
											<span x-text="item.qty"></span>
										</td>
										<td>
											<span x-text="item.qty_issued"></span>
										</td>
										<td>
											<span x-text="item.remarks"></span>
										</td>
									</tr>
								</template>
							</tbody>
						</table>
					</div>
					<br>
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-4">
								<label>Requested By:
								<span x-text="requested_by"></span></label>
							</div>
							<div class="col-sm-4">
								<label>Received By:
								<span x-text="received_by"></span></label>
							</div>
							<div class="col-sm-4">
								<label>Issued By:
								<span x-text="issued_by"></span></label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>

			<script>

			</script>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

/**
Using AlpineJS (test) ***************************************
*/

// function viewDeclinedRequestState() {
function viewDeclinedRequestState() {
	return {
	// window.viewDeclinedRequestState = {
		status: '',
		request_to: '',
		request_to_branch_id: '',
		request_from: '',
		request_from_branch_id: '',
		requested_by: '',
		received_by: '',
		issued_by: '',
		requested_by_id: '',
		received_by_id: '',
		issued_by_id: '',
		ris: '',
		request_date: '',
		issue_date: '',
		remarks: '',
		items: [
			// {
				// prod_id: '',
				// serial: '',
				// item: '',
				// unit_name: '',
				// remaining_qty: '',
				// qty: '',
				// qty_issued: '',
				// remarks: '',
				// error: 0,
			// }
		],
		itemreturn_head_id: 0,

		getItems(itemreturn_head_id) {
			console.log('getItems invoked... ' + itemreturn_head_id);
			$.get(`ward_ret_view.php?itemreturn_head_id=${itemreturn_head_id}`)
			.done(response=>{
				response = JSON.parse(response);
				console.log(response);
				// console.log(viewDeclinedRequestState);
				this.ris = response.data.ris;
				this.request_date = response.data.request_date;
				this.items = response.data.items;
				this.status = response.data.status;
				this.request_from = response.data.request_from;
				this.request_to = response.data.request_to;
				this.request_from_branch_id = response.data.request_from_branch_id;
				this.request_to_branch_id = response.data.request_to_branch_id;
				this.requested_by = response.data.requested_by;
				this.issued_by = response.data.issued_by;
				this.requested_by_id = response.data.requested_by_id;
				this.issued_by_id = response.data.issued_by_id;
				this.issue_date = response.data.issue_date;
				this.itemreturn_head_id = response.data.itemreturn_head_id;
			});
		},

		// submit() {
		// 	console.log('invoking submit()...');
		// 	if(!confirm('Are you sure you want to continue?')) {
		// 		return;
		// 	}
		// 	$.post('ward_req_submit.php', {
		// 		request_to_branch_id: this.request_to_branch_id,
		// 		ris: this.ris,
		// 		request_date: this.request_date,
		// 		issue_date: this.issue_date,
		// 		request_from_branch_id: this.request_from_branch_id,
		// 		requested_by_id: this.requested_by_id,
		// 		received_by_id: this.received_by_id,
		// 		issued_by_id: this.issued_by_id,
		// 		status: 'Confirmed',
		// 		remarks: this.remarks,
		// 		items: this.items,
		// 		itemreturn_head_id: this.itemreturn_head_id
		// 	}).done(res => {
		// 		res = JSON.parse(res);
		// 		console.log(res);
		// 		// window.location.reload(true);
		// 	});
		// }
	}
}

// ****************************************************

</script>
	
