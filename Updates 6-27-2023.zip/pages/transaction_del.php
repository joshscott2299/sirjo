<?php
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
include("../dist/includes/dbcon.php");
$id = $_REQUEST['id'];
$cid = $_POST['cid'];
$qty = $_REQUEST['qty'];
$name = $_REQUEST['name'];

mysqli_query($con,"UPDATE qty_general SET qty=qty+'$qty' where ID='$name' and branch_id='$branch'") or die(mysqli_error($con)); 

mysqli_query($con,"DELETE FROM temp_trans_mms WHERE temp_trans_id ='$id'")
	or die(mysqli_error($con));
	
echo "<script>document.location='cash_transaction.php?cid=$cid'</script>";  
?>
