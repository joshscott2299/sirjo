<?php

include("../dist/includes/dbcon.php");
//empty cart by distroying current session

//add item in shopping cart


	
	//$return_url = base64_decode($_POST["return_url"]); //return url
	



$id=$_GET['id'];

 
 //echo $id;
 //echo '<br/>';
 
$result = mysqli_query($con,"SELECT * FROM product where prod_id='$id'");
		while($row = mysqli_fetch_array($result))
			{
			
				$stocks=$row['prod_qty'];
				//echo $stocks;
				//echo '<br/>';
			}
	$results = mysqli_query($con,"SELECT * FROM temp_trans where prod_id ='$id'");
		while($row = mysqli_fetch_array($results))
			{
			
				$qty=$row['qty'];
				//echo $qty;
				//echo '<br/>';
			}		

$plus = $qty + $stocks;
//echo $plus;
	mysqli_query($con,"UPDATE product SET prod_qty='$plus' WHERE prod_id='$id'");
 header("location: cash_transaction.php");
 
 $sql = "delete from temp_trans where prod_id='$id'";
header("location: cash_transaction.php");
 mysqli_query( $sql);



{


	
 

}	
	
	
	
	
	
?>