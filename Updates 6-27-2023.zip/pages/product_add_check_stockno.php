<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];
include('../dist/includes/dbcon.php');

if(isset($_POST['serial'])) {
    $serial = $_POST['serial'];
    $res = mysqli_query($con, "SELECT * FROM qty_general ".
    "WHERE serial='$serial'");
    $response = ($res->num_rows > 0) ? "existing" : "not-existing";
    echo json_encode(['response' => $response]);
}

?>