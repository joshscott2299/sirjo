<?php
//CARLO

session_start();
if (empty($_SESSION['id'])) header('Location:../index.php');

$branch = $_SESSION['branch'];

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    include('../dist/includes/dbcon.php');

    $res = mysqli_query($con, "SELECT * FROM qty_general" .
    " WHERE id=" . $id);

    if($res->num_rows > 0) {
        $row = mysqli_fetch_assoc($res);
        echo json_encode($row);
    }
}