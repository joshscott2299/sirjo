<br>
<div x-data>
	<table width="100%" class="table table-striped table-bordered table-hover" id="DeclineTable">
		<thead>
			<tr>
				<th>Date Requested</th>
				<th>Patient Name</th>
				<th>STATUS</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody >
			<?php
			$branch = $_SESSION['branch'];
			echo $branch;
			include_once('../dist/includes/dbcon.php');
			// $rq=mysqli_query($con,"select * from request_itemmicro natural join branch where request_status='Pending' and branch_id_to='$branch' order by request_date desc");
			$rq = mysqli_query(
				$con,
				"select * from itemrequests_head1
				left join branch on itemrequests_head1.request_from_branch_id=branch.branch_id
				where status='Declined' and request_from_branch_id='$branch'
				ORDER BY itemrequests_head1.itemrequests_head_id DESC;"
			);
			while ($rqrow = mysqli_fetch_array($rq)) {

				$rid = $rqrow['itemrequests_head_id'];
				?>
				<tr>
					<td><?php echo date("M d, Y ", strtotime($rqrow['request_date'])); ?></td>
					<td><?php echo ucwords($rqrow['ris']); ?></td>
					<td><?php echo ucwords($rqrow['status']); ?></td>

					<td>
						<button data-toggle="modal" data-target="#item_requests_view_modal1"
							@click="$dispatch('view-request-modal1',<?php echo($rid); ?>)"
							class="btn btn-sm btn-success"
						>View Details</button>
					</td>
				</tr>
			<?php
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->

