<?php 
session_start();
include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	$user1=$_SESSION['id'];
	
	
	$qty = $_POST['qty'];
	$user = $_POST['user'];
		$note = $_POST['note'];
		$product = $_POST['prod_name'];
	
	date_default_timezone_set('Asia/Manila');

	$date = date("Y-m-d H:i:s");
	$id=$_SESSION['id'];
	
	$query=mysqli_query($con,"select product_name,serial from product_dept where temp_trans_id='$product' and branch_id_to='$branch'")or die(mysqli_error());
  
        $row=mysqli_fetch_array($query);
		$product1=$row['product_name'];
		$product2=$row['serial'];
	$remarks="added $qty of $product";  
	
		mysqli_query($con,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($con));
		
		
	mysqli_query($con,"UPDATE product_dept SET qty=qty+'$qty' where serial='$product2' and branch_id_to='$branch'") or die(mysqli_error($con)); 
			
			mysqli_query($con,"INSERT INTO stockin_macro(product_name,serial,qty,date_issue,branch_id,e_user,note) VALUES('$product1','$product2','$qty','$date','$branch','$user','$note')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new stocks!');</script>";
					  echo "<script>document.location='stockin.php'</script>";  
	
?>