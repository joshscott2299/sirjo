<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
if(empty($_SESSION['branch'])):
header('Location:../index.php');
endif;
?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Inventory Report | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style type="text/css">
      h5,h6{
        text-align:center;
      }
		

      @media print {
          .btn-print {
            display:none !important;
		  }
		  .btn-default {
            display:none !important;
		  }
		  .main-footer	{
			display:none !important;
		  }
		  .main-title	{
			display:none !important;
		  }
		  .box.box-primary {
			  border-top:none !important;
		  }
		  
          
      }
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header.php');
      include('../dist/includes/dbcon.php');
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
         

          <!-- Main content -->
          <section class="responsive">
            <div class="row">
	    <div class="col-xs-12">
              <div class="box box-primary">
					
              
                <div class="box-body">
				<?php
include('../dist/includes/dbcon.php');

$branch=$_SESSION['branch'];
    $query=mysqli_query($con,"select * from branch where branch_id='$branch'")or die(mysqli_error());
  
        $row=mysqli_fetch_array($query);
				
?>      			<h5><b>Inventory Report</b> </h5>
					<h5><b>GOV. CELESTINO GALLARES MEMORIAL HOSPITAL</b></h5>
					 <h6>Agency</h6>
				  <h5><b>Product Inventory as of today, <?php echo date("M d, Y h:i a");?>&nbsp;(<?php echo $row['branch_name'];?>)</b></h5>
                  
				  <a class = "btn btn-success btn-print" href = "" onclick = "window.print()"><i class ="glyphicon glyphicon-print"></i> Print</a>
							<a class = "btn btn-primary btn-print" href = "home.php"><i class ="glyphicon glyphicon-arrow-left"></i> Back to Homepage</a>   
						<div class="col-lg-5 pull-right noprint">
						<select id="catList" class="btn btn-default">
							<option value="0">All Department</option>
							<?php
								$cat=mysqli_query($con,"select * from branch where category_dept='2' ");
								while($catrow=mysqli_fetch_array($cat)){
									$catid = isset($_GET['categorys']) ? $_GET['categorys'] : 0;
									$selected = ($catid == $catrow['branch_id']) ? " selected" : "";
									echo "<option$selected value=".$catrow['branch_id'].">".$catrow['branch_name']."</option>";	
								}
							?>
						</select>
						
					</div>		
                 <table width="100%" class="table table-bordered" style="font-size:13px;">
                    <thead>
					
                      
					              <th>Item Code</th> 
                        <th>Product Name</th>
                       
											
                        <th>Qty Left</th>
						
            						<th>Unit Cost</th>
            						<th>Total</th>
            						<th>Reorder</th>
                       
                     
                    </thead>
                    <tbody>
<?php
								$where="";
								if(isset($_GET['categorys']))
								{
									$catid=$_GET['categorys'];
									if ($catid==0){
										$where="";
									}
									else{
									$where = " WHERE product_dept.branch_id_to = $catid";
									}
								}

		$branch=$_SESSION['branch'];
		$query=mysqli_query($con,"select product_name,serial,price,reorder, SUM(qty) AS QTY from product_dept left join branch on branch.branch_id=product_dept.branch_id_to $where  GROUP BY product_name, serial ASC")or die(mysqli_error());
		$grand=0;
		
		while($row=mysqli_fetch_array($query)){
			$QTY= $row['QTY'];
			$total=$row['price']*$row['QTY'];
			
			$grand+=$total;
			
?>
                      <tr>
                        <td><?php echo $row['serial'];?></td>
                        <td><?php echo ucwords($row['product_name']);?></td>
                       
						
                        <td><?php echo $row['QTY'];?></td>
						
						<td>&#8369;<?php echo $row['price'];?></td>
						<td>&#8369;<?php echo number_format($total,2);?></td>
						<td class="text-center"><?php if ($row['QTY']<=$row['reorder'])echo "<span class='badge bg-red'><i class='glyphicon glyphicon-refresh'></i>Reorder</span>";?></td>
                       
                    
                       </tr>

<?php }?>		
 		   
                    </tbody>
                   
                     <tr>
						
                         <td colspan="4">Overall Total</td>
						<td colspan="1">&#8369;<?php echo number_format($grand,2);?></td>
                     	<td colspan="1"></td>
                      </tr>
                    			  
                    
                  </table>
				 
                </div><!-- /.box-body -->

	      </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->
<br>
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
	$(document).ready(function(){
		$("#catList").on('change', function(){
			if($(this).val() == 0)
			{
				window.location = 'macro_inventory.php';
			}
			else
			{
				window.location = 'macro_inventory.php?categorys='+$(this).val();
			}
		});
	});
	
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
  </body>
</html>
