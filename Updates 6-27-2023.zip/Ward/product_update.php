<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

include('../dist/includes/dbcon.php');
	$id = $_POST['id'];
	$price = $_POST['prod_price'];
	$reorder = $_POST['reorder'];
	$serial = $_POST['serial'];
	$serials = $_POST['serials'];
	$desc = $_POST['desc'];
	$expiry = $_POST['expiry'];
	$qty = $_POST['qty'];

	mysqli_query($con,"update product_dept set price='$price',qty='$qty',
	reorder='$reorder',data1='$serial',serial='$serials',description='$desc',expiry='$expiry' where temp_trans_id='$id'")or die(mysqli_error($con));
	
	echo "<script type='text/javascript'>alert('Successfully updated Item details!');</script>";
	echo "<script>document.location='product.php'</script>";  
?>
