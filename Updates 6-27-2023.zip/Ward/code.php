<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<?php
	$code=$_GET['code'];
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Issue Item | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      
    </style>
 </head>
<body>
    <div class="container-fluid">
		<br>
		<center>
            <div class="container-fluid">
				<div class="row">
                <div class="col-lg-12">
                    <div class="col-lg-12">
						<table>
							<tr>
								<td rowspan="3" style="width:60px;"><img src="../img/gcgmh.png" width="100px" height="100px"></td>
								<td><span style="font-size:20px;"></span></td>
							</tr>
						</table>
					</div>				
				</div>
				</div>
				<br>
				<div class="row">
                <div class="col-lg-12">
                    <span style="font-size:15px;">RIS CONTROL NO.:</span><span style="font-size:30px;"><?php echo $code; ?></span>					
				</div>
				</div><br>
				<div class="row">
				
				<div class="col-lg-12 noprint">
						
						<a href="reorder.php" class="btn btn-lg btn-success"><i class="fa fa-check"></i> OK</a>
				</div>
				
				</div>				
				<br>
			</div>
			</center>
	</div>
	<br>
	
	 <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
	
	
</body>
</html>