<div class="modal fade" id="item_requests_view_modal" 
	tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
	x-data="viewRequestState()"
	@view-request-modal.window="getItems($event.detail)">
	<?php
		$branch = $_SESSION['branch'];

		// get wardstaffs - TEST ****************************************************
		$q = mysqli_query($con,
			"SELECT user_id,name,branch_id,section FROM user WHERE section='test_section'"
		);
		$tempWardstaffs = [];
		while($row = mysqli_fetch_assoc($q)) {
			$tempWardstaffs[] = $row;
		}
		$tempWardstaffs = json_encode($tempWardstaffs);
		// /get wardstaffs - TEST ****************************************************
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn-print" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">
					Item Request 
					<span class="badge badge-success btn-print" x-text="status"></span>
				</h4>

			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-xs-6">
						<div class="row">
							<div class="col-xs-12">
								<label>Request To: <span x-text="request_to"></span></label>
							</div>
							<div class="col-xs-12">
								<label>Request Date: <span x-text="request_date"></span></label>
							</div>
							
						</div>
					</div>
					<div class="col-xs-6">
						<div class="row">
							<div class="col-xs-12 pull-right">
								<label class="pull-rightx">RIS NO: <span x-text="ris"></span></label>
							</div>
							<div class="col-xs-12 pull-right">
								<label class="pull-rightx">Issue Date: <span x-text="issue_date"></span></label>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12" style="border-top:1px solid #f3f3f3;">
						<center>
							<h6 style="padding:0;margin-top:8px;">
								<strong>REQUISITION SLIP</strong>
							</h6>
						</center>
					</div>
					<div class="col-xs-12">
						
						<em x-show="items.length<1">No items to display...</em>

						<table class="table table-bordered table-hover" 
							x-show="items.length > 0">
							<thead>
								<tr>
									<th>Item</th>
									<th>Unit</th>
									<th>Quantity</th>
									<th>Qty. Issued</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<template x-for="item in items" :key="item.prod_id">
									<tr>
										<td x-text="item.item"></td>
										<td x-text="item.unit_name"></td>
										<td>
											<span x-text="item.qty"></span>
										</td>
										<td>
											<span x-text="item.qty_issued"></span>
										</td>
										<td>
											<span x-text="item.remarks"></span>
										</td>
									</tr>
								</template>
							</tbody>
						</table>
					</div>
					<br>
					<div class="col-sm-12">
						<div class="row">
							<div class="col-xs-4">
							    <label>Ward/Unit: 
								<span x-text="request_from"></span></label>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-4">
							    <label>Requested By:
								<span x-text="requested_by"></span></label>
							</div>
							<div class="col-xs-4">
								<label>Returned By:
								<span x-text="received_by"></span></label>
							</div>
							<div class="col-xs-4">
								<label class="pull-rightx">Received By:
								<span x-text="issued_by"></span></label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button class="btn btn-primary btn-print" 
					onclick="printElement('#item_requests_view_modal')">
					Print
				</button>
				<button class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>

			<script>

			</script>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

/**
Using AlpineJS (test) ***************************************
*/

// function viewRequestState() {
function viewRequestState() {
	return {
	// window.viewRequestState = {
		status: '',
		request_to: '',
		request_to_branch_id: '',
		request_from: '',
		request_from_branch_id: '',
		requested_by: '',
		received_by: '',
		issued_by: '',
		requested_by_id: '',
		received_by_id: '',
		issued_by_id: '',
		ris: '',
		request_date: '',
		issue_date: '',
		remarks: 'test request remarks',
		items: [
			// {
				// prod_id: '',
				// serial: '',
				// item: '',
				// unit_name: '',
				// remaining_qty: '',
				// qty: '',
				// qty_issued: '',
				// remarks: '',
				// error: 0,
			// }
		],
		itemrequests_head_id: 0,

		getItems(itemrequests_head_id) {
			console.log('getItems invoked... ' + itemrequests_head_id);
			$.get(`item_requests_view.php?itemrequests_head_id=${itemrequests_head_id}`)
			.done(response=>{
				response = JSON.parse(response);
				console.log(response);
				// console.log(viewRequestState);
				this.ris = response.data.ris;
				this.request_date = response.data.request_date;
				this.items = response.data.items;
				this.status = response.data.status;
				this.request_from = response.data.request_from;
				this.request_to = response.data.request_to;
				this.request_from_branch_id = response.data.request_from_branch_id;
				this.request_to_branch_id = response.data.request_to_branch_id;
				this.requested_by = response.data.requested_by;
				this.issued_by = response.data.issued_by;
				this.received_by = response.data.received_by;
				this.requested_by_id = response.data.requested_by_id;
				this.issued_by_id = response.data.issued_by_id;
				this.received_by_id = response.data.received_by_id;
				this.issue_date = response.data.issue_date;

				this.itemrequests_head_id = response.data.itemrequests_head_id;
			});
		},
	}
}

// ****************************************************

</script>
	
