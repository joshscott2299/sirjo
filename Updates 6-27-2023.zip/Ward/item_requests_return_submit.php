<?php
// header('Content-Type:application/json');
include('../dist/includes/dbcon.php');

$request = $_POST ?? [];
$request = json_decode(json_encode($request));

$response = [];

// check if RIS already exists...
// $query = mysqli_query(
//   $con,
//   "select * from itemrequests_head
//   where ris='$request->ris' LIMIT 1;
//   "
// );

// if(mysqli_num_rows($query) > 0) {
//   $response['success']=false;
//   $response['message']='RIS already exists. Please specify another.';
//   echo json_encode($response);
//   return;
// } else {
  
// }

// $query->close();

  $query2 = mysqli_query(
    $con,
    "INSERT INTO itemreturn_head(
      request_to_branch_id,request_date,request_from_branch_id,requested_by_id
    )
    VALUES(
      $request->request_to_branch_id,
      '$request->request_date',
      $request->request_from_branch_id,
      $request->requested_by_id
    );
    "
  );
  $lastInsertedID = null;

  if($query2==true) {
    $q = mysqli_query(
      $con, "SELECT itemreturn_head_id FROM itemreturn_head ORDER BY itemreturn_head_id DESC LIMIT 1"
    );
    while($row=mysqli_fetch_array($q)) {
      $lastInsertedID = $row['itemreturn_head_id'];
    }
  }
  
  foreach($request->items as $item) {
    mysqli_query($con,
      "INSERT INTO itemreturn_line(prod_id,qty,serial,unit_id,itemreturn_head_id)
      VALUES(
        '$item->id',
        '$item->quantity',
        '$item->serial',
        '$item->unit_id',
        $lastInsertedID
      )
      "
    );
  }

  $response['success']=true;
  $response['message']='Successful';

  echo json_encode($response);
