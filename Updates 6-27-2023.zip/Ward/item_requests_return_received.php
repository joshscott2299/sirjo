<br>
<div x-data>
	<table width="100%" class="table table-striped table-bordered table-hover" id="ReceivedTable">
		<thead>
			<tr>
				<th>Date Requested</th>
				<th>Date Received</th>
				<th>Return Slip No.</th>
				<th>STATUS</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody >
			<?php
			$branch = $_SESSION['branch'];
			//echo $branch;
			include_once('../dist/includes/dbcon.php');
			// $rq=mysqli_query($con,"select * from request_itemmicro natural join branch where request_status='Pending' and branch_id_to='$branch' order by request_date desc");
			$rq = mysqli_query(
				$con,
				"select * from itemreturn_head 
				left join branch on itemreturn_head.request_from_branch_id=branch.branch_id
				where status='Received' and request_from_branch_id='$branch'
				ORDER BY itemreturn_head.request_date DESC;"
			);
			while ($rqrow = mysqli_fetch_array($rq)) {

				$rid = $rqrow['itemreturn_head_id'];
				?>
				<tr>
					<td><?php echo date("M d, Y H:i:s", strtotime($rqrow['request_date'])); ?></td>
					<td><?php echo date("M d, Y H:i:s", strtotime($rqrow['issue_date'])); ?></td>
					<td><?php echo date("M d, Y H:i:s", strtotime($rqrow['receive_date'])); ?></td>
					<td><?php echo ucwords($rqrow['status']); ?></td>

					<td>
						<button data-toggle="modal" data-target="#item_requests_return_view_modal"
							@click="$dispatch('view-request-modal',<?php echo($rid); ?>)"
							class="btn btn-sm btn-success">View Details</button>
					</td>
				</tr>
			<?php
			}
			?>
		</tbody>
	</table>
</div>
<!-- /.table-responsive -->

