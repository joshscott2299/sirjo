<?php
// session_start();
include("../dist/includes/dbcon.php");

// kinsay ga issue
$branch=$_SESSION['branch'];

// kinsay issuehan...
$issue = $_SESSION['branch_to'];
$sessionRIS = $_SESSION['ris'];

$c = mysqli_query($con,
	"SELECT * FROM temp_trans_mms where branch_receive='$branch' and ris='$sessionRIS'"
);
	
foreach($c as $row1) {
	$prod = $row1['prod_id'];
	$qty = $row1['qty'];
	$price = $row1['price'];
	$from = $row1['branch_id_from'];
	$to = $row1['branch_id_to'];
	$desc = $row1['description'];
	$serial = $row1['serial'];
	$reorder = $row1['reorder'];
	$cat = $row1['cat_id'];
	$initial = $row1['initial_qty'];
	$issues = $row1['date_issue'];
	$supp = $row1['supplier_id'];
	$bal = $row1['balance_qty'];
	$euser = $row1['e_user'];
	$toname = $row1['branch_id_toname'];
	$unit = $row1['unit_id'];
	$batch = $row1['batch'];
	$pr = $row1['pr'];
	$po = $row1['po'];
	$iar = $row1['iar'];
	$expiry = $row1['expiry'];
	$product = $row1['product_name'];
	$ris = $row1['ris'];
	$rec = $row1['rec_qty'];
	$receive = $row1['branch_receive'];
	$bar = $row1['data1'];
	$clas = '2';

	$query2 = mysqli_query($con,
		"SELECT * FROM product_dept 
		where serial ='$serial' and branch_id_to='$from' and ris='$ris'"
	);

	$number=mysqli_num_rows($query2);

	if ($number > 0)
	{
		mysqli_query($con,
			"update product_dept 
			set qty=qty+'$qty', initial_qty=initial_qty+'$qty' 
			where serial ='$serial' and branch_id_to='$from'"
		) 
		or die(mysqli_error($con));
	}
	else 
	{
		mysqli_query($con,
		
			"INSERT INTO product_dept(
				prod_id,price,qty,branch_id_from,branch_id_to,description,
				serial,reorder,cat_id,initial_qty,date_issue,supplier_id,
				balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,
				iar,expiry,product_name,ris,rec_qty,branch_receive,data1,clas
			) VALUES (
				'$prod','$price','$qty','$from','$to','$desc','$serial',
				'$reorder','$cat','$initial','$issues','$supp','$bal',
				'$euser','$toname','$unit','$batch','$pr','$po','$iar',
				'$expiry','$product','$ris','$rec','$receive','$bar','$clas'
			)"
		) or die(mysqli_error($con));
	}

	// 2022-09-25
	// ****************************************************************************
	// ************************* to issuances_wards table *************************
	// ****************************************************************************
	$issueDate = date('Y-m-d H:i:s', time());

	// kaloy 2022-08-07
	// previous stock qty ================================================
	$prev_stock_qty = 0;
	$csq = mysqli_query($con,"
		SELECT qty FROM qty_ward WHERE prod_id=$prod AND branch_id=$from
	");
	foreach($csq as $r) { 
		$prev_stock_qty = $r['qty'] + $qty;
	}
	// /previous stock qty ================================================

	mysqli_query($con, 
		"INSERT INTO issuances_wards(
			temp_reference_no,
			patient_name,
			prev_stock_qty,
			qty,
			prod_id,
			serial,
			prod_name,
			description,
			price,
			cat_id,
			unit_id,
			branch_id_from,
			branch_id_to,
			mode,
			issued_by_id,
			issue_date,
			clas
		) 
		VALUES(
			'$ris',
			'',
			$prev_stock_qty,
			$qty,
			'$prod',
			'$serial',
			'$product',
			'$desc',
			$price,
			$cat,
			$unit,
			'$from',
			'$to',
			'out',
			$euser,
			'$issueDate',
			'$clas'
		)"
	) or die(mysqli_error($con));
	// ****************************************************************************
	// ************************* /to issuances_wards table ************************
	// ****************************************************************************
}

mysqli_close($con); 

// echo "<script>document.location='ward_req_add_issue_process.php'</script>";

// header('location:ward_req_add_issue_process.php');

