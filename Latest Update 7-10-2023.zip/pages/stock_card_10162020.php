<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
if(empty($_SESSION['branch'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Stock Card | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    
    <style type="text/css">
      tr td{
        padding-top:-10px!important;
        border: 1px solid #000;
      }
      @media print {
          .btn-print {
            display:none !important;
		  }
		  .main-footer	{
			display:none !important;
		  }
		  .main-title	{
			display:none !important;
		  }
		  .box.box-primary angel {
			  border-top:none !important;
		  }
		  
          
      }
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
    <div class="wrapper">
      
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">

          <section class="content">
            <div class="row">
	      <div class="col-md-12">
              <div class="col-md-12">

              </div>
                
                <div class="box-body">

                  <!-- Date range -->
                  <form method="post" action="">
<?php
include('../dist/includes/dbcon.php');
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
    $queryb=mysqli_query($con,"select * from branch where branch_id='$branch'")or die(mysqli_error());
  
        $rowb=mysqli_fetch_array($queryb);
        
?>	
<?php
include('../dist/includes/dbcon.php');

$branch=$_SESSION['branch'];
$username=$_SESSION['id'];
$name = $_POST['prod_name'];

$query5=mysqli_query($con,"select * from product natural join unit_measure where prod_id='$name'")or die(mysqli_error($con));
  $row5=mysqli_fetch_array($query5);
           $branch_names=$row5['prod_name'];
		   $ser=$row5['serial'];
		    $price=$row5['prod_price'];
			 $unit=$row5['unit_name'];
			
?>
 <table width="100%" class="table-bordered" style="font-size:11px;">
<thead>
                        <td><pull-right><img src="/img/gcgmh.png" style="width:150px; height:50px;"> </pull-right></td>
                    
                       <center>
                      <th colspan="5" style="font-weight:normal"><font size="3"><center>CSR STOCK CARD</center></th>
                      </center>
                   
                      <tr></tr>
                      <tr></tr>
                      
                      <td>
                         &nbsp
                         &nbsp
                        <p>Item: </p><p>Unit: </p><p>Stock No.:</p>  <td><b><p><?php echo $branch_names; ?></b></p>  <p><b><?php echo $unit; ?></b></p><p><b><?php echo $ser; ?></b></p></td>
                        
                        
                        </tr></td></t>

                    
                        <!--<td style="font-size:7px"><center><b>DATE & TIME</b></center></td>-->
                         <th colspan="1" style="font-weight:normal"><font size="2"><center>DATE & TIME</center></th>
                        <!--<td style="font-size:10px"><center><b>REFERENCE</b></center></td>-->
                        <th colspan="1" style="font-weight:normal"><font size="2"><center>REFERENCE</center></th>
                        <!--<td style="font-size:10px"><center><b>QTY</b></center></td> <!--//current qty-->
                        <th colspan="1" style="font-weight:normal"><font size="2"><center>QTY</center></th>
						<!--<td style="font-size:10px"><center><b>RELEASING OFFICE</b></center></td>-->
						<th colspan="1" style="font-weight:normal"><font size="2"><center>RELEASING OFFICE</center></th>
						<!--<td class="text-center">Expiration</td>-->
                        <!--<td style="font-size:10px"><center><b>QTY</b></center></td> <!--//qty issued-->
                        <th colspan="1" style="font-weight:normal"><font size="2"><center>QTY</center></th>
                        <!--<td style="font-size:10px"><center><b>RECEIVING OFFICE</b></center></td>-->
                        <th colspan="1" style="font-weight:normal"><font size="2"><center>RECEIVING OFFICE</center></th>
                        <!--<td style="font-size:10px"><center><b>BALANCE</b></center></td>-->
                        <th colspan="1" style="font-weight:normal"><font size="2"><center>BALANCE</center></th>
						<!--<td style="font-size:10px"><center><b>INITIALS</b></center></td>-->
						<th colspan="1" style="font-weight:normal"><font size="2"><center>INITIALS</center></th>
						<!--<td class="text-center"><b>REMARKS</b></td>--> <!--//.-->

                    </thead>
                    
                     <tbody>
                      <?php
                      $branch = $_SESSION['branch'];
                      
					  $e_user = $_SESSION['name'];
                     
                      $grand = 0;
                      $grand1 = 0;
                      //$query=mysqli_query($con,"select product_name,description,price,balance_qty,serial,unit_name,cat_name,supplier_name,ris,pr,po,branch_id_toname,iar,date_issue, SUM(qty) AS QTY from issue_item_supply natural join category natural join unit_measure natural join supplier where date(date_issue)>='$start' and date(date_issue)<='$end' and branch_id_from='$branch' ORDER BY date_issue ASC")or die(mysqli_error($con));
                      $query = mysqli_query($con, "select * from issue_item_supply ".
                      "natural join category natural join unit_measure natural join supplier natural join user ".
                      "where serial='$ser' and name='$e_user'") 
                      or die(mysqli_error($con));

                      while ($row = mysqli_fetch_array($query)) {
                        //$id=$row['temp_trans_id'];
						
                        $qty = $row['qty'];
                        $total = $row['balance_qty'] - $row['qty'];
                        $total_cost = $qty * $row['price'];
                        $grand += $total_cost;
                        $grand1 += $qty;

                        ?>
                        <tr>
                          
                          <td style="font-size:8px"><center><?php echo $row['date_issue']; ?></center</td>
                          <td style="font-size:10px"><center><?php echo $row['ris']; ?></center></td>
                          <td style="font-size:10px"><center><?php echo $row['balance_qty']; ?></center></td>
                          <td style="font-size:10px"><center><?php echo $row['supplier_name']; ?></center></td>
                          <!--<td style="text-align:center"><!--<?php echo $row['expiry']; ?></td>-->
                          
                          <td style="font-size:10px"><center><?php echo $row['qty']; ?></center></td>
                          <td style="font-size:10px"><center><?php echo $row['branch_id_toname']; ?></center></td>

                          <td style="font-size:10px"><center><?php echo number_format($total); ?><center></td>
						  <td style="font-size:10px"><center><?php echo $row['e_user']; ?></center></td>
						  <!--<td style="text-align:center"><?php echo $row['']; ?></td>-->
						  

                        </tr>

                        </tr>


                      <?php } ?>

                    </tbody>
					
<!--
                     <th colspan="4" style="font-weight:normal"><font size="1">Effectivity Date:03/04/2020</th>
                    <th colspan="3" style="font-weight:normal"><font size="1">Rev. No: 01</th>
                    <th colspan="5" style="font-weight:normal"><font size="1">GCGMH-F-CSR-18</th>

-->
                  </table>
              </div><!-- /.box-body -->
            </div>
            </form>
          </div><!-- /.box-body -->

          <a class="btn btn-primary btn-print" href="search_stock.php"><i class="glyphicon glyphicon-arrow-left"></i> Back to Homepage</a>
      </div><!-- /.box -->
    </div><!-- /.col (right) -->

  </div><!-- /.row -->


  </section><!-- /.content -->
  </div><!-- /.container -->
  </div><!-- /.content-wrapper -->

  </div><!-- ./wrapper -->


  <script type="text/javascript" src="autosum.js"></script>
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $(".select2").select2();

      //Datemask dd/mm/yyyy
      $("#datemask").inputmask("dd/mm/yyyy", {
        "placeholder": "dd/mm/yyyy"
      });
      //Datemask2 mm/dd/yyyy
      $("#datemask2").inputmask("mm/dd/yyyy", {
        "placeholder": "mm/dd/yyyy"
      });
      //Money Euro
      $("[data-mask]").inputmask();

      //Date range picker
      $('#reservation').daterangepicker();
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        format: 'MM/DD/YYYY h:mm A'
      });
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
      );

      //Date picker
      $('#datepicker').datepicker({
        autoclose: true
      });

      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      });
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      });
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      });

      //Colorpicker
      $(".my-colorpicker1").colorpicker();
      //color picker with addon
      $(".my-colorpicker2").colorpicker();

      //Timepicker
      $(".timepicker").timepicker({
        showInputs: false
      });
    });
  </script>
</body>

</html>