<div class="modal fade" id="ward_req_view_printable_modal" 
	tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
	x-data="viewPrintableItemRequestState()"
	@view-printable-modal.window="getItems($event.detail)"
>
	<?php
		$branch = $_SESSION['branch'];

		// get wardstaffs - TEST ****************************************************
		$q = mysqli_query($con,
			"SELECT user_id,name,branch_id,section FROM user ORDER by name"
		);
		$tempWardstaffs = [];
		while($row = mysqli_fetch_assoc($q)) {
			$tempWardstaffs[] = $row;
		}
		$tempWardstaffs = json_encode($tempWardstaffs);
		// /get wardstaffs - TEST ****************************************************
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn-print" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">
					Item Request 
					<span class="badge badge-success btn-print" x-text="status"></span>
				</h4>

			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-xs-6">
						<div class="row">
							<div class="col-xs-12">
								<label>Request To: <span x-text="request_to"></span></label>
							</div>
							<div class="col-xs-12">
								<label>Request Date: <span x-text="request_date"></span></label>
							</div>
							
						</div>
					</div>
					<div class="col-xs-6">
						<div class="row">
							<div class="col-xs-12 pull-right">
								<label class="pull-rightx">RIS NO: <span x-text="ris"></span></label>
							</div>
							<div class="col-xs-12 pull-right">
								<label class="pull-rightx">Issue Date: <span x-text="issue_date"></span></label>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12" style="border-top:1px solid #f3f3f3;">
						<center>
							<h6 style="padding:0;margin-top:8px;">
								<strong>REQUISITION SLIP</strong>
							</h6>
						</center>
					</div>
					<div class="col-xs-12">
						
						<em x-show="items.length<1">No items to display...</em>

						<table class="table table-bordered table-hover" 
							x-show="items.length > 0">
							<thead>
								<tr>
									<th>Balance</th>
									<th>Standard Stock Level</th>
									<th>Quantity</th>
									<th>Unit</th>
									<th>Item</th>
									<th>Qty.</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<template x-for="item in items" :key="item.prod_id">
									<tr>
										<td>
											<span x-text="item.balance_qty"></span>
										</td>
										<td></td>
										<td>
											<span x-text="item.qty"></span>
										</td>
										<td x-text="item.unit_name"></td>
										<td x-text="item.item"></td>
										<td>
											<span x-text="item.qty_issued"></span>
										</td>
										<td>
											<span x-text="item.remarks"></span>
										</td>
									</tr>
								</template>
							</tbody>
						</table>
					</div>
					<br>
					<br>
					<div class="col-sm-12">
						<div class="row">
							<div class="col-xs-4">
							    <label>Ward/Unit: 
								<span x-text="request_from"></span></label>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-4">
							    <label>Requested By:
								<span x-text="requested_by"></span></label>
							</div>
							<div class="col-xs-4">
								<label>Received By:
								<select x-model="received_by_id"
									style="border:1px solid lightblue;padding:4px;">
									<option value=""></option>
									<template 
										x-for="wardstaff in wardstaffs">
										<option :value="wardstaff.user_id" x-text="wardstaff.name"></option>
									</template>
								</select>
							</div>
							<div class="col-xs-4">
								<label class="pull-rightx">Issued By:
								<span x-text="issued_by"></span></label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button class="btn btn-primary btn-print" @click="markAsReceived()"
					:disabled="received_by_id==''">
					Mark as Received
				</button>
				<button class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>

			<script>

			</script>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

/**
Using AlpineJS (test) ***************************************
*/

// function viewPrintableItemRequestState() {
function viewPrintableItemRequestState() {
	return {
	// window.viewPrintableItemRequestState = {
		status: '',
		request_to: '',
		request_to_branch_id: '',
		request_from: '',
		request_from_branch_id: '',
		requested_by: '',
		received_by: '',
		issued_by: '',
		requested_by_id: '',
		received_by_id: '',
		issued_by_id: '',
		ris: '',
		request_date: '',
		issue_date: '',
		remarks: 'test request remarks',
		items: [
			// {
				// prod_id: '',
				// serial: '',
				// item: '',
				// unit_name: '',
				// remaining_qty: '',
				// qty: '',
				// qty_issued: '',
				// remarks: '',
				// error: 0,
			// }
		],
		itemrequests_head_id: 0,
		wardstaffs: <?php echo $tempWardstaffs; ?>,

		getItems(itemrequests_head_id) {
			console.log('getItems invoked... ' + itemrequests_head_id);
			$.get(`ward_req_view.php?itemrequests_head_id=${itemrequests_head_id}`)
			.done(response=>{
				response = JSON.parse(response);
				console.log(response);
				// console.log(viewPrintableItemRequestState);
				this.ris = response.data.ris;
				this.request_date = response.data.request_date;
				this.items = response.data.items;
				this.status = response.data.status;
				this.request_from = response.data.request_from;
				this.request_to = response.data.request_to;
				this.request_from_branch_id = response.data.request_from_branch_id;
				this.request_to_branch_id = response.data.request_to_branch_id;
				this.requested_by = response.data.requested_by;
				this.issued_by = response.data.issued_by;
				this.requested_by_id = response.data.requested_by_id;
				this.issued_by_id = response.data.issued_by_id;
				this.issue_date = response.data.issue_date;

				this.itemrequests_head_id = response.data.itemrequests_head_id;
			});
		},

		markAsReceived() {
			console.log('invoking markAsReceived()...');
			if(!confirm('Are you sure you want to continue?')) {
				return;
			}
			$.post('ward_req_receive.php', {
				itemrequests_head_id: this.itemrequests_head_id,
				received_by_id: this.received_by_id,
			}).done(res => {
				// res = JSON.parse(res);
				console.log(res);
				window.location.reload(true);
			});
		}
	}
}

// ****************************************************

</script>
	
