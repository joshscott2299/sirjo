<?php 

include('../dist/includes/dbcon.php');

	$name = $_POST['name'];
	$area = $_POST['area'];
		
			
			mysqli_query($con,"INSERT INTO requester(requester_name,requester_area) 
				VALUES('$name','$area')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new requester!');</script>";
					  echo "<script>document.location='requester.php'</script>";  
	
?>