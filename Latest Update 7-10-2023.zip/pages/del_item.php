<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
$branch=$_SESSION['branch'];	
include('../dist/includes/dbcon.php');

$id=$_POST['id'];

// June 26, 2019 (CARLO) ===============================================================
$serial = $_POST['serial'];
// echo('serial'. $serial . '<br>'); // test

$res = mysqli_query($con, "SELECT current_qty FROM product WHERE prod_id='$id'");
$row = mysqli_fetch_assoc($res);
$prod_currqty = $row['current_qty'];
// echo('prod_currqty' . $prod_currqty . "<br>"); // test
$res->close(); // free up $res resource usage

$res = mysqli_query($con, "SELECT prod_name,prod_desc,supplier_id " . 
"FROM product WHERE serial='$serial'");
$row = mysqli_fetch_assoc($res);
$prod_name = $row['prod_name'];
// echo('prod_name' . $prod_name . "<br>"); // test
$prod_desc = $row['prod_desc'];
// echo('prod_desc' . $prod_desc . "<br>"); // test
$prod_supplier = $row['supplier_id'];
// echo('prod_supplier' . $prod_supplier . "<br>"); // test
$prod_item_count = $res->num_rows;
$res->close();

$res = mysqli_query($con, "SELECT qty FROM qty_general WHERE `serial`='$serial'");
$row = mysqli_fetch_assoc($res);
$qty_general_currqty = $row['qty'];
// echo('qty_general_currqty' . $qty_general_currqty . "<br>"); // test
$res->close();

//subtract the current qty of the item from the current general qty of the product
$curr_qty = $qty_general_currqty - $prod_currqty;
// echo('curr_qty' . $curr_qty . "<br>"); // test

// die('test');

$res = mysqli_query($con, "UPDATE qty_general SET ".
"item='$prod_name',description='$prod_desc',qty=$curr_qty,". 
"supplier_id=$prod_supplier WHERE serial='$serial'");
// die($res);
// June 26, 2019 (CARLO) =================================================================

$result=mysqli_query($con,"DELETE FROM product WHERE prod_id ='$id'")
	or die(mysqli_error($con));

	/* if isa nalang yung item sa item list, burahin na rin yung
	nasa qty_general na table */
	if($prod_item_count === 1) {
		mysqli_query($con,"DELETE FROM qty_general WHERE serial ='$serial'")
		or die(mysqli_error($con));
	}

	header('Location:product.php');
// echo "<script>document.location='product.php'</script>";


?>