<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];
include('../dist/includes/dbcon.php');

date_default_timezone_set('Asia/Manila');

$date = date("Y-m-d H:i:s");
$dates = date("Y-m-d");

	$name = $_POST['item'];
	$price = $_POST['prod_price'];
	$desc = $_POST['prod_desc'];
	
	$reorder = $_POST['reorder'];
	$category = $_POST['category'];
	$serial = $_POST['serial'];
	$qty = $_POST['qty'];
	$unit = $_POST['unit'];
	$expire = $_POST['expire'];
	$barcode = $_POST['barcode'];
	$supplier = $_POST['supplier'];
	$username = $_POST['username'];
	
	$query2=mysqli_query($con,"select * from product_dept where product_name ='$name' and data1 ='$barcode'")or die(mysqli_error($con));
	$count=mysqli_num_rows($query2);
	 
		
		if ($count>0)
		{
			echo "<script type='text/javascript'>alert('Check the item name or stock no. first! if already exists!!');</script>";
			echo "<script>document.location='product.php'</script>";  
}
  else {
    
          mysqli_query($con,"INSERT INTO product_dept(price,qty,description,branch_id_to,serial,reorder,cat_id,date_issue,supplier_id,e_user,unit_id,product_name,expiry,data1) VALUES('$price','$qty','$desc','$branch','$serial','$reorder','$category','$date','$supplier','$id','$unit','$name','$expire','$barcode')")or die(mysqli_error($con));
				mysqli_query($con,"INSERT INTO tbl_petty_item(barcode,serial,item,description,unit_id,qty,price,cat_id,reorder,expiry,date_receive,user,branch_id,user_id)
			VALUES('$barcode','$serial','$name','$desc','$unit','$qty','$price','$category','$reorder','$expire','$date','$username','$branch','$id')")or die(mysqli_error($con));
			
			
			}
	

			echo "<script type='text/javascript'>alert('Successfully added new Item!');</script>";
					  echo "<script>document.location='product.php'</script>";  
		
?>