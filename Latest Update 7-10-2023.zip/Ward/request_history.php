<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Product | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <style>

  </style>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-<?php echo $_SESSION['skin']; ?> layout-top-nav">
  <div class="wrapper">
    <?php include('../dist/includes/header_csr.php'); ?>
    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">
        <!-- Content Header (Page header) -->

        <section class="content-header">

          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Product</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="responsive">
          <div class="row">


            <div class="col-xs-12">
              <div class="box box-primary">

                <div class="box-header">
                  <h3 class="box-title">Product List Request Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th class="hidden"></th>
                        <th>Date Requested</th>
                        <th>Date Issued</th>
                        <th>RIS NO.</th>
                        <th>Department</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $td = 0;
                      $tsales = 0;

                      $branch = $_SESSION['branch'];
                      $user = $_SESSION['id'];
                      $sh = mysqli_query($con, "select * from request_itemmacro natural join branch where branch_id='$branch' order by request_date desc");
                      while ($shrow = mysqli_fetch_array($sh)) {
                        ?>
                        <tr>
                          <td class="hidden"></td>
                          <td><?php echo date("M d, Y ", strtotime($shrow['request_date'])); ?></td>
                          <td><?php echo date("M d, Y ", strtotime($shrow['action_date'])); ?></td>
                          <td>
                            <?php
                            echo $shrow['ris_code'];
                            ?>
                          </td>

                          <td>
                            <?php
                            echo $shrow['branch_name'];
                            ?>
                          </td>
                          <td>
                            <?php
                            echo $shrow['request_status'];
                            ?>
                          </td>
                          <td>
                            <a href="#full_detail<?php echo $shrow['requestid']; ?>" data-toggle="modal" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-search"></i> View Full Details</a>
                            <?php include('modal_hist.php'); ?>
                            <a href="print_requisition.php?id=<?php echo $shrow['requestid']; ?>" data-toggle="modal" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-print"></i> Print</a>

                          </td>
                        </tr>
                      <?php
                    }
                    ?>
                    </tbody>

                  </table>
                </div><!-- /.box-body -->

              </div><!-- /.col -->


            </div><!-- /.row -->


        </section><!-- /.content -->
      </div><!-- /.container -->
    </div><!-- /.content-wrapper -->
    <?php include('../dist/includes/footer.php'); ?>
  </div><!-- ./wrapper -->

  <!--end of modal-->
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>

  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false
      });
    });
  </script>
</body>

</html>