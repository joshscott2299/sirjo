<?php
session_start();
include("../dist/includes/dbcon.php");

$branch=$_SESSION['branch'];

$issue = $_POST['branch_name'];



$query1= "SELECT prod_id,price,qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty FROM temp_trans where branch_id_from='$branch'";

if $result=$mysqli_query($con,$query1){
	
	while ($row = $result->fetch_row()){
			 
			$query2 = $mysqli->query($con,"SELECT * FROM product_dept where prod_id = '$row[1]' and branch_id_from='$branch'");
			
			if ($mysqli_num_rows(query2) > 0)
			{
				$update = "UPDATE product_dept set qty = qty + 'row[3]', current_qty = current_qty + 'row[3]' where branch_id_from='$branch'";
				$queryupdate = $mysqli-$mysql_db_query($update);
			}
			else
			{
				$insert = "INSERT INTO product_dept(prod_id,price,qty,current_qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty)VALUES('$row[0]', '$row[1]', '$row[2]', '$row[9]', '$row[3]', '$row[4]', '$row[5]', '$row[6]', '$row[7]', '$row[8]', '$row[11]')";
				$queryinsert = $mysqli->$mysql_db_query($insert);
			}
	}
	$result->close();
}
	$mysqli->close();
	
echo "<script>document.location='home.php'</script>";  
?>