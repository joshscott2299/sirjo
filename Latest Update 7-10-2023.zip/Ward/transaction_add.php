<?php 
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];	

include('../dist/includes/dbcon.php');

	date_default_timezone_set('Asia/Manila');
	$date = $_POST['dates'];
	$cid = $_POST['cid'];
	$name = $_POST['prod_name'];
	$qty = $_POST['qty'];
	$issue = $_POST['branch_name'];
	$issues = $_POST['branch_names'];
	$ris = $_POST['ris'];
	
			
		$query=mysqli_query($con,"select price,temp_trans_id,description,branch_id_to,reorder,serial,cat_id,qty,supplier_id,unit_id,batch,pr,po,iar,product_name,expiry from product_dept where temp_trans_id='$name'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);
		$price=$row['price'];
		$desc=$row['description'];
		$stock=$row['reorder'];
		$code=$row['serial'];
		$category=$row['cat_id'];
		$remain=$row['qty'];
		$sup=$row['supplier_id'];
		$current=$row['qty'];
		$unit=$row['unit_id'];
		$batch=$row['batch'];
		$pr=$row['pr'];
		$po=$row['po'];
		$iar=$row['iar'];
		$item=$row['product_name'];
		$expiry=$row['expiry'];
		

		$query3=mysqli_query($con,"select temp_id,branch_to from temp_dept where temp_id='$issue'")or die(mysqli_error());
		$row=mysqli_fetch_array($query3);
		$to=$row['branch_id'];

		
		$query1=mysqli_query($con,"select * from temp_trans where prod_id='$name' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error());
		$count=mysqli_num_rows($query1);
		
		$total=$price*$qty;

   if ($qty == 0 )
  {
    ?>
            <script type="text/javascript">
            alert("Enter quantity greater than 0!");
            window.location = "cash_transaction.php";           
            </script>
            
<?php
  }
		
	else if ($count>0){
			mysqli_query($con,"update temp_trans set qty=qty+'$qty', initial_qty=initial_qty+'$qty' where prod_id='$name' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error());
			mysqli_query($con,"UPDATE product_dept SET qty=qty-'$qty' where temp_trans_id='$name' and branch_id_to='$branch'") or die(mysqli_error($con)); 	
	
		}
		else{
			
			mysqli_query($con,"UPDATE product_dept SET qty=qty-'$qty' where temp_trans_id='$name' and branch_id_to='$branch'") or die(mysqli_error($con)); 
			mysqli_query($con,"INSERT INTO temp_trans(prod_id,qty,price,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,ris,rec_qty,branch_receive) VALUES('$name','$qty','$price','$branch','$desc','$issue','$code','$stock','$category','$qty','$date','$sup','$current','$id','$issues','$unit','$batch','$pr','$po','$iar','$expiry','$item','$ris','$current','$branch')")or die(mysqli_error($con));
		}
		


	
		echo "<script>document.location='cash_transaction.php?cid=$cid'</script>";  
	
?>