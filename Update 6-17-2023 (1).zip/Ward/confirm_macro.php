<?php session_start();
if (empty($_SESSION['id'])) :
	header('Location:../index.php');
endif;
?>
<?php

include('../dist/includes/dbcon.php');

$myarray = json_decode($_GET['myarray'], true);
$credit = $_GET['credit'];

$encode = json_encode($myarray);
$data = 'myarray=' . rawurlencode($encode);



$branch = $_SESSION['branch'];
$user = $_SESSION['id'];

$set = '123456789';
$code = substr(str_shuffle($set), 0, 12);





mysqli_query($con, "insert into request_itemmacro (user_id, branch_id, request_date, request_status, ris_code, branch_id_to) values ('$user', '$branch', NOW(), 'Pending', '$code', '$credit')");
$rid = mysqli_insert_id($con);

foreach ($myarray as $info) :
	$pro = mysqli_query($con, "select * from product_dept where temp_trans_id = $info[product_macro]");
	$prorow = mysqli_fetch_array($pro);
	$name = $prorow['product_name'];


	$quant = $info['qty'];
	$quant1 = $info['to'];

	mysqli_query($con, "insert into request_detailmacro (requestid, temp_trans_id, request_qty, branch_refer, branch_id_tos, stock_name) values ('$rid' , $info[product_macro], $info[qty], '$branch', $info[to], '$name')");
endforeach;



?>
<script type="text/javascript">
	var code = "<?php echo $code; ?>";
	window.alert("Request successful!");
	window.location.href = 'code.php?code=' + code;
</script>