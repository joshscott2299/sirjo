<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemrequests_head_id = $_POST['itemrequests_head_id'] ?? 0;
$itemrequests_head_id = htmlspecialchars(trim($itemrequests_head_id));

mysqli_query(
  $con, "DELETE FROM itemrequests_head WHERE itemrequests_head_id='$itemrequests_head_id';"
);
mysqli_query(
  $con, "DELETE FROM itemrequests_line WHERE itemrequests_head_id='$itemrequests_head_id';"
);
