<!-- Decline Reserve -->
    <div class="modal fade" id="decline_<?php echo $rid; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Decline Request</h4></center>
                </div>
                <div class="modal-body">
				<?php
				$tq=0;
					$res=mysqli_query($con,"select * from request_itemmicro natural join branch where requestid='$rid' and branch_id_to='$branch'");
					$rrow=mysqli_fetch_array($res);
					
				?>
				<form method="POST" action="decline_res.php<?php echo '?id='.$rid; ?>">
				<div class="container-fluid">
					<div class="form-group input-group">
						<span class="input-group-addon" style="width:150px;">Department Name:</span>
						<span style="width:350px;" class="form-control"><?php echo ucwords($rrow['branch_name']); ?></span>
					</div><br><br>
					<div class="form-group input-group">
						<span class="input-group-addon" style="width:150px;">RIS NO.:</span>
						<span style="width:350px;" class="form-control"><?php echo ucwords($rrow['ris_code']); ?></span>
					</div>
                </div>                 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Decline</button>
					</form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->

<!-- Confirm Reserve -->
    <div class="modal fade" id="confirm_<?php echo $rid; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Confirm Request(All Item)</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$res=mysqli_query($con,"select * from request_itemmicro where requestid='$rid' and branch_id_to='$branch'");
					$rrow=mysqli_fetch_array($res);
				?>
				<form method="POST" action="confirm_res.php<?php echo '?id='.$rid; ?>">
				<div class="container-fluid">
					<div class="form-group input-group">
						<span class="input-group-addon" style="width:150px;">RIS NO.:</span>
						<input type="text" style="width:350px;" name="riscode" class="form-control" required>
					</div>
                </div>                 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Confirm</button>
					</form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->
