<!-- History -->
    <div class="modal fade" id="full_detail<?php echo $shrow['requestid']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<center><h4 class="modal-title" id="myModalLabel">Request Item Detail's</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$reserve=mysqli_query($con,"select * from request_itemmacro where requestid='".$shrow['requestid']."'");
					$rerow=mysqli_fetch_array($reserve);
				?>
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-9 rname">
							<p>Request To:<b> MMS</b></p>
						</div>
						<div class="col-lg-3">
							<p class="pull-right">Date Requested:<b> <?php echo date("M d, Y", strtotime($rerow['request_date'])); ?></b></p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-9">
							<p>Status:<b> <?php echo ucwords($rerow['request_status']); ?></b></p>
						</div>
						<div class="col-lg-3">
							<p class="pull-right">RIS NO.: <strong><?php echo $rerow['ris_code']; ?></strong></p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<table width="100%" class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th>Stock No.</th>
										<th>Item Name</th>
										<th>Description</th>
										<th>Unit</th>
										<th>Category</th>
										<th>Qty Request</th>
										
										
									</tr>
								</thead>
								<tbody>
									<?php
									$branch=$_SESSION['branch'];
									include('../dist/includes/dbcon.php');
										$tq=0;
										
										$rd=mysqli_query($con,"select * from request_detailmacro natural join product_dept natural join unit_measure natural join category  where requestid='".$shrow['requestid']."' and branch_refer='$branch'");
										while($rdrow=mysqli_fetch_array($rd)){
											?>
											<tr>
											<td><?php echo ucwords($rdrow['serial']); ?></td>
												<td><?php echo ucwords($rdrow['product_name']); ?></td>
												<td><?php echo ucwords($rdrow['description']); ?></td>
												<td><?php echo ucwords($rdrow['unit_name']); ?></td>
												<td align="right">
													 
													<?php 
														echo $rdrow['cat_name'];
													?>
												</td>
												<td>
													<?php 
														echo $rdrow['request_qty'];
														$tq+=$rdrow['request_qty'];
													?>
												</td>
												
											
											</tr>
											<?php
										}
									?>
									<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
										<td align="right"><strong>Total Qty</strong></td>
										<td><strong><?php echo $tq; ?></strong></td>
										
										
									</tr>
									
								
								
								
								</tbody>
							</table>
						</div>
					</div>      
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->