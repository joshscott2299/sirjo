<?php 
session_start();
include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	$name = $_POST['prod_name'];
	$qty = $_POST['qty'];
	$user = $_POST['user'];

	
	date_default_timezone_set('Asia/Manila');

	$date = date("Y-m-d H:i:s");
	$id=$_SESSION['id'];
	
	
	$query6=mysqli_query($con,"select product_name,description,price,serial,data1,unit_id,cat_id,reorder,expiry from product_dept where temp_trans_id='$name'")or die(mysqli_error());
        $row6=mysqli_fetch_array($query6);
		$product1=$row6['product_name'];
		$product2=$row6['description'];
		$product3=$row6['price'];
		$product4=$row6['serial'];
		$product5=$row6['data1'];
		$product6=$row6['unit_id'];
		$product7=$row6['cat_id'];
		$product8=$row6['expiry'];
		$product9=$row6['reorder'];
	
	
	
	$query=mysqli_query($con,"select product_name from product_dept where temp_trans_id='$name'")or die(mysqli_error());
        $row=mysqli_fetch_array($query);
		$product=$row['product_name'];
	$remarks="added $qty of $product";  
	
		mysqli_query($con,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($con));
		
		
	mysqli_query($con,"UPDATE product_dept SET qty=qty+'$qty' where temp_trans_id='$name' and branch_id_to='$branch'") or die(mysqli_error($con)); 
			
			mysqli_query($con,"INSERT INTO tbl_petty_item (barcode,serial,item,description,unit_id,qty,price,cat_id,reorder,expiry,date_receive,user,branch_id,user_id) VALUES('$product5','$product4','$product1','$product2','$product6','$qty','$product3','$product7','$product9','$product8','$date','$user','$branch','$id')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully item added!');</script>";
					  echo "<script>document.location='petty_cash.php'</script>";  
	
?>