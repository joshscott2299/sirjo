<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Stock Card | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../plugins/select2/select2.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">

  <style type="text/css">
    tr td {
      padding-top: -10px !important;
      border: 1px solid #000;
    }

    @media print {
      .btn-print {
        display: none !important;
      }

      .main-footer {
        display: none !important;
      }

      .main-title {
        display: none !important;
      }

      .box.box-primary angel {
        border-top: none !important;
      }


    }
  </style>
</head>

<body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
  <div class="wrapper">

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">

        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="col-md-12">

              </div>

              <div class="box-body">

                <!-- Date range -->
                <form method="post" action="">
                  <?php
                    include_once('../dist/includes/dbcon.php');
                    $id = $_SESSION['id'];
                    $branch = $_SESSION['branch'];
                    $queryb = mysqli_query($con, "select * from branch where branch_id='$branch'") 
                      or die(mysqli_error($con));

                    $rowb = mysqli_fetch_array($queryb);
                    $branch_name = $rowb['branch_name'];
                  ?>
                  <?php
                    include_once('../dist/includes/dbcon.php');

                    $branch = $_SESSION['branch'];
                    $user = $_SESSION['id'];
                    $prod_id = $_POST['prod_name'];

                    // kaloy 2022-07-08
                    $query5 = mysqli_query($con, 
                      "select * from qty_ward where prod_id='$prod_id' AND branch_id='$branch'"
                    ) or die(mysqli_error($con));

                    $row5 = mysqli_fetch_array($query5);
                    $item = $row5['item'];
                    $ser = $row5['serial'];
                    $desc = $row5['description'];
                    $level = $row5['reorder'];
                    $price = $row5['price'];
                    $qty_available = $row5['qty'];
                  ?>

                  <table class="table">
                    <thead>
                      <center>
                        <h6><b>STOCK CARD (PATIENTS ISSUANCES)</b></h6>
                        <h6>GOV. CELESTINO GALLARES MEMORIAL HOSPITAL</h6>
                        <h5>Agency</h5>
                      </center>
                      <center>
                        <b><?php echo $branch_name; ?></b>
                      </center>
                    </thead>
                    <thead>

                      <tr>
                        <th>Item: <u><?php echo $item; ?></u></th>
                        <th>Stock No.: <u><?php echo $ser; ?></u></th>
                      </tr>
                      <tr>
                        <th>Description: <u><?php echo $desc; ?></u></th>
                        <th>Re-Order Point: <u><?php echo $level; ?></u></th>
                      </tr>


                    </thead>
                  </table>
                  <table class="table">
                    <thead>
                      <tr style="border: solid 1px #000">
                        <td class="text-center">Date Issued</td>
                        <td class="text-center">Reference #</td>
                        <td class="text-center">Issued To</td>
                        <td class="text-center">Current Stock Qty</td>
                        <td class="text-center">Qty Issued</td>
                        <td class="text-center">Balance Qty</td>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $branch = $_SESSION['branch'];
                      $user = $_SESSION['id'];
                      // $date = $_POST['date'];
                      // $date = explode('-', $date);
                      // $start = date("Y/m/d", strtotime($date[0]));
                      // $end = date("Y/m/d", strtotime($date[1]));

                      $query = mysqli_query($con, 
                        "select * from issuances_wards 
                        natural join category 
                        natural join unit_measure 
                        where serial='$ser' 
                        and branch_id_from='$branch' 
                        ORDER BY issue_date") 
                        or die(mysqli_error($con));

                      $total_issued = 0;

                      while ($row = mysqli_fetch_array($query)) {
                        //$id=$row['temp_trans_id'];
                        // $total = $row['rec_qty'] - $row['initial_qty'];
                          $prev_stock_qty = intval($row['prev_stock_qty']);
                          $balance_qty = $prev_stock_qty - intval($row['qty']);

                          $total_issued += intval($row['qty']);
                        ?>
                        <tr>
                          <td style="text-align:center"><?php echo $row['issue_date']; ?></td>
                          <td style="text-align:center"><?php echo $row['temp_reference_no']; ?></td>
                          <td style="text-align:center"><?php echo $row['patient_name']; ?></td>
                          <td style="text-align:center"><?php echo $prev_stock_qty; ?></td>
                          <td style="text-align:center"><?php echo $row['qty']; ?></td>
                          <td style="text-align:center"><?php echo $balance_qty; ?></td>
                        </tr>
                      <?php } ?>
                    </tbody>
                    <tr style="border: solid 1px #000">
                      <td colspan="4" class="text-center">Total</td>
                      <td class="text-center"><?php echo $total_issued; ?></td>
                      <td class="text-center"></td>
                    </tr>
                    <th colspan="2" style="font-size:9px">EFFECTIVITY DATE:11/01/2014</th>

                    <th colspan="1" style="font-size:9px">REV.NO.0</th>
                    <th colspan="1" style="font-size:9px">GCGMH-F-MMS-12</th>
                  </table>
              </div><!-- /.box-body -->
            </div>
            </form>
          </div><!-- /.box-body -->

          <a class="btn btn-primary btn-print" href="search_stock_issuance.php"><i class="glyphicon glyphicon-arrow-left"></i> Back</a>
      </div><!-- /.box -->
    </div><!-- /.col (right) -->

  </div><!-- /.row -->


  </section><!-- /.content -->
  </div><!-- /.container -->
  </div><!-- /.content-wrapper -->

  </div><!-- ./wrapper -->


  <script type="text/javascript" src="autosum.js"></script>
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $(".select2").select2();

      //Datemask dd/mm/yyyy
      $("#datemask").inputmask("dd/mm/yyyy", {
        "placeholder": "dd/mm/yyyy"
      });
      //Datemask2 mm/dd/yyyy
      $("#datemask2").inputmask("mm/dd/yyyy", {
        "placeholder": "mm/dd/yyyy"
      });
      //Money Euro
      $("[data-mask]").inputmask();

      //Date range picker
      $('#reservation').daterangepicker();
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        format: 'MM/DD/YYYY h:mm A'
      });
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
      );

      //Date picker
      $('#datepicker').datepicker({
        autoclose: true
      });

      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      });
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      });
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      });

      //Colorpicker
      $(".my-colorpicker1").colorpicker();
      //color picker with addon
      $(".my-colorpicker2").colorpicker();

      //Timepicker
      $(".timepicker").timepicker({
        showInputs: false
      });
    });
  </script>
</body>

</html>