<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Stock Card | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../plugins/select2/select2.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">

  <style type="text/css">
    tr td {
      padding-top: -10px !important;
      border: 1px solid #000;
    }

    @media print {
      .btn-print {
        display: none !important;
      }

      .main-footer {
        display: none !important;
      }

      .main-title {
        display: none !important;
      }

      .box.box-primary angel {
        border-top: none !important;
      }


    }
  </style>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
  <div class="wrapper">

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">

        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="col-md-12">

              </div>

              <div class="box-body">

                <!-- Date range -->
                <form method="post" action="">
                  <?php
                  include('../dist/includes/dbcon.php');
                  $id = $_SESSION['id'];
                  $branch = $_SESSION['branch'];
                  $queryb = mysqli_query($con, "select * from branch where branch_id='$branch'") or die(mysqli_error($con));

                  $rowb = mysqli_fetch_array($queryb);
                  $date = $_POST['date'];
                  $date = explode('-', $date);
                  $start = date("Y/m/d", strtotime($date[0]));
                  $end = date("Y/m/d", strtotime($date[1]));


                  ?>




                  <table class="table">
                    <thead>

                      <center>

                        <h6><b>STOCK CARD (RECEIVED)</b></h6>
                        <h6>GOV. CELESTINO GALLARES MEMORIAL HOSPITAL</h6>
                        <h5>Agency</h5>

                        <h4 class="text-center">From <?php echo date("M d, Y", strtotime($start)) . " To " . date("M d, Y", strtotime($end)); ?></h4>
                      </center>


                    </thead>

                  </table>
                  <table class="table">
                    <thead>

                      <tr style="border: solid 1px #000">
                        <td class="text-center">Name</td>
                        <td class="text-center">Description</td>
                        <td class="text-center">Unit</td>

                        <td class="text-center">Category</td>
                        <td class="text-center">Qty Received</td>
                        <td class="text-center">Unit Cost</td>

                        <td class="text-center">Total Cost</td>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $branch = $_SESSION['branch'];
                      $user = $_SESSION['id'];
                      $date = $_POST['date'];
                      $date = explode('-', $date);
                      $start = date("Y/m/d", strtotime($date[0]));
                      $end = date("Y/m/d", strtotime($date[1]));
                      $cat = $_POST['cat_name']; // cat_id is being retrieved here...
                      
                      $grand = 0;
                      $grand1 = 0;

                      //$query=mysqli_query($con,"select * from issue_item_issuance natural join category natural join unit_measure natural join supplier where cat_id='$cat' and date(date_issue)>='$start' and date(date_issue)<='$end' and branch_id='$branch' ORDER BY date_issue ASC")or die(mysqli_error($con));

                      $query = mysqli_query($con, 
                        "
                        select product_name,description,rec_qty,price,serial,unit_name,
                        cat_name, SUM(rec_qty) AS REC_QTY 
                        from product_dept 
                        natural join category 
                        natural join unit_measure 
                        where cat_id='$cat' and date(date_issue)>='$start' and date(date_issue)<='$end' 
                        AND branch_id_to=$branch 
                        GROUP by serial
                        "
                      ) 
                      or die(mysqli_error($con));

                      while ($row = mysqli_fetch_array($query)) {
                        //$id=$row['temp_trans_id'];
                        $rec_qty = $row['REC_QTY'];
                        // $total = $row['balance_qty'] - $row['QTY'];
                        $total_cost = $rec_qty * $row['price'];
                        $grand += $total_cost;
                        $grand1 += $rec_qty;
                      ?>
                        <tr>
                          <td style="text-align:center"><?php echo $row['product_name']; ?></td>
                          <td style="text-align:center"><?php echo $row['description']; ?></td>
                          <td style="text-align:center"><?php echo $row['unit_name']; ?></td>

                          <td style="text-align:center"><?php echo $row['cat_name']; ?></td>
                          <td style="text-align:center"><?php echo $row['REC_QTY']; ?></td>
                          <td style="text-align:center"><?php echo number_format($row['price'], 2); ?></td>




                          <td style="text-align:center"><?php echo number_format($total_cost, 2); ?></td>
                        </tr>


                      <?php } ?>









                      <tr>
                        <td colspan="4">Overall Total</td>
                        <td style="text-align:center"><?php echo number_format($grand1); ?></td>
                        <td></td>
                        <td colspan="1" style="text-align:center">&#8369;<?php echo number_format($grand, 2); ?></td>

                      </tr>
                    </tbody>

                    <th colspan="3" style="font-size:9px">EFFECTIVITY DATE:11/01/2014</th>

                    <th colspan="3" style="font-size:9px">REV.NO.0</th>
                    <th colspan="1" style="font-size:9px">GCGMH-F-MMS-13</th>


                  </table>
              </div><!-- /.box-body -->
            </div>
            </form>
          </div><!-- /.box-body -->

          <a class="btn btn-primary btn-print" href="received_search_stock.php"><i class="glyphicon glyphicon-arrow-left"></i> Back to Homepage</a>
      </div><!-- /.box -->
    </div><!-- /.col (right) -->

  </div><!-- /.row -->


  </section><!-- /.content -->
  </div><!-- /.container -->
  </div><!-- /.content-wrapper -->

  </div><!-- ./wrapper -->


  <script type="text/javascript" src="autosum.js"></script>
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $(".select2").select2();

      //Datemask dd/mm/yyyy
      $("#datemask").inputmask("dd/mm/yyyy", {
        "placeholder": "dd/mm/yyyy"
      });
      //Datemask2 mm/dd/yyyy
      $("#datemask2").inputmask("mm/dd/yyyy", {
        "placeholder": "mm/dd/yyyy"
      });
      //Money Euro
      $("[data-mask]").inputmask();

      //Date range picker
      $('#reservation').daterangepicker();
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        format: 'MM/DD/YYYY h:mm A'
      });
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
      );

      //Date picker
      $('#datepicker').datepicker({
        autoclose: true
      });

      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      });
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      });
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      });

      //Colorpicker
      $(".my-colorpicker1").colorpicker();
      //color picker with addon
      $(".my-colorpicker2").colorpicker();

      //Timepicker
      $(".timepicker").timepicker({
        showInputs: false
      });
    });
  </script>
</body>

</html>