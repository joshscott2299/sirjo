<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<?php
	$myarray = json_decode($_GET['myarray'], true);
	
	$encode = json_encode($myarray);
	$data1 = rawurlencode($encode);
	
 
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Product Reorder | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header_csr.php');?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">
          <!-- Content Header (Page header) -->
          <section class="content-header">
           </br>
            <ol class="breadcrumb">
              <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Request List Item</li>
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="row">
	      
            
            <div class="col-xs-12">
              <div class="box box-primary">
    
                <div class="box-header">
                  <h3 class="box-title">List of Request Item</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
				
                  <table  class="table table-striped table-bordered table-hover" >
                    <thead>
                                <tr>
                                    <th>Item Code</th>
									<th>Item Name</th>
									<th>Description</th>
									<th>Unit</th>
									<th>Category</th>
									<th>Qty Requested</th>
                                </tr>
                            </thead>
                   <tbody>
								<?php
								include('../dist/includes/dbcon.php');
								
									$tq=0;
									$tp=0;
									$td=0;
									$tpro=0;
									$tnbd=0;
									$tnet=0;
									foreach ($myarray as $data):
                  $rd=mysqli_query($con,
                    "select * from product_dept 
                    natural join category 
                    natural join unit_measure 
                    where temp_trans_id=$data[product_macro]");
									$rdrow=mysqli_fetch_array($rd);
									//$rd=mysqli_query($con,"select * from reserve_detail left join product on product.productid=reserve_detail.productid where reserveid='$rid'");
									//while($rdrow=mysqli_fetch_array($rd)){
										?>
										<tr>
										<td><?php echo ucwords($rdrow['serial']); ?></td>
										<td><?php echo ucwords($rdrow['product_name']); ?></td>
										<td><?php echo ucwords($rdrow['description']); ?></td>
										<td><?php echo ucwords($rdrow['unit_name']); ?></td>
											<td><?php echo ucwords($rdrow['cat_name']); ?></td>
											<td>
												<?php 
													echo $data['qty'];
													$tq+=$data['qty'];
												?>
											</td>
											<td hidden>
												<?php 
													echo $data['to'];
													$tp=$data['to'];
												?>
											</td>
											
										</tr>
										<?php
									
									 endforeach;
								?>
								<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
									<td align="right"><strong>Total Quantity</strong></td>
									<td><strong><?php echo $tq; ?></strong></td>
									<td hidden><strong><?php echo $tp; ?></strong></td>
									
								</tr>
								
								
								
								
							
								
							</tbody>
                   
                  </table>
				 </br>
				  <div class="row">
					<div class="col-lg-12">
					<span class="pull-right">
					<a href="confirm_macro.php?<?php echo 'myarray='.$data1.'&credit='.$tp; ?>" class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Confirm</a> <a href="reorder.php" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Cancel</a>
					</span>
					</div>
      </div><!-- /.content-wrapper -->
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	  
            
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
		
		$("form").on('submit',function(evt){
		var _this = $(this);
		materialTable.$('input[type="checkbox"]').each(function(){
			if(!$.contains(document, this))
			{
				if(this.checked)
				{
					_this.append($('<input>').attr('type', 'hidden').attr('name', this.name).val(this.value));
				}
			} 
		});
		materialTable.$('input[type="text"]').each(function(){
			if(!$.contains(document, this))
			{
				_this.append($('<input>').attr('type', 'hidden').attr('name', this.name).val(this.value));
			} 
		});
	});
	
      });
    </script>
  </body>
</html>
