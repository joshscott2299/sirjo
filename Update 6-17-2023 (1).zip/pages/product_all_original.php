<?php
//

session_start();
$branch = $_SESSION['branch'];
include('../dist/includes/dbcon.php');

$query = mysqli_query($con, "select * from qty_general " . 
    "natural join category natural join supplier " .
    "where branch_id='$branch' " . 
    "order by item") or die(mysqli_error($con));

$products = array();

while ($row = mysqli_fetch_assoc($query)) {

    $row['item_with_description'] = $row['item'] . " " . $row['description'];

    $row['action'] = 
    /* view all action button */
    "<a href='viewall.php?id=" . $row['serial'] . "' " .
    "title='View item list' " .
    "style='color:#fff; class='small-box-footer'>" .
    "<i class='glyphicon glyphicon-list-alt text-blue'></i></a> | " . 
    
    /* edit product action button */
    "<a id='btn_edit' pid='" . $row['ID'] . "' href='#mod_update' " .
    /* "onclick=this " . */
    "title='Edit Item' data-target='#mod_update' " .
    "data-toggle='modal' style='color:#fff;" .
    "class='btn_edit'><i class='glyphicon glyphicon-edit text-blue'></i></a>";

    // "<a href='#updateordinance" . $row['ID'] . "' " .
    // "title='Edit Item' data-target='#updateordinance" .  $row['ID'] . "' " .
    // "data-toggle='modal' style='color:#fff;" .
    // "class='small-box-footer'><i class='glyphicon glyphicon-edit text-blue'></i></a>";

    $products[] = $row;
}

echo json_encode(array('data' => $products)); // return response as json


?>