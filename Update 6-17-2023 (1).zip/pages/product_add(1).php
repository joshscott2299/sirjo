<?php
session_start();
$branch = $_SESSION['branch'];
$id = $_SESSION['id'];
include('../dist/includes/dbcon.php');

date_default_timezone_set('Asia/Manila');

$date = date("Y-m-d H:i:s");
$dates = date("Y-m-d");

$name = $_POST['item'];
$price = $_POST['prod_price'];
$desc = $_POST['prod_desc'];
$supplier = $_POST['supplier'];
$reorder = $_POST['reorder'];
$category = $_POST['category'];
$serial = $_POST['serial'];
$po = $_POST['po'];
$qty = $_POST['qty'];
$unit = $_POST['unit'];
$pr = $_POST['pr'];
$iar = $_POST['iar'];
$expire = $_POST['expire'];
$batch = $_POST['batch'];
$barcode = $_POST['barcode'];
$dateme = $_POST['dateme'];


if (isset($_POST['prod'])) {
	$prod = $_POST['prod']; // detect wether the user is adding a new prod
} else {
	$prod = "new_prod";
}

// die($prod);

$query2 = mysqli_query($con, "select * from product where prod_name !='$name' and serial='$serial'") or die(mysqli_error($con));
$count = mysqli_num_rows($query2);

$query = mysqli_query($con, "select serial,qty,initial from qty_general where serial='$serial'") or die(mysqli_error($con));
$row = mysqli_fetch_array($query);
$no = $row['serial'];
$bal = $row['qty'];

if ($count > 0) {
	echo "<script type='text/javascript'>alert('Check the item name or stock no. first!');</script>";
	echo "<script>document.location='product.php'</script>";
}

// die('serial='. $serial . '<br>'. 'no=' . $no);
else if ($serial == $no) {
	mysqli_query($con, "update qty_general set qty=qty+'$qty', initial=initial+'$qty' where serial='$serial' and branch_id='$branch'") or die(mysqli_error());
	mysqli_query($con, "INSERT INTO product(prod_name,unit_id,prod_price,prod_desc,cat_id,prod_qty,current_qty,reorder,supplier_id,branch_id,serial,po,pr,iar,expiry,date_created,batch_no,barcode)
			VALUES('$name','$unit','$price','$desc','$category','$qty','$qty','$reorder','$supplier','$branch','$serial','$po','$pr','$iar','$expire','$dateme','$batch','$barcode')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO issue_item_supply(price,branch_id_from,description,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,unit_id,batch,pr,po,iar,product_name,data1,balance)
			VALUES('$price','$branch','$desc','$serial','$reorder','$category','$dateme','$supplier','$qty','$id','$unit','$batch','$pr','$po','$iar','$name','0','$bal')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO issue_item_supply_receive(price,branch_id_from,description,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,unit_id,batch,pr,po,iar,product_name,data1)
			VALUES('$price','$branch','$desc','$serial','$reorder','$category','$dateme','$supplier','$qty','$id','$unit','$batch','$pr','$po','$iar','$name','0')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO product_backup(prod_name,unit_id,prod_price,prod_desc,cat_id,prod_qty,current_qty,reorder,supplier_id,branch_id,serial,po,pr,iar,expiry,date_created,batch_no,barcode)
			VALUES('$name','$unit','$price','$desc','$category','$qty','$qty','$reorder','$supplier','$branch','$serial','$po','$pr','$iar','$expire','$dateme','$batch','$barcode')") or die(mysqli_error($con));
	mysqli_query($con, "update qty_general set price='$price', supplier_id='$supplier' where serial='$serial' and branch_id='$branch'") or die(mysqli_error());
} else {

	mysqli_query($con, "INSERT INTO qty_general(serial,item,qty,initial,price,branch_id,barcode,description,cat_id,unit_id,reorder,supplier_id) VALUES('$serial','$name','$qty','$qty','$price','$branch','$barcode','$desc','$category','$unit','$reorder','$supplier')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO product(prod_name,unit_id,prod_price,prod_desc,cat_id,prod_qty,current_qty,reorder,supplier_id,branch_id,serial,po,pr,iar,expiry,date_created,batch_no,barcode)
			VALUES('$name','$unit','$price','$desc','$category','$qty','$qty','$reorder','$supplier','$branch','$serial','$po','$pr','$iar','$expire','$dateme','$batch','$barcode')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO product_backup(prod_name,unit_id,prod_price,prod_desc,cat_id,prod_qty,current_qty,reorder,supplier_id,branch_id,serial,po,pr,iar,expiry,date_created,batch_no,barcode)
			VALUES('$name','$unit','$price','$desc','$category','$qty','$qty','$reorder','$supplier','$branch','$serial','$po','$pr','$iar','$expire','$dateme','$batch','$barcode')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO issue_item_supply(price,branch_id_from,description,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,unit_id,batch,pr,po,iar,product_name,data1)
			VALUES('$price','$branch','$desc','$serial','$reorder','$category','$dateme','$supplier','$qty','$id','$unit','$batch','$pr','$po','$iar','$name', '0')") or die(mysqli_error($con));
	mysqli_query($con, "INSERT INTO issue_item_supply_receive(price,branch_id_from,description,serial,reorder,cat_id,date_issue,supplier_id,balance_qty,e_user,unit_id,batch,pr,po,iar,product_name,data1)
			VALUES('$price','$branch','$desc','$serial','$reorder','$category','$dateme','$supplier','$qty','$id','$unit','$batch','$pr','$po','$iar','$name', '0')") or die(mysqli_error($con));
}

if ($prod == 'new_prod') {
	echo "<script type='text/javascript'>alert('Successfully added new product!');</script>";
	echo "<script>document.location='product.php'</script>";
} else if ($prod == 'new_item') {
	echo "<script type='text/javascript'>alert('New item added!');</script>";
	echo "<script>document.location='viewall.php?id=$serial'</script>";
}
