<?php
	session_start();
	include_once("../dist/includes/dbcon.php");

	$branch = $_SESSION['branch'];
	$user = $_SESSION['id'];

	$issue_to_patient_name = $_SESSION['issue_to_patient_name'] ?? '';

	if($issue_to_patient_name != '') {
		$c = mysqli_query($con, "SELECT * FROM temp_trans_patient_phar where  branch_id_from='$branch' and e_user='$user'");
		//$rows[]=array();

		foreach ($c as $row1) : {
			$prod = $row1['prod_id'];
			$qty = $row1['qty'];
			$price = $row1['price'];
			$from = $row1['branch_id_from'];
			$to = $row1['branch_id_to'];
			$desc = $row1['description'];
			$serial = $row1['serial'];
			$reorder = $row1['reorder'];
			$cat = $row1['cat_id'];
			$initial = $row1['initial_qty'];
			$issues = $row1['date_issue'];
			$supp = $row1['supplier_id'];
			$bal = $row1['balance_qty'];
			$euser = $row1['e_user'];
			$toname = $row1['branch_id_toname'];
			$unit = $row1['unit_id'];
			$batch = $row1['batch'];
			$pr = $row1['pr'];
			$po = $row1['po'];
			$iar = $row1['iar'];
			$expiry = $row1['expiry'];
			$product = $row1['product_name'];
			$ris = $row1['ris'];
			$rec = $row1['rec_qty'];
			$receive = $row1['branch_receive'];
			$bar = $row1['data1'];

			// mysqli_query($con, "INSERT INTO issue_item_issuance(prod_id,price,qty,branch_id,branch_id_to,description,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,ris,rec_qty,branch_receive,data1) VALUES ('$prod','$price','$qty','$from','$to','$desc','$serial','$reorder','$cat','$initial','$issues','$supp','$bal','$euser','$toname','$unit','$batch','$pr','$po','$iar','$expiry','$product','$ris','$rec','$receive','$bar')") or die(mysqli_error($con));
			// mysqli_query($con, "INSERT INTO issue_item_general(prod_id,price,qty,branch_id,branch_id_to,description,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,ris,rec_qty,branch_receive,data1) VALUES ('$prod','$price','$qty','$from','$to','$desc','$serial','$reorder','$cat','$initial','$issues','$supp','$bal','$euser','$toname','$unit','$batch','$pr','$po','$iar','$expiry','$product','$ris','$rec','$receive','$bar')") or die(mysqli_error($con));
			// mysqli_query($con, "INSERT INTO issue_details(prod_id,price,qty,branch_id_from,branch_id_to,description,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,ris,rec_qty,branch_receive,data1) VALUES ('$prod','$price','$qty','$from','$to','$desc','$serial','$reorder','$cat','$initial','$issues','$supp','$bal','$euser','$toname','$unit','$batch','$pr','$po','$iar','$expiry','$product','$ris','$rec','$receive','$bar')") or die(mysqli_error($con));
			

			// ****************************************************************************
			// ************************* to issuances_wards table *************************
			// ****************************************************************************
			//temporary reference number
			$temp_reference_number = $branch. '-' . time();
			$issueDate = date('Y-m-d H:i:s', time());

			// kaloy 2022-08-07
			// previous stock qty ================================================
			$prev_stock_qty = 0;
			$csq = mysqli_query($con,"
				SELECT qty FROM qty_ward WHERE prod_id=$prod AND branch_id=$branch
			");
			foreach($csq as $r) { $prev_stock_qty = $r['qty'] + $qty; }
			// /previous stock qty ================================================

			mysqli_query($con, 
				"INSERT INTO issuances_wards(
					temp_reference_no,
					patient_name,
					prev_stock_qty,
					qty,
					prod_id,
					serial,
					prod_name,
					description,
					price,
					cat_id,
					unit_id,
					branch_id_from,
					issued_by_id,
					issue_date
				) 
				VALUES(
					'$temp_reference_number',
					'$issue_to_patient_name',
					$prev_stock_qty,
					$qty,
					'$prod',
					'$serial',
					'$product',
					'$desc',
					$price,
					$cat,
					$unit,
					'$branch',
					$user,
					'$issueDate'
				)"
			) or die(mysqli_error($con));
			// ****************************************************************************
			// ************************* /to issuances_wards table ************************
			// ****************************************************************************

			
			// ************************* quantity adjustment on qty_ward table *************************
			// currently using serial instead of product id.. (test purposes)
			// use branch_id also for additonal conditional parameter so that we can identify 
			// which branch is the source in case we put all ward item inventory in qty_ward table

			// commented out to avoid double deduct in qty_ward
			// mysqli_query($con, 
			// 	"UPDATE qty_ward
			// 		SET qty=qty-$qty 
			// 	WHERE serial='$serial' AND branch_id=$branch"
			// ) or die(mysqli_error($con));

		}
		endforeach;

		// mysqli_query($con,"INSERT into issue_details Select * from temp_trans where branch_id_from='$branch' and e_user='$user'");
		mysqli_query($con, "DELETE FROM temp_trans_patient_phar WHERE branch_id_from ='$branch' and e_user='$user'");

		mysqli_close($con);

		$_SESSION['issue_to_patient_name'] = '';

		echo "
			<script>document.location='reciept_patient.php?temp_reference_no=$temp_reference_number&issue_to_patient_name=$issue_to_patient_name'</script>
		";
	} else {
		echo "<script>alert('No patient specified!');document.location='patient_select.php'</script>";
	}
	?>