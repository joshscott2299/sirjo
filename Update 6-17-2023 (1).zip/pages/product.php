<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Product | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  
  <!-- carlo -->
  <!-- <link rel="stylesheet" href="../dist/sweet/jquery.sweet-modal.min.css"> -->
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-<?php echo $_SESSION['skin']; ?> layout-top-nav">
  <!-- Jonathan Juguilon updated march 15 2020 improvement of design -->
  <div class="wrapper">
    <?php include('../dist/includes/header.php'); ?>

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="responsive">
        <!-- Content Header (Page header) -->

        <!-- Main content -->
        <section class="content">
          <div class="row">

            <div class="col-md-12">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">Product List</h3>
                </div>

                <div class="box-header">
                  <!-- ADD BUTTON -->
                  <a class="btn btn-lg btn-success ml-8" href="#add" data-target="#add" data-toggle="modal" data-backdrop="static" data-keyboard="true">Add New Item</a>
                </div>

                <div class="box-body">


                  <div class="container pb-8">
                    <span class="loaderprod">
                      <center><img src='../dist/img/load.gif' style="width:150px;height:150px" /></center>
                    </span>
                  </div>

                  <div class="col-lg-12">


                    <table id="tbl_products" class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>Barcode</th>
                          <th>Stock #</th>
                          <th>Item Name</th>
                          <th>Current Stock</th>
                          <th>Initial Stock</th>
                          <th>Supplier</th>
                          <th>Unit Cost</th>
                          <th>Category</th>
                         <!-- <th><center>Rack#</center></th>-->
                          <th>Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                      <!--<tfoot>
                        <tr>
                          <th>Barcode</th>
                          <th>Stock #</th>
                          <th>Item Name</th>
                          <th>Current Stock</th>
                          <th>Initial Stock</th>
                          <th>Supplier</th>
                          <th>Unit Cost</th>
                          <th>Category</th>
                          <th>Reorder level</th>
                          <th>Action</th>
                        </tr>
                      </tfoot>-->
                  </div>

                </div><!-- /.box-body -->

              </div><!-- /.col -->


            </div><!-- /.row -->


        </section><!-- /.content -->

      </div><!-- /.container -->
    </div><!-- /.content-wrapper -->
  </div><!-- ./wrapper -->
  <!-- WWWWWWWWWWWRRRRRRRRRRRRRRRRAAAAAAAAAAAAAAAAAPPPPPPPPPPPPPPPPPPPEEEEEEEEEEEEEEEEEEEEERRRRRRRRRRRRRR -->





  <!-- /////////////////// MODAL FORMS //////////////////////////// -->

  <!-- Update Modal -->
  <div id="mod_update" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
      <div class="modal-content" style="height:auto">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Update Item Details</h4>
        </div>
        <div class="modal-body">

          <!-- FORM UPDATE -->
          <form class="form-horizontal" method="post" action="update_item.php" enctype='multipart/form-data' id="frm_add">
            <input type="hidden" class="form-control" id="id" name="id" value="" required>
            <div class="form-group">
              <label class="control-label col-lg-3" for="barcode">Barcode #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="barcode" name="barcode">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="serial">Stock #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="serial" name="serial">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="prod_name">Product Name</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="prod_name" name="prod_name" required>
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3" for="desc">Description</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="desc" name="desc">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="current">Current Qty</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="current_qty" name="current" disabled>
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="initial">Initial Qty</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="initial_qty" name="initial" disabled>
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3" for="prod_price">Price</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="prod_price" name="prod_price">
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3">Category</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="category" id="category">
                  <!-- <option id="category" value=""></option> -->
                  <?php

                  $queryc = mysqli_query($con, "select * from category order by cat_name") or die(mysqli_error($con));
                  while ($rowc = mysqli_fetch_array($queryc)) {
                    ?>
                    <option value="<?php echo $rowc['cat_id']; ?>"><?php echo $rowc['cat_name']; ?></option>
                  <?php } ?>
                </select>
              </div><!-- /.input group -->
              <br><br>
            </div><!-- /.form group -->
            
             
           <!-- <div class="form-group">
              <label class="control-label col-lg-3">Location</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="location" id="location">
                  <!-- <option id="location" value=""></option> -->
              <!-- <?php

                  $queryc = mysqli_query($con, "select * from location order by location_name") or die(mysqli_error($con));
                  while ($rowc = mysqli_fetch_array($queryc)) {
                    ?>
                    <option value="<?php echo $rowc['location_id']; ?>"><?php echo $rowc['location_name']; ?></option>
                  <?php } ?>
                </select>
              </div><!-- /.input group -->
              <br><br>
            </div><!-- /.form group -->
            
            <!--<div class="form-group">
              <label class="control-label col-lg-3" for="price">Reorder</label>
              <div class="col-lg-9">
                <input type="number" class="form-control" id="reorder" name="reorder">
              </div>
              <br><br>
            </div>-->
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save Changes</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>

    </div>
    <!--end of modal-dialog-->
  </div>
  <!--End of Update Modal-->
  


  <!-- ADD MODAL FORM -->
  <div id="add" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
      <div class="modal-content" style="height:auto">
        <div class="modal-header bg-primary">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Add New Item</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" method="post" action="product_add.php" enctype='multipart/form-data'>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price">RIS #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="batch" placeholder="RIS No.">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price">P.O #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="po" placeholder="Purchase Order No.">
              </div>
              <br><br>
            </div>
            <!--<div class="form-group">
              <label class="control-label col-lg-3" for="price">P.R #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="pr" placeholder="Purchase Request No.">
              </div>
              <br><br>
            </div>-->
            <div class="form-group">
              <label class="control-label col-lg-3" for="price">PR #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="iar" placeholder="Purchase Reqquest No.">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price1">Barcode #</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price1" name="barcode" placeholder="Barcode no.">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price2">Stock #</label>
              <div class="col-lg-9">
                <input id="stockno" type="text" class="form-control" name="serial" placeholder="Stock no." required>
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3" for="price">Item Name</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="item" placeholder="Item Name" required>
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price">Product Description</label>
              <div class="col-lg-9">
                <textarea class="form-control" id="price" name="prod_desc" placeholder="Product Description"></textarea>
              </div>
              <br><br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3">Unit</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="unit">

                  <?php

                  $queryc = mysqli_query($con, "select * from unit_measure order by unit_name") or die(mysqli_error($con));
                  while ($rowc = mysqli_fetch_array($queryc)) {
                    ?>
                    <option value="<?php echo $rowc['unit_id']; ?>"><?php echo $rowc['unit_name']; ?></option>
                  <?php } ?>
                </select>
              </div><!-- /.input group -->
              <br><br>
            </div><!-- /.form group -->
            <div class="form-group">
              <label class="control-label col-lg-3" for="file">Supplier</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="supplier">
                  <?php

                  $query2 = mysqli_query($con, "select * from supplier") or die(mysqli_error($con));
                  while ($row2 = mysqli_fetch_array($query2)) {
                    ?>
                    <option value="<?php echo $row2['supplier_id']; ?>"><?php echo $row2['supplier_name']; ?></option>
                  <?php } ?>
                </select>
              </div>
              <br><br>
            </div>
            <div class="form-group">
              <label class="control-label col-lg-3" for="price">Qty</label>
              <div class="col-lg-9">
                <input type="number" class="form-control" id="price" name="qty" placeholder="Quantity" required>
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3" for="price">Price</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="prod_price" placeholder="Product Price">
              </div>
              <br><br>
            </div>

            <div class="form-group">
              <label class="control-label col-lg-3">Category</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="category">

                  <?php

                  $queryc = mysqli_query($con, "select * from category order by cat_name") or die(mysqli_error($con));
                  while ($rowc = mysqli_fetch_array($queryc)) {
                    ?>
                    <option value="<?php echo $rowc['cat_id']; ?>"><?php echo $rowc['cat_name']; ?></option>
                  <?php } ?>
                </select>

              </div>
			  <br></br>
            
           <!--   <div class="form-group">
              <label class="control-label col-lg-3">Location</label>
              <div class="col-lg-9">
                <select class="form-control select2" style="width: 100%;" name="location">

                  <?php

                  $queryc = mysqli_query($con, "select * from location order by location_name") or die(mysqli_error($con));
                  while ($rowc = mysqli_fetch_array($queryc)) {
                    ?>
                    <option value="<?php echo $rowc['location_id']; ?>"><?php echo $rowc['location_name']; ?></option>
                  <?php } ?>
                </select>

              </div>-->
			   
            
            
            <div class="form-group">
              </br>
              <label class="control-label col-lg-3" for="price">Date Expire</br>(yyyy-mm-dd)</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="expire" placeholder="yyyy-mm-dd">
              </div>
              <br><br>
            </div>
            <div class="form-group">
              </br>
              <label class="control-label col-lg-3" for="price">Date Created</br>(yyyy-mm-dd)</label>
              <div class="col-lg-9">
                <input type="text" class="form-control" id="price" name="dateme" value="<?php echo date("Y-m-d"); ?>">
              </div>
              <br><br>
            </div>


        </div>
        <div class="modal-footer">
          <button id="save_item" type="submit" class="btn btn-primary">Save Item</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>

      </div>

    </div>
    <!--end of modal-dialog-->
  </div>

  <!-- //////////////////////////////////////// MODAL FORMS /////////////////////////////////////// -->





  <!-- /////////////////////////////////////////////////////////////////////////////// -->

  <!-- SCRIPTS -->

  <!-- /////////////////////////////////////////////////////////////////////////////// -->

  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>

  <!-- carlo -->
  <!-- <script src="../dist/sweet/jquery.sweet-modal.min.js"></script> -->



  <script type="text/javascript">
    $('#price1').keydown(function(e) {
      if (e.keyCode == 13) { // barcode scanned!
        $('#price2').focus();
        return false; // block form from being submitted yet
      }
    });


    $(function() {
      // $("#example1").DataTable();

      // $('#example2').DataTable({
      //   "paging": true,
      //   "lengthChange": false,
      //   "searching": false,
      //   "ordering": true,
      //   "info": true,
      //   "autoWidth": false
      // });


    }); ///////////////////////////



    // ====================  document.ready ==========================
    $(document).ready(function() {

 
      $("#tbl_products").DataTable({
        ajax: {
          url: "product_all.php"
        },

        columns: [{
            data: 'barcode'
          },
          {
            data: 'serial'
          },
          {
            data: 'item_with_description'
          },
          {
            data: 'qty'
          },
          {
            data: 'initial'
          },
          {
            data: 'supplier_name'
          },
          {
            data: 'price'
          },
          {
            data: 'cat_name'
          },
         // {
         //   data: 'location_name'
        //  },
         
          {
            data: 'action'
          }
        ],
        initComplete: function(settings, json) {
          $('.loaderprod').hide();


          // ========================= Jonathan (May 06, 2022 - Friday) =======================
          // This will fire whenever we click the small edit-item action button
          $("#tbl_products").on("click", "tbody tr td a#btn_edit", function(e) {
            e.preventDefault();
            var pid = $(this).attr('pid');
            $.ajax({
              method: 'GET',
              url: 'product_edit.php?id=' + pid,
              success: function(result) {
                var prod = JSON.parse(result);
                $('#id').val(pid);
                $('#barcode').val(prod.barcode);
                $('#serial').val(prod.serial);
                $('#prod_name').val(prod.item);
                $('#desc').val(prod.description);
                $('#current_qty').val(prod.qty);
                $('#initial_qty').val(prod.initial);
                $('#prod_price').val(prod.price);
                $('#category option[value=' + prod.cat_id + ']')
                  .prop('selected', true);
                $('#reorder').val(prod.reorder);
              }
            });
          });


        },
        order: [2, 'asc'],
        columnDefs: [{
            "width": "30%",
            "targets": 2
          },
          {
            "width": "10%",
            "targets": 7
          }
        ],
        deferRender: true // set to true for faster loading of data
      });
  


      $("#stockno").on("keyup", function() {
        // $(this).preventDefault();
        var sn = $(this).val();
        if (!(sn=='')) {
          $.ajax({
            type: "post",
            url: "product_add_check_stockno.php",
            data: {
              "serial": sn
            },
            success: function(result) {
              var res = JSON.parse(result);
              if (res.response == "existing") {
                
                alert('The stock number already exists!');
                // $.sweetModal('Stock number already exists!');
                $("#stockno").focus();
                $("#stockno").val('');
                
              } else {
                
              }
            }
          });
        }
      });


    }); // ==================== end of document.ready ==========================
  </script>

</body>

</html>