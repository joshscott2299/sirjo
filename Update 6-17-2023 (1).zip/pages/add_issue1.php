<?php
session_start();
include("../dist/includes/dbcon.php");

$branch=$_SESSION['branch'];

$issue = $_POST['branch_name'];


  $query1=mysqli_query($con,"SELECT prod_id,price,qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty FROM temp_trans where branch_id_from='$branch'")or die(mysqli_error());


if $result = $mysqli_query($con,$query1){
	
	while ($row = $result->fetch_row()){
			 
			$query2 = $mysqli->query($con,"SELECT * FROM product_dept where prod_id = '$row[prod_id]' and branch_receive='$issue'");
			
			if ($mysqli_num_rows(query2) > 0)
			{
				$update1 = "UPDATE product_dept set qty = qty + 'row[qty]', current_qty = current_qty + 'row[qty]' where branch_receive='$issue'";
				$queryupdate1 = $mysqli-$mysql_db_query($update1);
			}
			else
			{
				$insert1 = "INSERT INTO product_dept(prod_id,price,qty,current_qty,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty)VALUES('$row[prod_id]', '$row[price]', '$row[qty]', '$row[branch_id_from]', '$row[description]', '$row[branch_id_to]', '$row[serial]', '$row[reorder]', '$row[cat_id]', '$row[initial_qty]', '$row[date_issue]', '$row[supplier_id]', '$row[balance_qty]')";
				$queryinsert1 = $mysqli->$mysql_db_query($insert1);
			}
	}
	$mysqli->close();
}
	$mysqli->close();
	
	 mysqli_query($con,"DELETE FROM temp_trans_mms WHERE branch_id_from ='$branch' and e_user='$user'");
	
echo "<script>document.location='home.php'</script>";  
?>