<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Inventory Report | <?php include_once('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <style type="text/css">
    h5,
    h6 {
      text-align: center;
    }

    @media print {
      .btn-print {
        display: none !important;
      }
      .btn-default {
        display: none !important;
      }
      .main-footer {
        display: none !important;
      }
      .main-title {
        display: none !important;
      }
      .box.box-primary {
        border-top: none !important;
      }
      body * {
        visibility: hidden;
      }
      #printSection,
      #printSection * {
        visibility: visible;
      }
      #printSection {
        position: absolute;
        left: 0;
        top: 0;
      }
    }

    @media screen {
      #printSection {
        display: none;
      }
    }

  </style>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-<?php echo $_SESSION['skin']; ?> layout-top-nav">
  <div class="wrapper">
    <?php
    include_once('../dist/includes/header.php');
    include_once('../dist/includes/dbcon.php');
    $branch = $_SESSION['branch'];
    // $issued_by_id = $_SESSION['id'];
    ?>
    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="container">
        <!-- Content Header (Page header) -->

        <!-- Main content -->
        <section class="responsive">
          <div class="row">
            <div class="col-md-12">
              <br>
              <div class="box box-primary">
                <div class="box-header">
                  <div class="box-title">
                    <h4>Ward Returns</h4>
                    <?php //print_r($_SESSION) ?>
                    <!-- <br> -->
                    <?php //print_r($_GET) ?>
                  </div>
                  <div class="pull-right print">
                    <select id="catList" class="btn btn-default">
                      <option value="0">All Department</option>
                      <?php
                      $cat = mysqli_query($con, "
                      Select * 
                        from branch 
                        where category_dept='2' ");

                      while ($catrow = mysqli_fetch_array($cat)) {
                        $catid = isset($_GET['categorys']) ? $_GET['categorys'] : 0;
                        $selected = ($catid == $catrow['branch_id']) ? " selected" : "";
                        echo "<option$selected value=" . $catrow['branch_id'] . ">" . $catrow['branch_name'] . "</option>";
                      }
                      ?>
                    </select>
                  </div>
                </div>
                
                <?php
                  $q = mysqli_query($con, 
                  "select * from itemreturn_head 
                  where status='Pending'");
                  $pendingCount = mysqli_num_rows($q);

                  $q = mysqli_query($con, 
                  "select * from itemreturn_head 
                  where status='Confirmed'");
                  $confirmedCount = mysqli_num_rows($q);

                  $q = mysqli_query($con, 
                  "select * from itemreturn_head 
                  where status='Received'");
                  $releasedCount = mysqli_num_rows($q);

                  $q = mysqli_query($con, 
                  "select * from itemreturn_head 
                  where status='Declined'");
                  $declinedCount = mysqli_num_rows($q);
                ?>

                <div class="box-body">
                  <div class="tabpanel">
                    <ul class="nav nav-tabs">
                      <li class="active"><a href="#pending">New Return(s)
                        <span class="label label-default"><?php echo $pendingCount; ?></span>
                      </a></li>
                      <li><a href="#confirmed">Checked / Received 
                       <span class="label label-default"><?php echo $confirmedCount; ?></span>
                      </a></li>
                      <li><a href="#received">Received 
                      <span class="label label-default"><?php echo $releasedCount; ?></span>
                      </a></li>
                      <li><a href="#declined">Declined 
                      <span class="label label-default"><?php echo $declinedCount; ?></span>
                      </a></li>
                    </ul>

                    <div class="tab-content" style="padding:14px;">
                      <div id="pending" class="tab-pane fade in active">
                        <?php include('ward_ret_pending.php'); ?>
                      </div>
                      <div id="confirmed" class="tab-pane fade in">
                        <?php include('ward_ret_confirmed.php'); ?>
                      </div>
                      <div id="received" class="tab-pane fade in">
                        <?php include('ward_ret_released.php'); ?>
                      </div>
                      <div id="declined" class="tab-pane fade in">
                        <?php include('ward_ret_declined.php'); ?>
                      </div>
                    </div>
                  </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

        </section><!-- /.content -->
      </div><!-- /.container -->
    </div><!-- /.content-wrapper -->
  </div><!-- ./wrapper -->
  <br>
  <!-- MODALS ************************************* -->
  <?php
    include_once('ward_ret_view_modal.php');
    include_once('ward_ret_view_printable_modal.php');
    include_once('ward_ret_view_released_modal.php');
    include_once('ward_ret_view_declined_modal.php');
  ?>
  <br>
  <!-- /MODALS ************************************* -->
  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <!-- SlimScroll -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <!-- <script src="../dist/js/demo.js"></script> -->
  <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- printThisJS -->
  <script src="../dist/js/printThis.js"></script>
  <!-- alpinejs -->
  <script src="../dist/js/alpine.min.js" defer></script>

  <script>
    function printElement(selector) {
      try {
        // let elem = window.document.getElementById(selector);
        let elem = window.document.querySelector(selector);
        let domClone = elem.cloneNode(true);
        let $printSection = window.document.getElementById('printSection');
  
        if(!$printSection) {
          let $printSection = window.document.createElement("div");
          $printSection.id = "printSection";
          window.document.body.appendChild($printSection);
        }
          
          $printSection.innerHTML = "";
          $printSection.appendChild(domClone);
          window.print();
      } catch (error) {
        console.log(error);
      }
    }


    $(function(){
      let hash = location.hash.replace(/^#/, '');
      if(hash){
        $('.nav-tabs a[href="#' + hash + '"]').tab('show');
      }
      $('.nav-tabs a').on('shown.bs.tab', function(e){
        window.location.hash = e.target.hash;
      });

      $("#catList").on('change', function() {
        if ($(this).val() == 0) {
          window.location = 'ward_return.php';
        } else {
          window.location = 'ward_return.php?categorys=' + $(this).val();
        }
      });

      $(".nav-tabs a").click(function() {
        $(this).tab('show');
      });

    })

    $('#PendingTable').dataTable({
      "bLengthChange": true,
      "bInfo": true,
      "bSort": false,
      "bFilter": true
    });

    $('#ConfirmedTable').dataTable({
      "bLengthChange": true,
      "bInfo": true,
      "bSort": false,
      "bFilter": true
    });
    $('#ReleasedTable').dataTable({
      "bLengthChange": true,
      "bInfo": true,
      "bSort": false,
      "bFilter": true
    });
    $('#DeclinedTable').dataTable({
      "bLengthChange": true,
      "bInfo": true,
      "bSort": false,
      "bFilter": true
    });
    
  
  </script>
</body>

</html>