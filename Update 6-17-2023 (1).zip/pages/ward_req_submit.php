<?php
session_start();
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$request = $_POST ?? [];
$request = json_decode(json_encode($request));

$issued_by_id = intval($_SESSION['id']);

// session_register('branch_to', $request->request_from_branch_id);
// session_register('ris', $request->ris);
$_SESSION['branch_to'] = $request->request_from_branch_id;
$_SESSION['ris'] = $request->ris;

// echo json_encode($request);

// die();

$response = [];

// check if RIS already exists...
// $query = mysqli_query(
//   $con,
//   "select * from itemrequests_head
//   where ris='$request->ris' LIMIT 1;
//   "
// );

// if(mysqli_num_rows($query) > 0) {
//   $response['success']=false;
//   $response['message']='RIS already exists. Please use another one.';
//   echo json_encode($response);
//   return;
// } else {
  
// }



// *********************************************************************
$dateToday = date('Y-m-d H:i:s', time());

mysqli_query(
  $con,
  "
  UPDATE itemrequests_head SET
    ris='$request->ris',
    issue_date='$dateToday',
    issued_by_id='$issued_by_id',
    status='$request->status',
    remarks='$request->remarks'
  WHERE itemrequests_head_id=$request->itemrequests_head_id
  "
);
foreach($request->items as $item) {
  $remarks = $item->remarks;
  // if($remarks=='' || null) {
  //   $remarks = 'N/A';
  //   // if($item->qty_issued < $item->qty && $item->qty_issued>1) {
  //   //   $remarks='Item issued (Lacking)';
  //   // } else if ($item->qty_issued >= $item->qty && $item->qty_issued>1) {
  //   //   $remarks='Item issued (Complete)';
  //   // } else {
  //   //   $remarks='No item issued';
  //   // }
  // }

  mysqli_query($con,
    "
    UPDATE itemrequests_line SET
      ris='$request->ris',
      qty_issued='$item->qty_issued',
      remarks='$remarks'
    WHERE prod_id='$item->prod_id' AND itemrequests_head_id=$request->itemrequests_head_id
    "
  );

  process1($con, $request, $item);

}

// **************************** PROCESS 1 *********************************
function process1($con, $request, $tempItem) {
  $id=$_SESSION['id'];
  $branch=$request->request_to_branch_id;
  $name = $tempItem->prod_id;
  $qty = $tempItem->qty_issued;
  $issue = $request->request_from_branch_id;
  $ris = $request->ris;
  $dates = date('Y-m-d H:i:s', time());
  $to_branch = $request->request_from;

  if(intval($qty) < 1) {
    return;
  }
    
  $query=mysqli_query($con,
    "select serial,batch,item,qty,initial,price,barcode,description,cat_id,unit_id,
    reorder,supplier_id from qty_general where ID='$name'") 
    or die(mysqli_error($con));
  $row=mysqli_fetch_array($query);
  $serial=$row['serial'];
  $item=$row['item'];
  $qty1=$row['qty'];
  $price=$row['price'];
  $desc=$row['description'];
  $cat=$row['cat_id'];
  $unit=$row['unit_id'];
  $reorder=$row['reorder'];
  $supp=$row['supplier_id'];
  $batch=$row['batch'];

  mysqli_query($con,
    "UPDATE qty_general 
    SET qty=qty-'$qty' where ID='$name' and branch_id='$branch'"
  ) 
  or die(mysqli_error($con)); 

  mysqli_query($con,
    "INSERT INTO temp_trans_mms(
      prod_id,qty,price,branch_id_from,description,branch_id_to,serial,
      reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,
      e_user,branch_id_toname,unit_id,batch,product_name,ris,rec_qty,branch_receive
    ) VALUES(
      '$name','$qty','$price','$branch','$desc','$issue','$serial','$reorder',
      '$cat','0','$dates','$supp','$qty1','$id','$to_branch','$unit','$batch',
      '$item','$ris','$qty','$issue'
    )"
    ) 
    or die(mysqli_error($con));

  // ======================= to qty_ward =========================
  $q = mysqli_query($con,"
      select serial, branch_id from qty_ward
      where serial='$serial' and branch_id=$issue
  ") or die(mysqli_error($con));

  if(mysqli_num_rows($q) > 0) {
    // if item already exists in qty_ward, just update its qty
    mysqli_query($con, 
    "
      update qty_ward
      set qty=qty+$qty 
      where serial='$serial' and branch_id=$issue
    ") or die(mysqli_error($con));
  } else {
    // if item does not yet exists in qty_ward, add the item and set its initial qty also
    mysqli_query($con, 
    "
      insert into qty_ward(
        prod_id,serial,item,qty,initial,branch_id,cat_id,unit_id,description,price,supplier_id
      )
      values(
        $tempItem->prod_id,'$serial','$item',$qty,$qty,$issue,$cat,$unit,'$desc',$price,$branch
      )
    ") or die(mysqli_error($con));
  }
  // ======================= to /qty_ward =========================
}
// ********************** /PROCESS 1 ************************************************

// echo "<script>document.location='ward_req_add_issue.php'</script>";

// header('location:ward_req_add_issue.php');

include('ward_req_add_issue.php');
include('ward_req_add_issue_process.php');


$response['success']=true;
$response['message']='Successful';

echo json_encode($response);

// *********************************************************************
