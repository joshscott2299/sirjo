<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Product | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
   
   
   
   
  <!-- Font Awesome -->
 
 
 

 </head>
 
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">

    <div class="wrapper">
      <?php include('../dist/includes/header.php');?>
       <?php
  error_reporting(E_ALL); ini_set('display_errors', 1);
  include('Main.php');
  $main = new Main();
  $data = $_REQUEST;

 
  
  $expiredResult = $main->showExpired($data);
  $expired = $expiredResult[0];
  $no = $expiredResult[1];


  
  
 ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">
          <!-- Content Header (Page header) -->
        

          <!-- Main content -->
          <section class="content">
            <div class="row">
       
            		<form action="" method="GET">
			<table class="table" style="background-color:white;">
				<tr>
				
					<td style="width:100px;">
						
						<input type="text" name="from" value="<?=isset($data['from']) ? $data['from'] : '' ?>" class="datepicker form-control input-sm input-sm" id="datepicker" placeholder="From" />
					</td>
					<td style="width:100px;"><input type="text" name="to"  value="<?=isset($data['to']) ? $data['to'] : '' ?>" class="datepicker form-control input-sm input-sm"  id="datepicker1" placeholder="To" /></td>
					<td>
						<input type="text" name="serial" value="<?=isset($data['to']) ? $data['serial'] : '' ?>" class="form-control input-sm input-sm" placeholder="Barcode"/>
					</td>
					
					<td>
						<button type="submit" title="Search" class="btn btn-default btn-sm"><i class="glyphicon glyphicon-search"></i></button> 
						
					</td>
					
				</tr>
				
			</table>
	</form>		
            <div class="col-xs-12">
              <div class="box box-primary">
    
                <div class="box-header">
                  <h3 class="box-title">Item's Status&nbsp;<a href="xpire.php"><button title="Refresh" class="btn btn-default btn-sm"><i class="glyphicon glyphicon-refresh"></i></button></a>
			</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                       
                  <th>Barcode</th>
                  <th>Item</th>
                  <th>Qty</th>
                  <th>Description</th>
          <th>Days Remaining</th>
          <th>Expiration</th>
                      </tr>
                    </thead>
                    <tbody>
          
            <?php foreach($expired as $row): 
          
          
          $today = date('Y-m-d');
          $date1=date_create($today);
          $date2=date_create($row['expiry']);
          $days_remaining=date_diff($date1,$date2);
        ?>
        
          <tr style="<?=($row['expiry'] <= date('Y-m-d')) ? 'background-color:rgba(255, 0, 0, 0.68);' : 'background-color:orange;'?>">
          
            <td><?=$row['serial']?></td>
            <td><?=$row['prod_name']?></td>
            <td><?=$row['prod_qty']?></td>
            <td><?=$row['prod_desc']?></td>
            <td>
              <?=$days_remaining->format("%R%a days")?>
            </td>
            <td>
              <?=$row['expiry']?></td>
          </tr>
        <?php endforeach; ?>
 
                    </tbody>
                    <tfoot>
                      <tr>
                       
                  <th>Barcode</th>
                  <th>Item</th>
                  <th>Qty</th>
                  <th>Description</th>
          <th>Days Remaining</th>
          <th>Expiration</th>
                      </tr>           
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
      
      
          </div><!-- /.row -->
    
            
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

 <!--end of modal--> 
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    
	
  <!-- Bootstrap 3.3.6 -->
 
  <!-- Select2 -->
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- InputMask -->
  <script src="../plugins/input-mask/jquery.inputmask.js"></script>
  <script src="../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
  <script src="../plugins/input-mask/jquery.inputmask.extensions.js"></script>
  <!-- date-range-picker -->
  
  <script src="../plugins/daterangepicker/daterangepicker.js"></script>
  <!-- bootstrap datepicker -->
  <script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
  <!-- bootstrap color picker -->
  <script src="../plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
  <!-- bootstrap time picker -->
  <script src="../plugins/timepicker/bootstrap-timepicker.min.js"></script>
  <!-- SlimScroll 1.3.0 -->
  <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
  <!-- iCheck 1.0.1 -->
  <script src="../plugins/iCheck/icheck.min.js"></script>
  <!-- FastClick -->
  <script src="../plugins/fastclick/fastclick.js"></script>
 
  
	
	
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
		
		 //Datemask mm/dd/yyyy
    $("#datemask").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
	
	 //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });
	 //Date picker
    $('#datepicker1').datepicker({
      autoclose: true
    });
      });
	  
    </script>
  </body>
</html>
