<div x-data>
  <?php
  $where = "";
  $catid = $_GET['categorys'] ?? 0;
  // echo $catid;
  if ($catid == 0) {
    $where = " WHERE ";
  } else {
    $where = " WHERE i.request_from_branch_id = $catid AND ";
    }

  $requests_query = mysqli_query($con, "
                        SELECT 
                          i.*,
                          b.branch_id, b.branch_name
                        FROM itemreturn_head i 
                        LEFT JOIN branch b ON b.branch_id=i.request_from_branch_id 
                        $where i.status='Confirmed' ORDER BY i.issue_date DESC" );
  ?>

  <table width="100%" class="table table-bordered table-hover" id="ConfirmedTable">
    <thead>
      <tr>
        <th>ID</th>
        <th>Date Requested</th>
        <th>Date Issued</th>
        <th>RIS NO.</th>
        <th>Request From</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = mysqli_fetch_array($requests_query)): ?>
        <tr>
          <td><?php echo $row['itemreturn_head_id'] ; ?></td>
          <td><?php echo date('M d, Y H:i:s', strtotime($row['request_date'])) ; ?></td>
          <td><?php echo date('M d, Y H:i:s', strtotime($row['issue_date'])) ; ?></td>
          <td><?php echo $row['ris'] ; ?></td>
          <td><?php echo $row['branch_name'] ; ?></td>
          <td>
            <button
              class="btn btn-sm btn-primary"
              data-toggle="modal" data-target="#ward_req_view_printable_modal"
              @click="$dispatch('view-printable-modal',<?php echo $row['itemreturn_head_id']; ?>)">
              View Details
            </button>
            <button
              class="btn btn-sm btn-primary"
              data-toggle="" data-target=""
              @click="',<?php echo ['on-going development for pick up trigger']; ?>)">
              Notify for PICK UP
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
