<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];

include('../dist/includes/dbcon.php');

	$name = $_POST['names'];
	$user = $_POST['user'];
	
	
	  mysqli_query($con,"DELETE FROM temp_requester WHERE requester_name ='$requester'");
	
	
	$query=mysqli_query($con,"select requester_name from requester where requester_id='$name'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);
		
		
		
			mysqli_query($con,"INSERT INTO temp_requester(requester_name) VALUES('$name')")or die(mysqli_error($con));

			
					  echo "<script>document.location='cash_transaction.php'</script>";  
		
?>