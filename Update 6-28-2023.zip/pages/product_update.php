<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

include('../dist/includes/dbcon.php');
	$id = $_POST['id'];
	$name =$_POST['prod_name'];
	$supplier =$_POST['supplier'];
	$price = $_POST['prod_price'];
	$reorder = $_POST['reorder'];
	$category = $_POST['category'];

	$serial = $_POST['serial'];
	$desc = $_POST['desc'];
	$po = $_POST['po'];
	$iar = $_POST['iar'];
	$pr = $_POST['pr'];
	$unit = $_POST['unit'];
	$expiry = $_POST['expiry'];
	
	$batch = $_POST['batch'];
	$barcode = $_POST['barcode'];
			
	mysqli_query($con,"update product set prod_name='$name',prod_price='$price',
	reorder='$reorder',supplier_id='$supplier',cat_id='$category',serial='$serial',prod_desc='$desc',po='$po',pr='$pr',iar='$iar',unit_id='$unit',expiry='$expiry',batch_no='$batch',barcode='$barcode' where prod_id='$id'")or die(mysqli_error($con));
	
	echo "<script type='text/javascript'>alert('Successfully updated Item details!');</script>";
	echo "<script>document.location='product.php'</script>";  

	
?>
