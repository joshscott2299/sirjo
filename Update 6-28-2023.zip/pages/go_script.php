<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];
include('../dist/includes/dbcon.php');


	
	$query2=mysqli_query($con,"select * from temp_trans_mms where branch_id_from='$branch' and e_user='$id'")or die(mysqli_error($con));
	$count=mysqli_num_rows($query2);
	 
		
		if ($count>0)
		{
			echo "<script type='text/javascript'>alert('You have already transaction!');</script>";
			echo "<script>document.location='cash_transaction.php'</script>";  
		}
		
  else {
    
           echo "<script>document.location='cust_new.php'</script>";  
  }
	

?>