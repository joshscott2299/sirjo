<?php 
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];	

include('../dist/includes/dbcon.php');

	date_default_timezone_set('Asia/Manila');
	$date = date("Y-m-d");
	$cid = $_POST['cid'];
	$name = $_POST['prod_name'];
	$qty = $_POST['qty'];
	$issue = $_POST['branch_name'];
	$issues = $_POST['branch_names'];
	$ris = $_POST['ris'];
	$dates = $_POST['dates'];
	
	
	$query4=mysqli_query($con,"select * from temp_dept where branch_from='$branch' and e_user='$id'")or die(mysqli_error());
		$row4=mysqli_fetch_array($query4);
		$to_branch=$row4['branch_to_id'];
		$ris=$row4['ris'];
	
		
			
		$query=mysqli_query($con,"select serial,batch,item,qty,initial,price,barcode,description,cat_id,unit_id,reorder,supplier_id from qty_general where ID='$name'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);
		$serial=$row['serial'];
		$item=$row['item'];
		$qty1=$row['qty'];
		$initial=$row['initial'];
		$price=$row['price'];
		$code=$row['barcode'];
		$desc=$row['description'];
		$cat=$row['cat_id'];
		$unit=$row['unit_id'];
		$reorder=$row['reorder'];
		$supp=$row['supplier_id'];
		$batch=$row['batch'];
	
		
		

		$query3=mysqli_query($con,"select temp_id,branch_to from temp_dept where temp_id='$issue'")or die(mysqli_error());
		$row=mysqli_fetch_array($query3);
		//$to=$row['branch_id'];

		
		$query1=mysqli_query($con,"select * from temp_trans_mms where prod_id='$name' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error());
		$count=mysqli_num_rows($query1);
		
		
		$total=$price*$qty;

		if ($qty1 == 0)
{
?>
<script type="text/javascript">
            alert("No Available Stocks");
          window.location = "cash_transaction.php";           
          </script>
<?php
}
  else if ($qty > $qty1 )
  {
     ?>
            <script type="text/javascript">
            alert("Insufficient stocks!");
            window.location = "cash_transaction.php";           
            </script>
            
<?php
  }
  else if ($qty == 0 )
  {
    ?>
            <script type="text/javascript">
            alert("Enter quantity greater than 0!");
            window.location = "cash_transaction.php";           
            </script>
            
<?php
  }
		
	else if ($count>0){
			mysqli_query($con,"update temp_trans_mms set qty=qty+'$qty', initial_qty=initial_qty+'$qty' where prod_id='$name' and branch_id_from='$branch' and e_user='$id'")or die(mysqli_error());
			mysqli_query($con,"UPDATE qty_general SET qty=qty-'$qty' where ID='$name' and branch_id='$branch'") or die(mysqli_error($con)); 	
	
		}
		else{
			
			mysqli_query($con,"UPDATE qty_general SET qty=qty-'$qty' where ID='$name' and branch_id='$branch'") or die(mysqli_error($con)); 
			mysqli_query($con,
				"INSERT INTO temp_trans_mms(prod_id,qty,price,branch_id_from,description,branch_id_to,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,product_name,ris,rec_qty,branch_receive) VALUES('$name','$qty','$price','$branch','$desc','$issue','$serial','$reorder','$cat','0','$dates','$supp','$qty1','$id','$to_branch','$unit','$batch','$item','$ris','$qty','$issue')")or die(mysqli_error($con));
		}
		


	
		echo "<script>document.location='cash_transaction.php?cid=$cid'</script>";  
	
?>