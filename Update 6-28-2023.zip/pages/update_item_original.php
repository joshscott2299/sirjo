<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

include('../dist/includes/dbcon.php');
	$id = $_POST['id'];
	$name =$_POST['prod_name'];
	$price = $_POST['prod_price'];
	$reorder = $_POST['reorder'];
	$category = $_POST['category'];
	$serial = $_POST['serial'];
	$desc = $_POST['desc'];
	$barcode = $_POST['barcode'];
			
	mysqli_query($con,"update qty_general set item='$name',price='$price',
	reorder='$reorder',cat_id='$category',serial='$serial',description='$desc',barcode='$barcode' where ID='$id'")or die(mysqli_error($con));
	
	echo "<script type='text/javascript'>alert('Successfully updated Item details!');</script>";
	echo "<script>document.location='product.php'</script>";  

	
?>
