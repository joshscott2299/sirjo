<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemreturn_head_id = $_POST['itemreturn_head_id'] ?? 0;
$itemreturn_head_id = htmlspecialchars(trim($itemreturn_head_id));

$remarks = $_POST['remarks'] ?? 'N/A';
$remarks = htmlspecialchars(trim($remarks));

$dateToday = date('Y-m-d H:i:s', time());

mysqli_query(
  $con, "UPDATE itemreturn_head 
    SET status = 'Declined', remarks = '$remarks', decline_date='$dateToday'   
    WHERE itemreturn_head_id=$itemreturn_head_id;"
);
mysqli_query(
  $con, "UPDATE itemreturn_line 
    SET status = 'Declined' 
    WHERE itemreturn_head_id=$itemreturn_head_id;"
);

echo 'Done';
