<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemreturn_head_id = $_GET['itemreturn_head_id'] ?? '';
$itemreturn_head_id = htmlspecialchars(trim($itemreturn_head_id));
$itemreturn_head_id = intval($itemreturn_head_id);

$query = mysqli_query(
  $con,
   "SELECT
      i.*,
      bf.branch_id as bf_branch_id,
      bf.branch_name as bf_branch_name,
      bt.branch_id as bt_branch_id,
      bt.branch_name as bt_branch_name,
      ureq.user_id, ureq.name as ureq_name,
      urec.user_id, urec.name as urec_name,
      uiss.user_id, uiss.name as uiss_name
    FROM itemreturn_head i 
    LEFT JOIN branch bf ON bf.branch_id=i.request_from_branch_id 
    LEFT JOIN branch bt ON bt.branch_id=i.request_to_branch_id 
    LEFT JOIN user ureq ON ureq.user_id=i.requested_by_id 
    LEFT JOIN user urec ON urec.user_id=i.received_by_id 
    LEFT JOIN user uiss ON uiss.user_id=i.issued_by_id 
    WHERE i.itemreturn_head_id = $itemreturn_head_id 
    LIMIT 1
  "
) or die(mysqli_error($con));

$item_query = mysqli_query($con,
 "SELECT 
    -- i.ris, 
    -- i.prod_id, 
    -- i.qty, 
    -- i.serial, 
    -- i.qty_issued, 
    -- i.remarks,
    --  
    i.*,
    -- 
    q.qty_ward_id, 
    q.item, 
    q.unit_id,
    q.cat_id,
    q.qty as remaining_qty,
    -- 
    u.unit_id,
    u.unit_name,
    --  
    c.cat_id,
    c.cat_name 
  FROM itemreturn_line i
  LEFT JOIN qty_ward q ON i.prod_id=q.qty_ward_id
  LEFT JOIN unit_measure u ON q.unit_id=u.unit_id
  LEFT JOIN category c ON c.cat_id=q.cat_id
  WHERE i.itemreturn_head_id = $itemreturn_head_id"
);

$res['data'] = null;
$res['data']['items'] = [];

while ($row = mysqli_fetch_array($query)) {
  $res['data']['status'] = $row['status']; 
  $res['data']['request_from'] = $row['bf_branch_name']; 
  $res['data']['request_to'] = $row['bt_branch_name']; 
  $res['data']['request_from_branch_id'] = intval($row['request_from_branch_id']);
  $res['data']['request_to_branch_id'] = intval($row['request_to_branch_id']);
  $res['data']['ris'] = $row['ris'];
  $res['data']['request_date'] = $row['request_date'];
  $res['data']['issue_date'] = $row['issue_date'];
  $res['data']['issued_by'] = $row['uiss_name'];
  $res['data']['issued_by_id'] = intval($row['issued_by_id']);
  $res['data']['received_by'] = $row['urec_name'];
  $res['data']['received_by_id'] = intval($row['received_by_id']);
  $res['data']['requested_by'] = $row['ureq_name'];
  $res['data']['requested_by_id'] = intval($row['requested_by_id']);
  $res['data']['itemreturn_head_id'] = intval($itemreturn_head_id);
}

while($item = mysqli_fetch_array($item_query)) {
  $res['data']['items'][] = [
    'prod_id'=>$item['prod_id'],
    'serial'=>$item['serial'],
    'item'=>$item['item'],
    'unit_id'=>$item['unit_id'],
    'unit_name'=>$item['unit_name'],
    'remaining_qty'=>intval($item['remaining_qty']),
    'qty'=>intval($item['qty']),
    'qty_issued'=>intval($item['qty_issued']),
    'remarks'=>$item['remarks'],
    'itemreturn_head_id'=>intval($itemreturn_head_id),
  ];
}

echo json_encode($res);