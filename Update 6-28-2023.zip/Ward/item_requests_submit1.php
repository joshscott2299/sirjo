<?php
// header('Content-Type:application/json');
include('../dist/includes/dbcon.php');

$request = $_POST ?? [];
$request = json_decode(json_encode($request));

$response = [];

// check if RIS already exists...
$query = mysqli_query(
  $con,
  "select * from itemrequests_head1
  where ris='$request->ris' LIMIT 1000;
  "
);
if(mysqli_num_rows($query) > 0) {
  $response['success']=false;
  $response['message']='RIS already exists. Please specify another.';
  echo json_encode($response);
  return;
} else {
  $query->close();

  $query2 = mysqli_query(
    $con,
    "INSERT INTO itemrequests_head1(request_to_branch_id,ris,request_date,request_from_branch_id,requested_by_id)
    VALUES(
      $request->request_to_branch_id,
      '$request->ris',
      '$request->request_date',
      $request->request_from_branch_id,
      $request->requested_by_id
    );
    "
  );
  foreach($request->items as $item) {
    mysqli_query($con,
      "INSERT INTO itemrequests_line1(prod_id,qty,serial,ris,unit_id)
      VALUES(
        '$item->id',
        '$item->quantity',
        '$item->serial',
        '$request->ris',
        '$item->unit_id'
      )
      "
    );
  }

  $response['success']=true;
  $response['message']='Successful';

  echo json_encode($response);
}
