<!-- Reserve Details -->
    <div class="modal fade" id="reserve_detail<?php echo $rid; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<?php
	$branch=$_SESSION['branch'];
		$res=mysqli_query($con,"select * from request_itemmicro natural join branch where requestid='$rid' and branch_id_to='$branch'");
		$resrow=mysqli_fetch_array($res);
	?>
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<center><h4 class="modal-title" id="myModalLabel">Request Item Detail's</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
				<div class="row" style="margin-left:0px; margin-right:0px;">
					<h5>From:<b> <?php echo ucwords($resrow['branch_name']); ?></b>
					<span class="pull-right">Date Requested:<b> <?php echo date("M d, Y ", strtotime($resrow['request_date'])); ?></b></span></h5>
					<h5>Status:<b> <?php echo ucwords($resrow['request_status']); ?></b>
					<span class="pull-right">RIS NO.: <b><?php echo ucwords($resrow['ris_code']); ?></b></span></h5>
				</div>
					<div style="height:5px;"></div>
					<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
						<thead>
							<tr>
							<th>Stock No.</th>
							<th>Item Name</th>
							<th>Description</th>
							<th>Unit</th>
							<th>Category</th>
							<th>Qty Request</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$branch=$_SESSION['branch'];
								$dis=0;
								$tq=0;
								$rd=mysqli_query($con,"select * from request_detailmicro natural join product_micro natural join category natural join unit_measure where requestid='$rid' and branch_id_tos='$branch'");
								while($rdrow=mysqli_fetch_array($rd)){
									?>
									<tr>
									<td><?php echo $rdrow['serial']; ?></td>
										<td><?php echo $rdrow['product_name']; ?></td>
										<td><?php echo $rdrow['description']; ?></td>
										<td><?php echo $rdrow['unit_name']; ?></td>
										<td><?php echo $rdrow['cat_name']; ?></td>
										<td>
											<?php 
												echo $rdrow['request_qty'];
												$tq+=$rdrow['request_qty'];
											?>
										</td>
										
										
										
										
									</tr>
									<?php
								}
							?>
							<tr>
								<td colspan="5" align="right"><strong>Total Quantity:</strong></td>
								<td align="left"><?php echo number_format($tq); ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				</div>
				<div style="height:5px;"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->