<?php
// header('Content-Type:application/json');
include('../dist/includes/dbcon.php');

$searchKey = $_GET['patient_name'] ?? '';
$searchKey = htmlspecialchars(trim($searchKey));

$queryc = mysqli_query(
  $con,
  "SELECT patient_name FROM issuances_patients 
    WHERE patient_name 
    LIKE '%$searchKey%' 
    GROUP by patient_name 
    LIMIT 10;"
) or die(mysqli_error($con));

$temp = [];

while ($rowc = mysqli_fetch_array($queryc)) {
  $temp[] = $rowc['patient_name'];
}

echo json_encode($temp);