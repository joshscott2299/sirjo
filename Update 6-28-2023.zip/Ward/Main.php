
<?php
error_reporting(E_ALL ^ E_DEPRECATED); ini_set('display_errors', 1);

class Main {
	
	protected $host = 'localhost';
	protected $username = 'root';
	protected $password = '';
	protected $dbname = 'inventory';
	protected $con;

	protected $messages;
	protected $today;
	protected $dtime;

	public function __construct() {
		 date_default_timezone_set('Asia/Manila');
		$this->today = date('Y-m-d');
		$this->dtime = date('Y-m-d G:i:s');
		try {
			$this->con = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->username, $this->password);
			}
		catch(PDOException $e)
			{
			echo "Connection failed: " . $e->getMessage(); die;
			}
	}

	public function login($data) {
		$user = $this->con->prepare("SELECT user.*, comp.* from 
		tbl_user as user 
		INNER JOIN tbl_personal as comp 
		ON user.code = comp.code	
		WHERE user.username =:uname and user.password =:pass
		and del = 0 AND user.code = '111116' AND comp.personal_id = '1001'");

		$user->execute(array(
			'uname' => $data['uname'],
			'pass' => $data['password']
		));

		$userInfo = $user->fetch(PDO::FETCH_ASSOC);
		
		$return = array();
		if(count($userInfo) >= 1) {
			session_start();
			$_SESSION = $userInfo;
			$_SESSION['barcode'] = array();
			$return['result'] = 'success';
	
		} else {
			$return['result'] = 'error';
		}

		return json_encode($return);
	}

	public function logout() {
		unset($_SESSION);
		session_destroy();
		header('Location: ../index.php');
	}

	public function suppliersList() {
		$users = $this->con->prepare("SELECT * FROM tbl_supplier where del = 0 order by company_name asc");
		$users->execute();
	
		return $users->fetchALL(PDO::FETCH_ASSOC);
	}

	public function showExpiredMedicines() {
		$basis_date = date('Y-m-d', strtotime("+210 days"));//7months
		$sql = "Select count(mqty.qty_id) as cnt from tbl_med_qty as mqty where mqty.expiration <= :today and 
		coalesce
		(
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id)
			-
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id),
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			0
		) > 0
		AND mqty.expiration <> '0000-00-00' limit 1";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'today' => $basis_date
		));

		return json_encode($query->fetch(PDO::FETCH_ASSOC));	
	}

	public function showCriticalMedicines() {
		$sql = "SELECT count(qty.qty_id) as cnt 
					FROM tbl_medicines AS med
				LEFT JOIN tbl_med_qty AS qty ON med.medicine_id = qty.medicine_id
				WHERE 
				coalesce
				(
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id)
					-
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id),
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					0
				)
				<= med.limit_qty limit 1";
		$query = $this->con->prepare($sql);
		$query->execute();

		return json_encode($query->fetch(PDO::FETCH_ASSOC));	
	}

	public function showExpired($data) {
		$from = '2016-01-01' . ' 00:00:00';
		$to = $this->today . ' 23:59:59';
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		}

		$basis_date = date('Y-m-d', strtotime("+210 days"));//7months
		$sql = "Select mqty.*  from product as mqty where mqty.expiry <= :today and 
		coalesce
		(
			(Select sum(prod_qty) from product where prod_id = mqty.prod_id)
			
			,
			0
		) > 0
		AND mqty.expiry <> '	0000-00-00' ";
		if(isset($data['from'])) {
			if($data['from']) {
				$sql .= " AND expiry >='$from' AND expiry <='$to'";
			}
		}
		if(isset($data['prod_name'])) {
			$sql .= " AND prod_name like '%$data[prod_name]%'";
		}
		if(isset($data['serial'])) {
			$sql .= " AND serial like '%$data[serial]%'";
		}
		
		$num = $this->con->prepare($sql);
		$num->execute(array(
			'today' => $basis_date

		));
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);
		$total = count($num);
		
		

		$query = $this->con->prepare($sql);
		$query->execute(array(
			'today' => $basis_date
		));

		return array($query->fetchAll(PDO::FETCH_ASSOC), $total);	
	}

	public function showExpiredPopup() {
	
		$basis_date = date('Y-m-d', strtotime("+210 days"));
		$sql = "Select mqty.*, coalesce
		(
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id)
			-
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id),
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			0
		) as current_qty
		
		from tbl_med_qty as mqty where expiration <= :today and 
		coalesce
		(
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id)
			-
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			(Select sum(qty) from tbl_med_qty where qty_id = mqty.qty_id),
			(Select sum(qty) from tbl_sold_medicine where qty_id = mqty.qty_id)
			,
			0
		) > 0
		and expiration <> '	0000-00-00' ";		
	
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'today' => $basis_date
		));

		return $query->fetchAll(PDO::FETCH_ASSOC);	
	}

	public function showCriticalPopup() {
		
		$sql = "SELECT qty.*, coalesce
				(
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id)
					-
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id),
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					0
				) as current_qty
					FROM tbl_medicines AS med
				LEFT JOIN tbl_med_qty AS qty ON med.medicine_id = qty.medicine_id
				WHERE 
				coalesce
				(
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id)
					-
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					(Select sum(qty) from tbl_med_qty where qty_id = qty.qty_id),
					(Select sum(qty) from tbl_sold_medicine where qty_id = qty.qty_id)
					,
					0
				)
				<= med.limit_qty";
		
		$query = $this->con->prepare($sql);
		$query->execute();

		return $query->fetchAll(PDO::FETCH_ASSOC);	
	}

	public function showCritical($data) {
	
		
		$sql = "SELECT qty.*, supp.company_name 
					FROM tbl_medicines AS med
				LEFT JOIN tbl_med_qty AS qty ON med.medicine_id = qty.medicine_id
				LEFT JOIN tbl_supplier as supp ON med.supplier_id = supp.supplier_id
				WHERE qty.current_qty <= med.limit_qty";
		
		if(isset($data['barcode'])) {
			$sql .= " AND qty.barcode like '%$data[barcode]%'";
		}
		if(isset($data['medicine'])) {
			$sql .= " AND qty.medicine_name like '%$data[medicine]%'";
		}
		
		
		$num = $this->con->prepare($sql);
		$num->execute();
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);
		$total = count($num);
		
		$sql .= " order by qty_id asc LIMIT $data[start], $data[pagesize]";

		$query = $this->con->prepare($sql);
		$query->execute();

		return array($query->fetchAll(PDO::FETCH_ASSOC), $total);

	
		
	}


	public function customer($data) {
		$sql = "Select * from tbl_customer where customer_id =:cust ";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cust' => $data['customer-name']
		));

		return $query->fetch(PDO::FETCH_ASSOC);

	}
	
	function getDoctor($doc) {
		$sql = "Select doctor_name from tbl_doctors where doctor_id = '$doc'";
		$query = $this->con->prepare($sql);
		$query->execute();

		return $query->fetch(PDO::FETCH_ASSOC);

	}

	function addPatientVisit($data) {
		
		$visit_date = date('Y-m-d', strtotime($data['date_visit'])) . ' ' . date('H:i:s');
		$sql = "Insert into tbl_patient_visit (customer_id, notes, date_visit, created_at, bp,wt, temp, complaint, diagnosis, prescription) VALUES (:cid, :notes, :dvisit, :today, :bp, :wt, :temp, :complaint, :diagnosis, :prescription)";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cid' => $data['cid'],
			'notes' => $data['notes'],
			'today' => $this->dtime,
			'dvisit' => $visit_date,
			'bp' => $data['bp'],
			'wt' => $data['wt'],
			'temp' => $data['temp'],
			'complaint' => $data['complaint'],
			'diagnosis' => $data['diagnosis'],
			'prescription' => $data['prescription']
		));
		
		//UPDATE LAST VISIT
		$update = "Update tbl_customer set last_visit =:last_visit where customer_id =:cid";
		$query_update = $this->con->prepare($update);
		$query_update->execute(array(
			'cid' => $data['cid'],
			'last_visit' => $visit_date
		));
		
		echo $visit_date;

	}

	function patientVisits($data){
		if($_SESSION['user_level'] == 'admin') {
			$update_sql1 = "Update tbl_customer set del = 0";
			$query_up1 = $this->con->prepare($update_sql1);
			$query_up1->execute();
			
			$update_sql = "Update tbl_customer set del = 1 where customer_id =:cid";
			$query_up = $this->con->prepare($update_sql);
			$query_up->execute(array(
				'cid' => $data['cid']	
			));
		}
		
		$sql = "Select * from tbl_patient_visit where customer_id =:cid order by created_at desc";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cid' => $data['cid']	
		));

		$name_sql = "Select customer_name, age from tbl_customer where customer_id =:cid";
		$name = $this->con->prepare($name_sql);
		$name->execute(array(
			'cid' => $data['cid']	
		));

		return array($query->fetchAll(PDO::FETCH_ASSOC) , $name->fetch(PDO::FETCH_ASSOC));

	}
	function invoice($data){
		$sql = "Select * from tbl_patient_visit ";
		$query = $this->con->prepare($sql);
		$query->execute(array(
				
		));


		return $query->fetch(PDO::FETCH_ASSOC);

	}
	function invoice1($data){
		$sql = "Select tbl_patient_visit.visit_id, tbl_customer.customer_name, tbl_patient_visit.notes, tbl_customer.address, tbl_patient_visit.date_visit, tbl_customer.age, tbl_patient_visit.prescription FROM tbl_patient_visit INNER JOIN tbl_customer ON tbl_patient_visit.customer_id=tbl_customer.customer_id";
		$query = $this->con->prepare($sql);
		$query->execute(array(
				
		));


		return $query->fetch(PDO::FETCH_ASSOC);

	}

	function editVisit($data){
		$sql = "Select * from tbl_patient_visit where visit_id =:vid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'vid' => $data['id']
		));

		return $query->fetch(PDO::FETCH_ASSOC);

	}
	function editvisitprint($data){
		$sql = "Select * from tbl_customer where customer_id =:vid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'vid' => $data['id']
		));

		return $query->fetch(PDO::FETCH_ASSOC);

	}
	function editvisitprint1($data){
		$sql = "Select * from tbl_patient_visit where customer_id =:vid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'vid' => $data['id']
		));

		return $query->fetch(PDO::FETCH_ASSOC);

	}



	function profile() {
		$sql = "Select * from tbl_user where user_id = '$_SESSION[user_id]'";
		$query = $this->con->prepare($sql);
		$query->execute();

		return $query->fetch(PDO::FETCH_ASSOC);
	}

	function updatePassword($data) {
		$sql = "Update tbl_user set password = '$data[password]' where user_id = '$_SESSION[user_id]' ";
		$query = $this->con->prepare($sql);
		$query->execute();
	}

	function updateVisit($data) {
		if($_SESSION['user_level'] == 'user') {
			$sql = "Update tbl_patient_visit set bp =:bp, wt =:wt, temp =:temp, complaint =:comp 
			where visit_id =:vid";
			$query = $this->con->prepare($sql);
			$query->execute(array(
				'vid' => $data['id'],
				'bp' => $data['bp'],
				'wt' => $data['wt'],
				'temp' => $data['temp'],
				'comp' => $data['complaint']
			));
		} else if($_SESSION['user_level'] == 'admin') {
			$sql = "Update tbl_patient_visit set bp =:bp, wt =:wt, temp =:temp, complaint =:comp, notes =:notes, diagnosis=:diagnosis, prescription =:presc, readme = 1 where visit_id =:vid";

			$query = $this->con->prepare($sql);
			$query->execute(array(
				'vid' => $data['id'],
				'bp' => $data['bp'],
				'wt' => $data['wt'],
				'temp' => $data['temp'],
				'comp' => $data['complaint'],
				'notes' => $data['notes'],
				'presc' => $data['prescription'],
				'diagnosis' => $data['diagnosis']
			));
		}

		
	}
	public function doctorsList($data = NULL) {
		$sql = "SELECT * FROM tbl_doctors where del = 0 ";
		if(isset($data['type'])) {
			$sql .= " AND type = '$data[type]' ";
		}
		$sql .= " order by doctor_name asc";
		$users = $this->con->prepare($sql);
		$users->execute();
	
		return $users->fetchALL(PDO::FETCH_ASSOC);
	}



	public function patientsList() {
		$users = $this->con->prepare("SELECT * FROM tbl_customer where customer_type = 'patient' order by created_at asc");
		$users->execute();
	
		return $users->fetchALL(PDO::FETCH_ASSOC);
	}
	
	public function medicineSold($data) {
		$sql = "Select medicine_name, unit_cost, sum(qty) as qty, created_at  from tbl_sold_medicine where transaction_id =:tid ";
		
		if(isset($data['cid'])) {
			$sql .= " and customer_id = '$data[cid]' ";
		}
		
		$sql .= " group by barcode";

		$query = $this->con->prepare($sql);
		$query->execute(array(
			'tid' => $data['tid']
		));

		return $query->fetchALL(PDO::FETCH_ASSOC);
	}

	public function updateTransactionDate($data){
		//DELETE TRANSACTION
		$date_transact = date('Y-m-d 10:00:00', strtotime($data['dateTransact']));
		$delTran = "Update tbl_transaction set created_at = '$date_transact' where transaction_id =:tid";
		$del = $this->con->prepare($delTran);
		$del->execute(array(
			'tid' => $data['transact_id']
		));
		
		//DELETE SOLD MEDICINE AND SERVICE
		if($del) {
			$delSoldMed = "Update tbl_sold_medicine set created_at = '$date_transact' where transaction_id =:tid";
			$delSoldMed = $this->con->prepare($delSoldMed);
			$delSoldMed->execute(array(
				'tid' => $data['transact_id']
			));

			$delSoldService = "Update tbl_sold_service set created_at = '$date_transact' where transaction_id =:tid";
			$delSoldService = $this->con->prepare($delSoldService);
			$delSoldService->execute(array(
				'tid' => $data['transact_id']
			));
		}

		if($delSoldService) {
			$delPayment = "Update tbl_payment set created_at = '$date_transact' where transaction_id =:tid";
			$delPayment = $this->con->prepare($delPayment);
			$delPayment->execute(array(
				'tid' => $data['transact_id']
			));
		}


		if($del) {
			return '1';
		} else {
			return '0';
		}
	}

	public function serviceSold($data) {
		$sql = "Select services, total_charges from tbl_sold_service where transaction_id =:tid ";

		if(isset($data['cid'])) {
			$sql .= " and customer_id = '$data[cid]' ";
		}

		$query = $this->con->prepare($sql);
		$query->execute(array(
			'tid' => $data['tid']
		));

		return $query->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function paymentHistory($data){
		$sql ="Select * from tbl_payment where transaction_id =:tid ";
		if(isset($data['cid'])) {
			$sql .= " and customer_id = '$data[cid]' ";
		}
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'tid' => $data['tid']
		));
		return $query->fetchALL(PDO::FETCH_ASSOC);
	}
	public function patientTransaction($data) {
		$sql = "Select transaction_id, payment_type, payment_status from tbl_transaction where customer_id =:cid order by created_at desc";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cid' => $data['cid']
		));

		return $query->fetchALL(PDO::FETCH_ASSOC);
	}

	public function patientsRecord($data) {
		$from = $this->today . ' 00:00:00';
		$to = $this->today . ' 23:59:59';
		
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		}
		$sql =  "SELECT cust.*, tran.transaction_id, tran.payment_status,
				(Select count(visit_id) from tbl_patient_visit where readme = 0 and customer_id  = cust.customer_id) as unreadVisit
				from tbl_customer as cust
				 LEFT JOIN
					tbl_transaction as tran
				  ON
					cust.last_transaction = tran.transaction_id
				  WHERE
					customer_type = 'patient' ";
		
		if(isset($data['name'])){
			if($data['name'])
			$sql .= " AND cust.customer_name like '%$data[name]%' ";
		}
		if(isset($data['payment_status'])){
			
			if($data['payment_status'])
			$sql .= " AND tran.payment_status = '$data[payment_status]' ";

		}
		
		if(isset($data['name'])){
			if($data['name']) {

			} else {
				$sql .= " AND cust.last_visit >= '$from' AND cust.last_visit <= '$to'";
			}
		} else {
			$sql .= " AND cust.last_visit >= '$from' AND cust.last_visit <= '$to'";
		}

		$sql .= " order by cust.last_visit";


		$query = $this->con->prepare($sql);
		$query->execute();

		return $query->fetchALL(PDO::FETCH_ASSOC);
	}
	
	public function lastPrescription($data) {
		$sql = "Select prescription from tbl_patient_visit where customer_id =:cid order by created_at desc limit 1";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cid' => $data['cid']	
		));
		$row = $query->fetch(PDO::FETCH_ASSOC);
		return $row['prescription'];

	}
	public function delPatient($data) {
		$sql = "Delete from tbl_customer where customer_id =:cid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'cid' => $data['id']	
		));

		if($query) {
			$sql = "Delete from tbl_patient_visit where customer_id =:cid";
			$query = $this->con->prepare($sql);
			$query->execute(array(
				'cid' => $data['id']	
			));
		}

		return json_encode($data);

	}

	
	public function servicesList() {
		$users = $this->con->prepare("SELECT * FROM tbl_service where del = 0  order by created_at asc");
		$users->execute();
	
		return $users->fetchALL(PDO::FETCH_ASSOC);
	}

	public function expenses($data) {
		
		if(isset($data['from'])) {
			$from1 = date('Y-m-d', strtotime($data['from']));
			$from = $from1 . ' 00:00:00';
			$to1 = date('Y-m-d', strtotime($data['to']));
			$to = $to1 . ' 23:59:59';
		}

		$sql = "SELECT * FROM tbl_expenses where expense_id <> ''";
		if(isset($data['from'])) {
			
			if($data['from'])
			$sql .= " AND date_expense >='$from'";

		}
		if(isset($data['to'])) {
			
			if($data['to'])
			$sql .= " AND date_expense <='$to'";

		}
		if(isset($data['description'])) {
			$sql .= " AND description like '%$data[description]%' ";
		}

		$num = $this->con->prepare($sql);
		$num->execute();
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);
		$total = count($num);

		$sql .= " order by date_expense desc LIMIT $data[start], $data[pagesize]";
		


		$users = $this->con->prepare($sql);
		$users->execute();
	
		return array($users->fetchALL(PDO::FETCH_ASSOC), $total);
	}

	public function users($data) {
		
		$sql = "SELECT * FROM tbl_user where user_id <> ''";

		if(isset($data['name'])) {
			$sql .= " AND name like '%$data[name]%' ";
		}

		$num = $this->con->prepare($sql);
		$num->execute();
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);
		$total = count($num);

		$sql .= " order by created_at desc LIMIT $data[start], $data[pagesize]";
		


		$users = $this->con->prepare($sql);
		$users->execute();
	
		return array($users->fetchALL(PDO::FETCH_ASSOC), $total);
	}

	public function addUser($data) {
		$sql = "Insert into tbl_user (name, username, password, created_at, user_level, code)
				VALUES (:name, :uname, :pass, :today, :level, :code)
		";
		$users = $this->con->prepare($sql);
		$users->execute(array(
			'name' => $data['name'],
			'uname' => $data['username'],
			'pass' => $data['password'],
			'today' => $this->dtime,
			'level' => $data['user_level'],
			'code' => '111116'
		));


	}

	public function editExpense($data){
		$sql = "Select * from tbl_expenses where expense_id =:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['id']	
		));
	
		return $query->fetch(PDO::FETCH_ASSOC);

	}

	public function editQuantity($data){
		$sql = "Select * from tbl_med_qty where qty_id =:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id']	
		));
	
		return $query->fetch(PDO::FETCH_ASSOC);

	}

	public function updateMedQty($data) {
		$sql = "Update tbl_med_qty set  qty =:qty, batch_no =:batch, expiration=:exp, created_at=:delivery
			    where qty_id =:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id'],
			'qty' => $data['qty'],
			'batch' => $data['batch_no'],
			'exp' => $data['expiration'],
			'delivery' => $data['delivery']
		));
	}
	
	public function unreadPatients() {
		
		$sql = "Select count(*) as cnt from tbl_patient_visit where readme = 0";
		$query = $this->con->prepare($sql);
		$query->execute();
		$row  = $query->fetch(PDO::FETCH_ASSOC);
		
		if($_SESSION['user_level'] == 'admin')
			return $row['cnt'];
		else
			return 0;

	}
	public function editUser($data){
		$sql = "Select * from tbl_user where user_id =:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['id']	
		));
	
		return $query->fetch(PDO::FETCH_ASSOC);

	}

	public function updateExpense($data){
		$sql = "Update tbl_expenses set amount =:amnt, description =:desc where expense_id=:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['eid'],
			'amnt' => $data['amount'],
			'desc' => $data['description']
		));
	
	}

	public function updateUser($data){
		$sql = "Update tbl_user set name =:name, username =:uname, password =:pass, user_level =:level where user_id=:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['eid'],
			'name' => $data['name'],
			'uname' => $data['username'],
			'pass' => $data['password'],
			'level' => $data['user_level']
		));
	
	}

	public function deleteExpense($data){
		$sql = "Delete from tbl_expenses where expense_id=:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['eid']
		));
	}

	public function deleteMedQty($data) {
		$sql = "Delete from tbl_med_qty where qty_id =:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id']
		));

	}

	public function deleteService($data) {
		$sql = "Delete from tbl_service where service_id =:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id']
		));

	}

	public function editService($data) {
		$sql = "Select * from tbl_service where service_id =:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id']
		));

		return $query->fetch(PDO::FETCH_ASSOC);
	}

	public function updateService($data) {
		$sql = "Update tbl_service set description =:desc, price =:price where service_id=:id";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'id' => $data['id'],
			'desc' => $data['description'],
			'price' => $data['price']
		));
	}

	public function deleteUser($data){
		$sql = "Delete from tbl_user where user_id=:eid";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'eid' => $data['eid']
		));
	}

	public function addExpense($data){
		$sql = "INSERT INTO tbl_expenses (amount, description, date_expense, user_id, created_at)
				VALUES (:exp, :desc, :dte, :uid, :today)";
		$add = $this->con->prepare($sql);
		$add->execute(array(
			'exp' => $data['amount'],
			'desc' => $data['description'],
			'dte' => date('Y-m-d', strtotime($data['date_expense'])),
			'uid' => $_SESSION['user_id'],
			'today' => $this->today
		));
	}

	public function paymentCredits($data) {
		$from1 = date('Y-m-d', strtotime($data['from']));
		$from = $from1 . ' 00:00:00';
		$to1 = date('Y-m-d', strtotime($data['to']));
		$to = $to1 . ' 23:59:59';
		
	
		$sql ="Select tran.transaction_id, sum(pay.amount) as total from tbl_transaction as tran 
			left join tbl_payment as pay ON tran.transaction_id = pay.transaction_id
			where tran.payment_type = 'credit' AND pay.created_at >=:from and pay.created_at <=:to
			";

		if(isset($data['doctor_id'])) {
			//$sql .= " AND tran.doctor_id = '$data[doctor_id]' ";
		}

		$query = $this->con->prepare($sql);
		$query->execute(array(
			'from' => $from,
			'to' => $to
		));
		
		return json_encode($query->fetch(PDO::FETCH_ASSOC));
		
	}

	public function totalExpenses($data) {
		$from1 = date('Y-m-d', strtotime($data['from']));
		$from = $from1 . ' 00:00:00';
		$to1 = date('Y-m-d', strtotime($data['to']));
		$to = $to1 . ' 23:59:59';
		
	
		$sql ="Select sum(amount) as total from tbl_expenses WHERE date_expense >=:from and date_expense <=:to";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'from' => $from,
			'to' => $to
		));
		
		return json_encode($query->fetch(PDO::FETCH_ASSOC));
		
	}

	public function searchBarcode() {
		$query = $this->con->prepare("SELECT barcode, name, company_price(1+marktab) as clinic_price FROM tbl_service where del = 0  order by description asc");
		$query->execute();
	
		return $query->fetchALL(PDO::FETCH_ASSOC);
	}

	public function addMedicineOrder($data) {
		$sql = "SELECT supplier_id, doctor_id, comp_percent, doc_percent, company_price, marktab, barcode, name, company_price, 
				(1-(company_price-marktab)/company_price) as percent_mark_up
		 FROM tbl_medicines where barcode =:code AND del = 0";
		$query = $this->con->prepare($sql);

		$query->execute(array(
			'code' => $data['barcode']	
		));

		$result = $query->fetch(PDO::FETCH_ASSOC);
	
	
		return $result;
	}

	public function batch_no($data) {
		$sql = "Select batch.qty_id, batch.batch_no, batch.medicine_id, batch.expiration,med.supplier_id, med.doctor_id,
				coalesce
				(
					batch.qty - (Select sum(qty) from tbl_sold_medicine where qty_id = batch.qty_id),
					batch.qty,
					(Select sum(qty) from tbl_sold_medicine where qty_id = batch.qty_id),
					0
				) as current_qty
				from tbl_med_qty as batch 
				LEFT JOIN
					tbl_medicines as med ON batch.medicine_id = med.medicine_id
				where batch.barcode =:bcode AND batch.del = 0  and 
				coalesce
				(
					batch.qty - (Select sum(qty) from tbl_sold_medicine where qty_id = batch.qty_id),
					batch.qty,
					(Select sum(qty) from tbl_sold_medicine where qty_id = batch.qty_id),
					0
				) >= 1 
				order by expiration asc";
		
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'bcode' => $data['barcode']
		));
		//echo $sql;
		$result = $query->fetchAll(PDO::FETCH_ASSOC);
	
	
		return $result;
	}

	public function credit_of_day($data){
		$from1 = date('Y-m-d', strtotime($data['from']));
		$from = $from1 . ' 00:00:00';
		$to1 = date('Y-m-d', strtotime($data['to']));
		$to = $to1 . ' 23:59:59';
		
		/*
		$sql ="Select tran.transaction_id, 
			  sum(
				(Select sum(unit_cost * qty) as credit_medicine from tbl_sold_medicine where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to) 
			  +
				(Select sum(total_charges) as credit_services from tbl_sold_service where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to)
			   ) as total
			  from tbl_transaction as tran
			  where tran.payment_type = 'credit'";
		*/
		/*
		So in this case, if neither parameter is null, it will return the sum. If only b is null, it will skip a+b and return a. If a is null, it will skip a+b and a and return b, which will only be null if they are both null.

		If you want the answer to be 0 rather than null if both a and b are null, you can pass 0 as the last parameter:

		coalesce(a+b, a, b, 0)
		*/
		$sql = "Select tran.transaction_id, 
			  sum(
				coalesce
				(
                     (Select sum(unit_cost * qty) as credit_medicine from tbl_sold_medicine where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to) 
				+
					(Select sum(total_charges) as credit_services from tbl_sold_service where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to),
                    (Select sum(unit_cost * qty) as credit_medicine from tbl_sold_medicine where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to),
                          
                    (Select sum(total_charges) as credit_services from tbl_sold_service where transaction_id = tran.transaction_id AND created_at >=:from AND created_at <=:to),
                    
					0
                          
                )
			   ) as total
			  from tbl_transaction as tran
			  where tran.payment_type = 'credit'";

		
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'from' => $from,
			'to' => $to
		));
		
		return json_encode($query->fetch(PDO::FETCH_ASSOC));
	}

	public function servicePayments($data) {
		$from1 = date('Y-m-d', strtotime($data['from']));
		$from = $from1 . ' 00:00:00';
		$to1 = date('Y-m-d', strtotime($data['to']));
		$to = $to1 . ' 23:59:59';
		
	
		$sql ="Select serv.service_id, serv.description,
				(SELECT sum(pay.amount) from tbl_transaction as tran
				left JOIN
				tbl_payment as pay ON tran.transaction_id = pay.transaction_id 
				 where pay.service_id = serv.service_id
				 AND pay.created_at >=:from AND pay.created_at <=:to AND tran.payment_type = 'cash' ";
		
		if(isset($data['doctor_id'])) {
			//$sql .= " AND tran.doctor_id = '$data[doctor_id]' ";
		}

		$sql .=" ) as total
				from tbl_service as serv order by serv.created_at asc";

		
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'from' => $from,
			'to' => $to
		));
		
		return json_encode($query->fetchALL(PDO::FETCH_ASSOC));
	}

	public function loadBarcodeRecord($data) {
		$query = $this->con->prepare("SELECT doc.doctor_name, supply.company_name, med.*, Emed.company_price*(1+med.marktab) as clinic_price 
		FROM 
			tbl_medicines as med 
		LEFT JOIN
			tbl_supplier as supply
		ON
			med.supplier_id = supply.supplier_id
		LEFT JOIN
			tbl_doctors as doc
		ON 
			med.doctor_id = doc.doctor_id
		where med.barcode =:bcode order by created_at asc");
		$query->execute(array(
			'bcode' => $data['bcode']	
		));
		
	
		return json_encode($query->fetch(PDO::FETCH_ASSOC));
	}

	function editMedicine($data) {
		$sql = "SELECT * from tbl_medicines where barcode =:code and medicine_id =:medid order by created_at desc limit 1";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'code' => $data['code'],
			'medid' => $data['medid']
		));

		return $query->fetch(PDO::FETCH_ASSOC);
	}

	function editMedicineSave($data){
		$sql = "UPDATE tbl_medicines SET barcode=:barcode, supplier_id=:supplier, doctor_id=:doctor, name=:name, doc_percent=:dper,
		comp_percent=:cper, notes=:notes, updated_at=:today, updated_by=:user, limit_qty=:limit_qty WHERE medicine_id =:med_id";
		$up = $this->con->prepare($sql);
		$up->execute(array(
			'user' => $_SESSION['name'],
			'doctor' => $data['doctor'],
			'supplier' => $data['supplier'],
			'name' => $data['medicine'],
			'dper' => $data['doc_share'],
			'cper' => $data['com_share'],
			'today' => $this->today,
			'notes' => $data['notes'],
			'limit_qty' => $data['limit_qty'],
			'barcode' => $data['barcode'],
			'med_id' => trim($data['medicine_id'])
		));

		$sqlUpQty = "Update tbl_med_qty set barcode=:barcode where medicine_id =:med_id";
		$up = $this->con->prepare($sqlUpQty);
		$up->execute(array(
			'med_id' => trim($data['medicine_id']),
			'barcode' => $data['barcode']	

		));

		return $data['barcode'];
		
	}

	public function payableOtherDoctor($docId,$medId) {
		$sql = "select sum(amount) as docPaid from tbl_payment_doctor where doctor_id =:did AND medicine_id =:mid";
		$getPaid = $this->con->prepare($sql);
		$getPaid->execute(array(
			'did' => $docId,
			'mid' => $medId
		));
		
		$list = $getPaid->fetch(PDO::FETCH_ASSOC);

		return $list;

	}

	public function addMedicine($data) {
		$ret = array();
		$otherDoctor = '';
		if($data['computation_type'] == '2') {
			$ctr = 0;
			foreach($data['otherDoctor'] as $docID) {
				$getDocName = "Select doctor_name from tbl_doctors where doctor_id =:did";
				$getDoc = $this->con->prepare($getDocName);
				$getDoc->execute(array(
					'did' => $docID
				));
				$doc = $getDoc->fetch(PDO::FETCH_ASSOC);
				
				$otherDoctor .= $otherDoctor  . $docID . '*' . $doc['doctor_name'] . '*' . $data['otherDoctorShare'][$ctr] . '|';
				
				$ctr++;
			}
		} 

		$up = $this->con->prepare("INSERT INTO tbl_medicines (user_id, supplier_id, doctor_id, name, company_price, doc_percent, marktab, comp_percent, initial_qty,  notes, barcode, created_at, limit_qty,other_doc_percent, type ) VALUES(:uid, :supplier, :doctor, :name, :com_price, :dper, :mtab, :cper, :init_qty,  :notes, :barcode, :today, :limit, :otherDocPercent, :type)");
		$up->execute(array(
			'uid' => $_SESSION['user_id'],
			'doctor' => $data['doctor'],
			'mtab' => $data['markup_tab'],
			'supplier' => $data['supplier'],
			'name' => $data['medicine'],
			'com_price' => $data['com_price'],
			'dper' => $data['doc_share'],
			'cper' => $data['com_share'],
			'init_qty' => $data['initial_qty'],
			'notes' => $data['notes'],
			'barcode' => $data['barcode'],
			'today' => $this->today,
			'limit' => $data['limit'],
			'otherDocPercent' => $otherDoctor,
			'type' => $data['computation_type']
		));
		
		//-->IF SUCCESS INSERT MEDICINE
		if($up) {
			$qty_sql = "INSERT INTO tbl_med_qty (medicine_id, medicine_name, barcode, qty, current_qty, created_at, user_id, batch_no, expiration)
						VALUES (:med_id, :med_name, :code, :qty, :cur_qty, :today, :uid, :batch_no, :expiration)";
			$qty_query = $this->con->prepare($qty_sql);
			$qty_query->execute(array(
				'med_id' => $this->con->lastInsertId(),
				'med_name' => $data['medicine'],
				'code' => $data['barcode'],
				'qty' => $data['initial_qty'],
				'cur_qty' => $data['initial_qty'],
				'today'=> $this->today,
				'uid' => $_SESSION['user_id'],
				'batch_no' => $data['batch_no'],
				'expiration' => date('Y-m-d', strtotime($data['expiration'])),
			));

			if($qty_sql) {
				$ret['result'] = 'success';
				$ret['msg']= 'Success inserting of data.';
			} else {
				$ret['result'] = 'error';
				$ret['msg']= 'Warning.Please reinsert initial quantity';
			}
		} else {
			$ret['result'] = 'error';
			$ret['msg']= 'Error inserting new medicine record.';
		}
		
		return json_encode($ret);
	}

	public function addSellMed($data) {
		$customer_id = $data['customer-name'];
		$transact_date = $data['transact_date'] . ' ' . date('G:i:s');
		$transact_date = strtotime($transact_date);
		$transact_date = date('Y-m-d G:i:s', $transact_date);
	
		//-->INSERT CUSTOMER IF WALK-IN
		if($data['patient-type'] == 'walk-in') {
			$insCustomer_sql = "INSERT tbl_customer (user_id, customer_name, customer_type, created_at)
							VALUES (:uid, :cust_name, :type, :today)";
			$insCustomer = $this->con->prepare($insCustomer_sql);
			$insCustomer->execute(array(
				'uid' => $_SESSION['user_id'],
				'cust_name' => $data['customer-name'],
				'type' => 'walk-in',
				'today' => $transact_date
			));

			if(is_object($insCustomer)) {
				$customer_id = $this->con->lastInsertId();
			} else {
				$customer_id = -1;
			}
		}
		
		//-->INSERT TRANSACTION
		if(trim($data['payment-type']) == 'cash') {
			$pay_status = 'Paid';
		} else {
			$pay_status = 'Unpaid';
		}

		$insTransaction_sql = "INSERT into tbl_transaction (customer_id, user_id, payment_type, created_at, payment_status, doctor_id)
							   VALUES (:cid, :uid, :ptype, :today, :pstatus, :doc)";
		$insTransaction = $this->con->prepare($insTransaction_sql);
		$insTransaction->execute(array(
			'cid' => $customer_id,
			'uid' => $_SESSION['user_id'],
			'ptype' => $data['payment-type'],
			'today' => $transact_date,
			'pstatus' => $pay_status,
			'doc' => $data['doctor']
		));

		if(is_object($insTransaction)) {
			$transaction_id = $this->con->lastInsertId();
			
			//UPDATE LAST TRANSACTION OF CUSTOMER
			$uptCusTransaction_sql = "UPDATE tbl_customer set last_transaction =:tid where customer_id =:cid";
			$uptCusTransaction = $this->con->prepare($uptCusTransaction_sql);
			$uptCusTransaction->execute(array(
				'tid' => $transaction_id,
				'cid' => $customer_id
			));

		} else {
			$transaction_id = -1;
		}

		//-->INSERT SOLD MEDICINE
		$i = 0;
		$total_medicine_cost = 0;
		if(isset($data['barcode'])) { 
			$ctr = 0; //FOR BATCH_NO
			foreach($data['barcode'] as $b): 
				$qty_var = 'qty_'.$b;
				
				foreach($data[$qty_var] as $q):
					
				  if($q) { 
					$insSoldMedicine_sql = "INSERT INTO tbl_sold_medicine (transaction_id, customer_id, batch_no, medicine_name, user_id, barcode, unit_cost, qty, created_at, medicine_id, supplier_id, doctor_id, company_price, mark_tab, comp_percent, doc_percent, qty_id)
					VALUES (:tid, :cid, :batch, :mname, :uid, :code, :ucost, :qty, :today, :medicine_id,
					:sid, :did, :co_price, :mtab, :coper, :doper, :qty_id)";
					
					$insSoldMedicine = $this->con->prepare($insSoldMedicine_sql);

					$insSoldMedicine->execute(array(
						'tid' => $transaction_id,
						'cid' => $customer_id,
						'batch' => $data['batch_no'][$ctr],
						'medicine_id' => $data['medicine_id'][$ctr],
						'mname' => $data['description'][$i],
						'sid' => $data['supplier_ids'][$ctr],
						'did' => $data['doctor_ids'][$ctr],
						'uid' => $_SESSION['user_id'],
						'co_price' => $data['company_prices'][$i],
						'mtab' => $data['mark_tabs'][$i],
						'coper' => $data['comp_percents'][$i],
						'doper' => $data['doc_percents'][$i],
						'code' => $b,
						'ucost' => $data['unit'][$i],
						'qty' => $q,
						'today' => $transact_date,
						'qty_id' => $data['qty_id'][$ctr],
						
					));
					
					//IF SUCCESS INSERT ADD TOTAL MEDICINE QTY
					if(is_object($insSoldMedicine)) {
						$total_medicine_cost = $total_medicine_cost + ($data['unit'][$i] * $q);	
					}

					 //-->UPDATE CURRENT QUANTITY, MINUS THE MEDICINE SOLD
					$bn = trim($data['batch_no'][$ctr]);
					$updateCurrentQty_sql = "Update tbl_med_qty as t1, 
					(Select current_qty,batch_no from tbl_med_qty where batch_no =:batch 
					 and medicine_id =:mid and qty_id =:qty_id) as t2
					set t1.current_qty = (t2.current_qty - :qty) where t1.batch_no =:batch AND t1.barcode =:code and medicine_id =:mid and qty_id =:qty_id";
					//echo $updateCurrentQty_sql . '<br/>';
					$updateCurrentQty = $this->con->prepare($updateCurrentQty_sql);
					$updateCurrentQty->execute(array(
						'batch' => $bn,
						'qty' => $q,
						'code' => $b,
						'mid' => $data['medicine_id'][$ctr],
						'qty_id' => $data['qty_id'][$ctr],
					));
				 }
			
				$ctr = $ctr + 1;
			
			  endforeach;
				
			$i++;
			endforeach;
		}

		//-->INSERT SERVICES
		if(isset($data['services'])) { 
		
			$insServices_sql = "INSERT INTO tbl_sold_service (transaction_id, customer_id, user_id, services, total_charges, created_at, doctor_id) VALUES(:tid, :cid, :uid, :services, :charges, :today, :doctor)";
			$insServices = $this->con->prepare($insServices_sql);
			$insServices->execute(array(
				'tid' => $transaction_id,
				'cid' => $customer_id,
				'uid' => $_SESSION['user_id'],
				'services' => implode("/",$data['services']),
				'charges' => $data['total-service-fee'],
				'today' => $transact_date,
				'doctor' => $data['doctor']
			));

			//IF SUCCESS INSERT ADD TOTAL MEDICINE QTY
			 if(is_object($insServices)) {
				foreach($data['services'] as $sv):
					$service_data = explode(',',$sv);
					//-->PAYMENTS
					//SERVICES
					if($pay_status == 'Paid') {
						$insPayment_sql = "INSERT INTO tbl_payment (transaction_id, customer_id, amount, created_at, payment_for, service_type, service_id) VALUES (:tid, :cid, :amount, :today, :pfor, :stype, :sid)";
						$insPayment = $this->con->prepare($insPayment_sql);
						$insPayment->execute(array(
							'tid' => $transaction_id,
							'cid' => $customer_id,
							'amount' => $service_data[2],
							'today' => $transact_date,
							'pfor' => 'service',
							'stype' => $service_data[1],
							'sid' => $service_data[0]
						));
					}
				endforeach;
			 }
			
		}

		//-->PAYMENTS
			//MEDICINES
			if($pay_status == 'Paid') {
				if($total_medicine_cost > 0) {
					$insPayment_sql = "INSERT INTO tbl_payment (transaction_id, customer_id, amount, created_at, payment_for) VALUES (:tid, :cid, :amount, :today, :pfor)";
					$insPayment = $this->con->prepare($insPayment_sql);
					$insPayment->execute(array(
						'tid' => $transaction_id,
						'cid' => $customer_id,
						'amount' => $total_medicine_cost,
						'today' => $transact_date,
						'pfor' => 'medicine'
					));
					
				}
			}

			return $transaction_id;

		

	}

	public function transactionList($data) {
		$from = $this->today . ' 00:00:00';
		$to = $this->today . ' 23:59:59';
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		} 

		$sql = "Select tran.*, cust.customer_name, doc.doctor_name, cust.customer_type from tbl_transaction as tran
				LEFT JOIN tbl_customer as cust ON tran.customer_id = cust.customer_id
				LEFT JOIN tbl_doctors as doc ON tran.doctor_id = doc.doctor_id
				";
		$sql .= " WHERE tran.created_at >= '$from' AND tran.created_at <= '$to'";
		$sql .= " order by tran.created_at desc";
		//echo $sql;
		
		$query = $this->con->prepare($sql);
		$query->execute();

		return $query->fetchALL(PDO::FETCH_ASSOC);

		
	}

	public function addPayment($data) {
		$total_paid = 0;
		//-->ADD PAYMENT
		if($data['payment_for'] == 'medicine') {
			$insPayment_sql = "INSERT INTO tbl_payment (transaction_id, customer_id, amount, created_at, payment_for) VALUES (:tid, :cid, :amount, :today, :pfor)";
			$insPayment = $this->con->prepare($insPayment_sql);
			$insPayment->execute(array(
				'tid' => trim($data['tid']),
				'cid' => trim($data['cid']),
				'amount' => $data['amount'],
				'today' => $this->dtime,
				'pfor' => 'medicine'
			));
			$total_paid +=$data['amount'];
				if(is_object($insPayment)) {
					return 1;
				} else {
					return 0;
				}
		} else if($data['payment_for'] == 'service') {
			$b = 0;
			foreach($data['service_id'] as $sid){
				$data['amount'][$b] = trim($data['amount'][$b]);
		
				if(is_numeric($data['service_amount'][$b])) {
					if($data['service_amount'][$b] > 0) {
						$insPayment_sql = "INSERT INTO tbl_payment (transaction_id, customer_id, amount, created_at, payment_for, service_type, service_id) VALUES (:tid, :cid, :amount, :today, :pfor, :stype, :sid)";
						$insPayment = $this->con->prepare($insPayment_sql);
						$insPayment->execute(array(
							'tid' => trim($data['tid']),
							'cid' => trim($data['cid']),
							'amount' => $data['service_amount'][$b],
							'today' => $this->dtime,
							'pfor' => 'service',
							'stype' => $data['service_name'][$b],
							'sid' => $sid
						));

						$total_paid +=$data['service_amount'][$b];
					}
				}

				$b++;
			}
		}

		//-->UPDATE PAID/UNPAID
		if($total_paid >= $data['balance']) {
			$pay_status = 'Paid';
		} else {
			$pay_status = 'Unpaid';
		}

		$sql = "UPDATE tbl_transaction set payment_status=:pstatus where transaction_id =:tid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
				'pstatus' => $pay_status,
				'tid' => trim($data['tid'])
		));


	}

	public function addPatient($data) {
		//INSERT CUSTOMER
		$insCustomer_sql = "INSERT into tbl_customer (user_id, customer_name, customer_type, address, birth, age, place, contact_no, mother, father, created_at, last_visit) VALUES (:uid, :cust_name, :type, :add, :birth, :age, :place, :contact, :mother, :father, :today, :today)";
		$insCustomer = $this->con->prepare($insCustomer_sql);
		$insCustomer->execute(array(
			'uid' => $_SESSION['user_id'],
			'cust_name' => $data['name'],
			'type' => 'patient',
			'add' => $data['address'],
			'birth' => $data['from'],
			'age' => $data['age'],
			'place' => $data['birthplace'],
			'contact' => $data['contact_no'],
			'mother' => $data['mother'],
			'father' => $data['father'],
			'today' => $this->today,
			'last_visit' =>  $this->today
		));
	}

	public function addSupplier($data) {
		$exist = $this->con->prepare("SELECT * FROM tbl_supplier where company_name =:com_name");
		$exist->execute(array(
			'com_name' => $data['company_name']
		));
		
		$company = $exist->fetchALL(PDO::FETCH_ASSOC);
		
		$ret = array();
		if(count($company) >= 1) {
			$ret['result'] = 'error';
			$ret['msg'] = 'Company name already exist';
		} else {
			$up = $this->con->prepare("INSERT INTO tbl_supplier (company_name, contact_no, created_at) VALUES(:com_name, :contact_no, :today)");
			$up->execute(array(
				'com_name' => $data['company_name'],
				'contact_no' => $data['contact_no'],
				'today' => $this->today
			));

			if(!is_object($up)) {
				$ret['result'] = 'error';
				$ret['msg'] = 'Error inserting new supplier';
			} else {
				$ret['result'] = 'success';
				$ret['msg'] = 'Successful data insertion.';
			}
		}

		return json_encode($ret);
	}

	public function addDoctor($data) {
		$up = $this->con->prepare("INSERT INTO tbl_doctors (doctor_name, phone_no, created_at, type) VALUES(:doc_name, :contact_no, :today, :type)");
		$up->execute(array(
			'doc_name' => $data['doctor_name'],
			'contact_no' => $data['contact_no'],
			'today' => $this->today,
			'type' => $data['computation'],
		));

		if(!is_object($up)) {
			$ret['result'] = 'error';
			$ret['msg'] = 'Error inserting new supplier';
		} else {
			$ret['result'] = 'success';
			$ret['msg'] = 'Successful data insertion.';
		}

		return json_encode($ret);
	}

	public function addMedicineQty($data) {
		$med_info = $this->con->prepare("SELECT medicine_id, name FROM tbl_medicines where medicine_id =:mid");
		$med_info->execute(array(
			'mid' => $data['mid']
		));
		
		$med_info = $med_info->fetch(PDO::FETCH_ASSOC);

		$sql = "INSERT INTO tbl_med_qty (medicine_id, medicine_name, barcode, qty, current_qty, batch_no, created_at, expiration, user_id)
				VALUES(:med_id, :med_name, :code, :qty, :cur_qty, :batch, :created_at, :exp, :uid)";
		$add = $this->con->prepare($sql);
		$add->execute(array(
			'med_id' => $med_info['medicine_id'],
			'med_name' => $med_info['name'],
			'code' => $data['barcode'],
			'qty' => $data['qty'],
			'cur_qty' => $data['qty'],
			'batch' => $data['batch_no'],
			'created_at' => date('Y-m-d',strtotime($data['date'])),
			'uid' => $_SESSION['user_id'],
			'exp' => date('Y-m-d',strtotime($data['expiration']))
		));
		
		print_r($med_info['medicine_id']);
		if($add) {
			return 1;
		} else {
			return 0;
		}
	}

	public function addService($data) {
		$up = $this->con->prepare("INSERT INTO tbl_service (description, price, created_at) VALUES(:desc, :price, :today)");
		$up->execute(array(
			'desc' => $data['description'],
			'price' => $data['price'],
			'today' => $this->today
		));

		if(!is_object($up)) {
			$ret['result'] = 'error';
			$ret['msg'] = 'Error inserting new supplier';
		} else {
			$ret['result'] = 'success';
			$ret['msg'] = 'Successful data insertion.';
		}

		return json_encode($ret);
	}

	function paymentToSupplier($data){
		$sql = "Select * from tbl_payment_supplier where barcode =:code AND supplier_id =:sid";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'code' => $data['code'],
			'sid' => $data['sid']
		));
		
		$result = $query->fetchAll(PDO::FETCH_ASSOC);
	
		return $result;
	}

	function paymentToDoctor($data){
		$sql = "Select * from tbl_payment_doctor where barcode =:code AND doctor_id =:did";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'code' => $data['code'],
			'did' => $data['did']
		));
		
		$result = $query->fetchAll(PDO::FETCH_ASSOC);
	
		return $result;
	}

	function addPaySupplier($data) {
		$sql = "INSERT INTO tbl_payment_supplier (supplier_id, barcode, amount, payment_date, created_at, medicine_id) 
		VALUES (:sid, :bcode, :amount, :pdate, :today, :mid)";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'bcode' => $data['barcode'],
			'sid' => $data['sid'],
			'mid' => $data['mid'],
			'amount' => $data['amount'],
			'pdate' => date('Y-m-d', strtotime($data['date'])),
			'today' => $this->today
		));
	}

	function addPayDoctor($data) {
		$sql = "INSERT INTO tbl_payment_doctor (doctor_id, barcode, amount, payment_date, created_at, medicine_id) 
		VALUES (:did, :bcode, :amount, :pdate, :today, :mid)";
		$query = $this->con->prepare($sql);
		$query->execute(array(
			'bcode' => $data['barcode'],
			'did' => $data['did'],
			'mid' => $data['mid'],
			'amount' => $data['amount'],
			'pdate' => date('Y-m-d', strtotime($data['date'])),
			'today' => $this->today
		));
	}
	
	function medicineList_sql(){
		$sql =	 "Select med.*, 
				supp.company_name, 
				doc.doctor_name,
				(Select sum(qty) from tbl_sold_medicine where medicine_id = med.medicine_id AND created_at >:from
				AND created_at <=:to
				) as sold,
				(Select sum(qty) from tbl_sold_medicine where  medicine_id = med.medicine_id
				) as carry_over_sold,
				(Select sum(qty) from tbl_med_qty where  medicine_id = med.medicine_id) as sum_initial_qty,
				(Select sum(amount) from tbl_payment_supplier where 
				supplier_id = med.supplier_id AND medicine_id = med.medicine_id) as supplier_paid,
				(Select sum(current_qty) from tbl_med_qty where  medicine_id = med.medicine_id) as sum_current_qty_old,
				coalesce
				(
					(Select sum(qty) from tbl_med_qty where  medicine_id = med.medicine_id)
					- 
					(Select sum(qty) from tbl_sold_medicine where medicine_id = med.medicine_id),
					(Select sum(qty) from tbl_med_qty where medicine_id = med.medicine_id),
					(Select sum(qty) from tbl_sold_medicine where medicine_id = med.medicine_id),
					0
				) as sum_current_qty,
				(Select sum(amount) from tbl_payment_doctor where 
				doctor_id = med.doctor_id AND medicine_id = med.medicine_id) as doctor_paid
					from tbl_medicines as med
				LEFT JOIN
					tbl_supplier as supp
				ON
					med.supplier_id = supp.supplier_id 
				LEFT JOIN
					tbl_doctors as doc
				ON
					med.doctor_id = doc.doctor_id
				where med.del = 0 ";
		return $sql;
	}

	function medicineList_sql_totalCollectibles($data){
		$sql =	 "Select med.*, 
				supp.company_name, 
				doc.doctor_name,
				(Select sum(qty) from tbl_sold_medicine where medicine_id = med.medicine_id
				) as carry_over_sold,
				(Select sum(amount) from tbl_payment_supplier where 
				supplier_id = med.supplier_id AND medicine_id = med.medicine_id) as supplier_paid
					from tbl_medicines as med
				LEFT JOIN
					tbl_supplier as supp
				ON
					med.supplier_id = supp.supplier_id 
				LEFT JOIN
					tbl_doctors as doc
				ON
					med.doctor_id = doc.doctor_id
				where med.del = 0 AND med.supplier_id = '$data[id]' ";

		return $sql;
	}

	function supplierPaymentAll($data) {
		$sql = "Select company_name from tbl_supplier where supplier_id =:sid";
		$company = $this->con->prepare($sql);
		$company->execute(array(
			'sid' => $data['id']

		));
		$company =  $company->fetch(PDO::FETCH_ASSOC);

		$col_sql = $this->medicineList_sql_totalCollectibles($data);

		if(isset($data['type'])) {
			$col_sql .= " AND med.type = '$data[type]'";
		}

		if(isset($data['doctor'])) {
			$doctor = trim($data['doctor']);
			$col_sql .= " AND med.other_doc_percent like '%*$doctor*%'";
		}

		$col = $this->con->prepare($col_sql);
		$col->execute();
		$col =  $col->fetchAll(PDO::FETCH_ASSOC);

		return array($company, $col);
	}

	function otherDoctorPaymentAll($data) {
		$sql = "Select company_name from tbl_supplier where supplier_id =:sid";
		$company = $this->con->prepare($sql);
		$company->execute(array(
			'sid' => $data['id']

		));
		$company =  $company->fetch(PDO::FETCH_ASSOC);

		$sql = "Select doctor_id from tbl_doctors where doctor_name =:doctor";
		$doctors = $this->con->prepare($sql);
		$doctors->execute(array(
			'doctor' => $data['doctor']

		));
		$doctors =  $doctors->fetch(PDO::FETCH_ASSOC);


		$col_sql = "Select med.*, 
				doc.doctor_name,
				(Select sum(qty) from tbl_sold_medicine where medicine_id = med.medicine_id
				) as carry_over_sold,
				(Select sum(amount) from tbl_payment_doctor where 
				doctor_id = doc.doctor_id AND medicine_id = med.medicine_id) as doctor_paid
					from tbl_medicines as med
				LEFT JOIN
					tbl_doctors as doc
				ON
					med.doctor_id = doc.doctor_id
				where med.del = 0 AND med.supplier_id = '$data[id]'";

		if(isset($data['type'])) {
			$col_sql .= " AND med.type = '$data[type]'";
		}

		if(isset($data['doctor'])) {
			$doctor = trim($data['doctor']);
			$col_sql .= " AND med.other_doc_percent like '%*$doctor*%'";
		}

		$col = $this->con->prepare($col_sql);
		$col->execute();
		$col =  $col->fetchAll(PDO::FETCH_ASSOC);

		return array($company, $col, $doctors);
	}

	function deleteTransaction($data){
		//DELETE TRANSACTION
		$delTran = "Delete from tbl_transaction where transaction_id =:tid";
		$del = $this->con->prepare($delTran);
		$del->execute(array(
			'tid' => $data['id']
		));
		
		//DELETE SOLD MEDICINE AND SERVICE
		if($del) {
			$delSoldMed = "Delete from tbl_sold_medicine where transaction_id =:tid";
			$delSoldMed = $this->con->prepare($delSoldMed);
			$delSoldMed->execute(array(
				'tid' => $data['id']
			));

			$delSoldService = "Delete from tbl_sold_service where transaction_id =:tid";
			$delSoldService = $this->con->prepare($delSoldService);
			$delSoldService->execute(array(
				'tid' => $data['id']
			));
		}

		if($delSoldService) {
			$delPayment = "Delete from tbl_payment where transaction_id =:tid";
			$delPayment = $this->con->prepare($delPayment);
			$delPayment->execute(array(
				'tid' => $data['id']
			));
		}


		if($del) {
			return '1';
		} else {
			return '0';
		}
	}

	function deleteMedicine($data){
		$sql = "Delete from tbl_medicines where medicine_id =:mid";
		$delMedicine = $this->con->prepare($sql);
		$delMedicine->execute(array(
			'mid' => $data['id']
		));

		if($delMedicine) {
			$sqlQty = "Delete from tbl_med_qty where medicine_id =:mid";
			$delQty = $this->con->prepare($sqlQty);
			$delQty->execute(array(
				'mid' => $data['id']
			));
		}

		if($delMedicine) {
			return '1';
		} else {
			return '0';
		}
	}

	function medicinesList($data){
		
		$from = $this->today . ' 00:00:00';
		$to = $this->today . ' 23:59:59';
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		} 
		
	
		$sql = $this->medicineList_sql();
		
		
		
		if(isset($data['product_code'])) {
			
			if($data['product_code']) {
				$data['product_code'] =  mysql_real_escape_string($data['product_code']);
				$sql .= " AND med.barcode = '$data[product_code]'";
			}
			if($data['description']) {
				$data['description'] =  mysql_real_escape_string($data['description']);
				$sql .= " AND med.name like '%$data[description]%'";
			}
			
		}
		if(isset($data['doctor'])) {
			
			if($data['doctor']) {
				$sql .= " AND doc.doctor_name like '%$data[doctor]%'";
				
			}
		}
		if(isset($data['company'])) {
			if($data['company']) {
					$sql .= " AND supp.supplier_id =  '$data[company]'";
				}
		}

		if(isset($data['computation_type'])) {
				$sql .= " AND med.type = '$data[computation_type]'";
				
		}	

		if(isset($data['with_sold'])) {
			if(isset($data['from']) && $data['from']) {
				$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
				$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
			} else {
				$from = '2014-01-01 ' . ' 00:00:00';
				$to = $this->today . ' 23:59:59';
			}
			$sql .= " AND 
				(Select sum(qty) from tbl_sold_medicine where  medicine_id = med.medicine_id AND created_at >=:from
				AND created_at <=:to
				) > 0 ";
		}
		
		//echo $sql;
		$num = $this->con->prepare($sql);
		$num->execute(array(
			'from' => $from,
			'to' => $to

		));
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);

		$total = count($num);
	
		$sql .= " order by created_at asc LIMIT $data[start], $data[pagesize]";
		
		
		
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'from' => $from,
			'to' => $to

		));
		$lists = $list->fetchALL(PDO::FETCH_ASSOC);
	

		return array($lists, $total, $num);

	}

	function editPatient($data) {
		$sql = "Select * from tbl_customer where customer_id =:cid";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'cid' => $data['id']

		));

		return $list->fetch(PDO::FETCH_ASSOC);

	}

	function updatePatient($data) {
		$sql = "Update tbl_customer set customer_name =:cname, address =:adds, age =:age, contact_no =:contact where customer_id =:cid";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'cid' => $data['id'],
			'cname' => $data['name'],
			'adds' => $data['address'],
			'age' => $data['age'],
			'contact' => $data['contact_no']
		));

		
	}

	function paymentAcknow($data) {
		$sql = "Select med.name, med.barcode, supp.company_name, doc.doctor_name from tbl_medicines as med LEFT JOIN tbl_supplier as supp 
		ON med.supplier_id = supp.supplier_id
		LEFT JOIN
		tbl_doctors as doc
		ON med.doctor_id = doc.doctor_id
		where medicine_id =:med_id";
		//echo $sql;
		$num = $this->con->prepare($sql);
		$num->execute(array(
			'med_id' => $data['mid']
		));
		$lists = $num->fetch(PDO::FETCH_ASSOC);

		return $lists;
	}

	function medicinesListPrint($data){
		
		$from = $this->today . ' 00:00:00';
		$to = $this->today . ' 23:59:59';
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		} 
		$sql = $this->medicineList_sql();

		
		if(isset($data['product_code'])) {
			
			if($data['product_code']) {
				$data['product_code'] =  mysql_real_escape_string($data['product_code']);
				$sql .= " AND med.barcode = '$data[product_code]'";
			}
			if($data['description']) {
				$data['description'] =  mysql_real_escape_string($data['description']);
				$sql .= " AND med.name like '%$data[description]%'";
			}
			if($data['company']) {
				$sql .= " AND supp.supplier_id =  '$data[company]'";
			}
		}
		if(isset($data['from'])) {
			
			if($data['doctor']) {
				$sql .= " AND doc.doctor_name like '%$data[doctor]%'";
				
			}
		}

		if(isset($data['computation_type'])) {
				$sql .= " AND med.type = '$data[computation_type]'";
				
		}
		
		//echo $sql;
		$num = $this->con->prepare($sql);
		$num->execute(array(
			'from' => $from,
			'to' => $to

		));
		$num =  $num->fetchALL(PDO::FETCH_ASSOC);
		$total = count($num);
	
		$sql .= " order by created_at asc";
		
		
		
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'from' => $from,
			'to' => $to

		));
		$lists = $list->fetchALL(PDO::FETCH_ASSOC);
	

		return array($lists, $total);

	}

	function supplierAcknow($data){
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		} 
		$sql = "Select med.*,sum(mqty.qty) as sold from tbl_medicines as med
					left join tbl_sold_medicine as mqty ON
					med.medicine_id = mqty.medicine_id
				where med.supplier_id =:sid AND mqty.created_at >=:from AND mqty.created_at <=:to";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'from' => $from,
			'to' => $to,
			'sid' => $data['sid']

		));

		$lists = $list->fetchALL(PDO::FETCH_ASSOC);

		$supplier_name = "Select company_name from tbl_supplier where supplier_id = '$data[sid]'";
		$supplier = $this->con->prepare($supplier_name);
		$supplier->execute();
		$supplier = $supplier->fetch(PDO::FETCH_ASSOC);
		
		return array($lists, $supplier);
	}

	function doctorAcknow($data){
		if(isset($data['from'])) {
			$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
			$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
		} 
		$sql = "Select med.*,sum(mqty.qty) as sold from tbl_medicines as med
					left join tbl_sold_medicine as mqty ON
					med.medicine_id = mqty.medicine_id
				where med.doctor_id =:did AND mqty.created_at >=:from AND mqty.created_at <=:to";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'from' => $from,
			'to' => $to,
			'did' => $data['did']

		));

		$lists = $list->fetchALL(PDO::FETCH_ASSOC);

		$doctor_name = "Select doctor_name from tbl_doctors where doctor_id = '$data[did]'";
		$doctor = $this->con->prepare($doctor_name);
		$doctor->execute();
		$doctor = $doctor->fetch(PDO::FETCH_ASSOC);
		
		return array($lists, $doctor);
	}
	
	function delPaySupplier($data) {
		$sql = "Delete from tbl_payment_supplier where psupplier_id =:pid";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'pid' => $data['pid']

		));

	}

	function delPayDoctor($data) {
		$sql = "Delete from tbl_payment_doctor where pdoctor_id =:pid";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'pid' => $data['pid']

		));
	}

	function totalIncomeAndCompShare($data) {

			$from = $this->today . ' 00:00:00';
			$to = $this->today . ' 23:59:59';
			if($data) {
				$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
				$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
			}
			
			$sql = $this->medicineList_sql();
			$sql .= " AND med.other_doc_percent like '$data[doctor_id]*%' AND med.type = '2' ";
			
			$list = $this->con->prepare($sql);
			$list->execute(array(
				'from' => $from,
				'to' => $to

			));

			$medicines = $list->fetchALL(PDO::FETCH_ASSOC);
			
			$over_all_other_doc_share = 0;$comp_share =0;$gros_patient_bill=0;
			$total_income = 0;$over_all_doc_share = 0;
			foreach($medicines as $row): 
			$percent_mark_up = 1-($row['company_price']-$row['marktab'])/$row['company_price'];
			$clinic_price = $row['company_price']*(1+$percent_mark_up);
			$gros_patient_bill += $clinic_price * $row['sold'];
			$itotalcom = $row['sold']*$row['company_price'];
			$comp_percent = $row['comp_percent']/100;
			$comp_share += $itotalcom * $comp_percent;
			
			$doc_percent = $row['doc_percent']/100;
			$icomshare = $doc_percent * $itotalcom;
			$mark_up_total_sold = $row['marktab'] * $row['sold'];
			$doc_share = $icomshare + $mark_up_total_sold;
			$over_all_doc_share += $doc_share;

			if($row['other_doc_percent']) {
				$row['other_doc_percent'] = substr($row['other_doc_percent'],0,-1);
				$otherDocPercents = explode('|',$row['other_doc_percent']);
				foreach($otherDocPercents as $dp) {
					$info = explode('*', $dp);	
					$over_all_other_doc_share += $itotalcom*($info[2]/100);
				
				}				
			}
			endforeach;
			
			$total_income = $gros_patient_bill-$over_all_other_doc_share-$comp_share;

			$return = array();
			$return['comp_share'] = $comp_share;
			$return['doc_share'] = $over_all_other_doc_share;
			$return['gross_bill'] = $gros_patient_bill;
			$return['total_income'] = $total_income;
			$return['pharmacy_share'] = $over_all_doc_share;

			

			return json_encode($return);
	}

	function summaryCompanyShare($data) {
			$from = $this->today . ' 00:00:00';
			$to = $this->today . ' 23:59:59';
			if($data) {
				$from = date('Y-m-d', strtotime($data['from'])) . ' 00:00:00';
				$to = date('Y-m-d', strtotime($data['to'])) . ' 23:59:59';
			}
			
			$sql = $this->medicineList_sql();
			//$sql .= " AND med.type = '1' ";

			if(isset($data['doctor_id'])) {
				if($data['doctor_id']) {
					$sql .= " AND med.doctor_id = '$data[doctor_id]' ";
				}
				
			}

			$list = $this->con->prepare($sql);
			$list->execute(array(
				'from' => $from,
				'to' => $to

			));

			$medicines = $list->fetchALL(PDO::FETCH_ASSOC);
			
			$total_comp_share = 0;$total_doc_share = 0;
			foreach($medicines as $row){	
				if($row['sold'] > 0) {
					$doc_percent = $row['doc_percent']/100;
					$itotalcom = $row['sold']*$row['company_price'];
					$icomshare = $doc_percent * $itotalcom;
					$mark_up_total_sold = $row['marktab'] * $row['sold'];
					
					$doc_share = $icomshare + $mark_up_total_sold;
					$total_doc_share +=$doc_share;

			
					$comp_percent = $row['comp_percent']/100;
					$comp_share = $itotalcom * $comp_percent;
					$total_comp_share +=$comp_share;
				}
			}

			$return = array();
			$return['comp_share'] = $total_comp_share;
			$return['doc_share'] = $total_doc_share;

			return json_encode($return);
		
	}

	function medicineQuantity($data) {
		$sql = "Select med.*, (Select name from tbl_user where user_id = med.user_id) as user,
			   coalesce
				(
					med.qty - (Select sum(qty) from tbl_sold_medicine where qty_id = med.qty_id),
					med.qty,
					(Select sum(qty) from tbl_sold_medicine where qty_id = med.qty_id),
					0
				) as current_qty_new
		from tbl_med_qty as med where  medicine_id =:mid AND del = 0 order by created_at desc";
		$list = $this->con->prepare($sql);
		$list->execute(array(
			'mid' => $data['mid']	
		));

		return $list->fetchALL(PDO::FETCH_ASSOC);

	}

	function checkBarcode($data) {
		$sql = "Select barcode from tbl_medicines where barcode=:code";
		$exist = $this->con->prepare($sql);
		$exist->execute(array(
			'code' => $data['barcode']
		));

		$count = $exist->fetchALL(PDO::FETCH_ASSOC);

		if(count($count) >= 1) 
			return 1;
		else
			return 0;
	}

	function payAllSupplier($data) {
		$ctr = 0;
		foreach($data['medicine_id'] as $med) {
			$sql = "INSERT INTO tbl_payment_supplier (supplier_id, barcode, amount, payment_date, created_at, medicine_id) 
			VALUES (:sid, :bcode, :amount, :pdate, :today, :mid)";
			$query = $this->con->prepare($sql);
			$query->execute(array(
				'bcode' => $data['barcode'][$ctr],
				'sid' => $data['supplier_id'][$ctr],
				'mid' => $med,
				'amount' => $data['amount'][$ctr],
				'pdate' => $this->dtime,
				'today' => $this->today
			));
			$ctr++;
		}
	}

	function payAllOtherDoctor($data) {
		$ctr = 0;
		foreach($data['medicine_id'] as $med) {
			$sql = "INSERT INTO tbl_payment_doctor (doctor_id, barcode, amount, payment_date, created_at, medicine_id) 
			VALUES (:did, :bcode, :amount, :pdate, :today, :mid)";
			$query = $this->con->prepare($sql);
			$query->execute(array(
				'bcode' => $data['barcode'][$ctr],
				'did' => $data['doctor_id'][$ctr],
				'mid' => $med,
				'amount' => $data['amount'][$ctr],
				'pdate' => $this->dtime,
				'today' => $this->today
			));
			$ctr++;
		}
	}

}