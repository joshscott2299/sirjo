<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$ris = $_GET['ris'] ?? '';
$ris = htmlspecialchars(trim($ris));

$query = mysqli_query(
  $con,
  "SELECT
      i.*,
      b.branch_id,
      b.branch_name   
    FROM itemrequests_head1 i
    LEFT JOIN branch b ON b.branch_id=i.request_to_branch_id 
    WHERE i.ris = '$ris'
    LIMIT 1
  "
) or die(mysqli_error($con));

$item_query = mysqli_query($con, 
  "SELECT 
    i.ris, 
    i.prod_id, 
    i.qty, 
    i.serial, 
    i.qty_issued, 
    i.remarks, 
    -- 
    q.ID, 
    q.item, 
    q.unit_id,
    -- 
    u.unit_id,
    u.unit_name 
  FROM itemrequests_line1 i
  LEFT JOIN qty_general q ON i.prod_id=q.ID
  LEFT JOIN unit_measure u ON q.unit_id=u.unit_id
  WHERE i.ris = '$ris'"
);

$res['data'] = null;
$res['data']['items'] = [];

while ($row = mysqli_fetch_array($query)) {
  $res['data']['status'] = $row['status']; 
  $res['data']['request_to'] = $row['branch_name']; 
  $res['data']['ris'] = $ris; 
  $res['data']['request_date'] = $row['request_date'];
}

while($item = mysqli_fetch_array($item_query)) {
  $res['data']['items'][] = [
    'prod_id'=>$item['prod_id'],
    'serial'=>$item['serial'],
    'item'=>$item['item'],
    'unit_name'=>$item['unit_name'],
    'qty'=>$item['qty'],
    'qty_issued'=>$item['qty_issued'],
    'remarks'=>$item['remarks'],
  ];
}

echo json_encode($res);