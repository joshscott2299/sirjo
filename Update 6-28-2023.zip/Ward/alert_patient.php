<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];

include('../dist/includes/dbcon.php');


	
	
	 mysqli_query($con,"DELETE FROM issue_details WHERE branch_id_from ='$branch' and e_user='$id'");
	

			
					  echo "<script>document.location='patient_select.php'</script>";  
		
?>