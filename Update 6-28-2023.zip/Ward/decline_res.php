
<?php

	session_start();
$branch=$_SESSION['branch'];

include('../dist/includes/dbcon.php');
	
	$rid=$_GET['id'];
	
	
	mysqli_query($con,"update request_itemmicro set request_status='Declined', action_date=NOW() where requestid='$rid' and branch_id_to='$branch'");
	
	
	?>
		<script>
			window.alert('Request Declined!');
			window.history.back();
		</script>
	<?php

?>