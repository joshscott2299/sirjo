<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$ris = $_POST['ris'] ?? 0;
$ris = htmlspecialchars(trim($ris));

mysqli_query(
  $con, "DELETE FROM itemrequests_head1 WHERE ris='$ris';"
);
mysqli_query(
  $con, "DELETE FROM itemrequests_line1 WHERE ris='$ris';"
);
