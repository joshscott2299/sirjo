<?php 
session_start();
$branch=$_SESSION['branch'];
$id=$_SESSION['id'];

include('../dist/includes/dbcon.php');

	$name = $_POST['names'];
	$user = $_POST['user'];
	
	
	  mysqli_query($con,"DELETE FROM temp_dept_csr WHERE branch_from ='$branch' and e_user='$id'");
	 mysqli_query($con,"DELETE FROM issue_details WHERE branch_id_from ='$branch' and e_user='$id'");
	
	$query=mysqli_query($con,"select branch_name,branch_id from branch where branch_id='$name'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);
		$dep=$row['branch_name'];
		
		
	
	
			mysqli_query($con,"INSERT INTO temp_dept_csr(branch_to,branch_from,branch_to_id,e_user) VALUES('$name', '$branch', '$dep', '$user')")or die(mysqli_error($con));

			
					  echo "<script>document.location='cash_transaction_csr.php'</script>";  
		
?>