<?php 
session_start();
include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	$name = $_POST['prod_name'];
	$qty = $_POST['qty'];
	$user = $_POST['user'];

	
	date_default_timezone_set('Asia/Manila');

	$date = date("Y-m-d H:i:s");
	$id=$_SESSION['id'];
	
	
	$query6=mysqli_query($con,"select product_name,description,price,serial,data1,unit_id from product_dept where temp_trans_id='$name'")or die(mysqli_error());
        $row6=mysqli_fetch_array($query6);
		$product1=$row6['product_name'];
		$product2=$row6['description'];
		$product3=$row6['price'];
		$product4=$row6['serial'];
		$product5=$row6['data1'];
		$product6=$row6['unit_id'];
	
	
	
	$query=mysqli_query($con,"select product_name from product_dept where temp_trans_id='$name'")or die(mysqli_error());
        $row=mysqli_fetch_array($query);
		$product=$row['product_name'];
	$remarks="added $qty of $product";  
	
		mysqli_query($con,"INSERT INTO history_log(user_id,action,date) VALUES('$id','$remarks','$date')")or die(mysqli_error($con));
		
		
	mysqli_query($con,"UPDATE product_dept SET qty=qty+'$qty' where temp_trans_id='$name' and branch_id_to='$branch'") or die(mysqli_error($con)); 
			
			mysqli_query($con,"INSERT INTO tbl_return (temp_trans_id,qty_return,date,branch_id,e_user,items,description,price,serial,barcode,unit_id) VALUES('$name','$qty','$date','$branch','$user','$product1','$product2','$product3','$product4','$product5','$product6')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully item added!');</script>";
					  echo "<script>document.location='return.php'</script>";  
	
?>