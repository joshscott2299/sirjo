<!-- Reserve Details -->
<div class="modal" id="item_requests_new_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<?php
	$branch = $_SESSION['branch'];
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content"
			x-data="newItemRequestState()">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">New Item Request</h4>
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<!-- ******************************************** -->
					<div class="row">
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-12">
									<label>Request to:</label>
									<select class="form-control" tabindex="1"
											style="width:100%" id="selRequestTo">
										<option value="1">
											Central Supply Room
										</option>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-12">
									<label>DATE:</label>
									<input type="text" readonly class="form-control form-control-sm" 
										autocomplete="off"
										id="txtRequestDate"
										value="<?php echo date('Y-m-d H:i:s', time()) ;?>"/>
									<br>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-12">
							<h5 style="padding:0;margin:0;color:green;">Select Items</h5>
						</div>
						<div class="form-group col-md-8">
							<select class="form-control select2" tabindex="1"
								style="width:100%"
								id="selItem">
								<?php
									$items = mysqli_query($con, 
										"select * from qty_general 
										natural join unit_measure 
										order by item") 
										or die(mysqli_error($con));
									while ($row = mysqli_fetch_array($items)) {
								?>
									<option value="<?php echo $row['ID']; ?>" 
									<?php
										if ($row['qty'] == 0) {
										 echo 'disabled';
										}
									?>>
									<?php echo $row['item'] . " " . $row['description'] . "&nbsp;[" . $row['unit_name'] . "] Stock#(" . $row['serial'] . $row['barcode'] . ") &nbsp;&nbsp;Qty[" . $row['qty'] . "]"; ?>
									</option>
								<?php } ?>
							</select>
						</div>
						<div class="form-group col-md-2">
							<input type="number" class="form-control" 
								name="" id="txtQuantity"
								x-model="txtquantity"
							/>
						</div>
						<div class="form-group col-md-2">
							<button class="btn btn-success" 
								onclick="addItem()"
								:disabled="txtquantity <=0 ? true : false"
							>Add to Cart</button>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<table id="tblSelectedItems" class="table table-bordered table-striped">
								<thead>
									<tr>
										<th>Serial</th>
										<th>Item</th>
										<th>Unit</th>
										<th>Quantity</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>

					<!-- footer part -->
					<div class="row">
						<?php //print_r($_SESSION); ?>
					</div>
					<!-- ******************************************** -->
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button class="btn btn-success" 
					onclick="submitItemRequest()"
				>
					Submit
				</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

	/**
		Using AlpineJS (test) ******************************
	 */
	function newItemRequestState() {
		return {
			// txtris: '',
			txtquantity: '',
		}
	}
	// *****************************************************

	let selectedItems = [
		// {
		// 	id: '101',
		// 	serial: '1001',
		// 	quantity: 1,
		// 	unit: 'pc',
		// 	unit_id: 1,
		// 	item: 'sample',
		// },
	];

	let payload = {
		// request_to_branch_id: $('#selRequestTo').val(),
		// ris: $('#txtRIS').val(),
		// request_date: $('#txtRequestDate').val(),
		// request_from_branch_id: '<?php echo trim($branch); ?>',
		// requested_by_id: '<?php echo trim($_SESSION['id']); ?>',
		// items: selectedItems,
	}

	function populateSelectedItemsTable(data) {
		
		$('#tblSelectedItems tbody>tr').remove();
		if(selectedItems.length<1) {
			$('#tblSelectedItems').children('tbody').append(`
				<tr>
					<td colspan='5'>No items selected</td>
				</tr>
			`);
		}
		selectedItems.forEach(e => {
			$('#tblSelectedItems').children('tbody').append(`
				<tr>
					<td>${e.serial}</td>
					<td>${e.item}</td>
					<td>${e.unit}</td>
					<td>${e.quantity}</td>
					<td><button class='btn-danger' onclick='removeItem(${e.id})'>x</button></td>
				</tr>
			`);
		});
	}

	function addItem() {
		const quantity = $('#txtQuantity').val();
		if(quantity<1) {
			alert('Please input a quantity!');
			return;
		}
		const selItem = $('#selItem');
		const selItemData = selItem.select2('data');

		$.get(`item_requests_add_item_to_list.php?item_id=${selItemData[0].id}&quantity=${quantity}`)
		.then(response => JSON.parse(response))
		.then(response => {
			console.log(response);
			if(response.success==true) {
				if(findItem(
					{id:response.data[0].id, quantity: quantity}
				) == false) {
					// alert('test');
					selectedItems.push({
						id: response.data[0].id,
						serial: response.data[0].serial,
						quantity: response.data[0].quantity,
						unit: response.data[0].unit,
						unit_id: response.data[0].unit_id,
						item: response.data[0].item,
					});
				}

				populateSelectedItemsTable(selectedItems);

			} else if(response.success==false) {
				alert('Insufficient quantity!');
			}
		});
	}

	function findItem(item) {
		let result = false;

		selectedItems.forEach(e => {
			if (e.id == item.id) {
				e.quantity = item.quantity;
				result = true;
			}
		});
		return result;
	}

	function removeItem(id) {
		let temp = selectedItems.filter(e => {
			return e.id != id;
		});
		selectedItems = temp;
		populateSelectedItemsTable(selectedItems);
	}

	function resetForm() {
		$('#txtRIS').val('');
		selectedItems = [];
	}

	function submitItemRequest() {
		if(selectedItems.length < 1) {
			alert('Please select item(s)');
			return;
		}
		if(!confirm('Done reviewing? Press OK to proceed submitting the item request.')) {
			return;
		}

		payload = {
			request_to_branch_id: $('#selRequestTo').val(),
			// ris: $('#txtRIS').val(),
			request_date: $('#txtRequestDate').val(),
			request_from_branch_id: '<?php echo trim($branch); ?>',
			requested_by_id: '<?php echo trim($_SESSION['id']); ?>',
			items: selectedItems,
		}
		console.log(payload);
		$.ajax({
			url: 'item_requests_submit.php',
			method: 'POST',
			data: payload,
		})
		.done(response => {
			response = JSON.parse(response);
			console.log(response);
			if(response.success==true) {
				alert(response.message);
				// resetForm();
				window.location.reload(true);
			} else {
				alert(response.message);
			}
		})
	}
	
	populateSelectedItemsTable(selectedItems);
</script>
	
