<?php
session_start();
include("../dist/includes/dbcon.php");

$branch=$_SESSION['branch'];
$user=$_SESSION['id'];
$issue = $_POST['branch_name'];



//$pro=mysqli_query($con,"SELECT * FROM temp_trans_mms where branch_id_from='$branch'");
			//$prorow=mysqli_fetch_array($pro);
			//$prod=$prorow['prod_id'];
			//$price=$prorow['price'];
			//$qty=$prorow['qty'];
		//	$from=$prorow['branch_id_from'];
		//	$to=$prorow['branch_id_to'];
			
			
	$c=mysqli_query($con,"SELECT * FROM temp_trans where branch_id_from='$branch'");
	//$rows[]=array();
	
	//while($row=mysqli_fetch_array($c)){
		//$rows[]=$row;
		//$to=$d['branch_id_to'];
		//$price=$d['price'];
		//$from=$d['branch_id_from'];
		//$qty=$d['qty'];
			
			//$pro=mysqli_query($con,"SELECT * FROM temp_trans_mms");
			//$prorow=mysqli_fetch_array($pro);
			//$prod=$prorow['prod_id'];
			//$qty=$prorow['qty'];
			//$price=$prorow['price'];
			//$from=$prorow['branch_id_from'];
			//$to=$prorow['branch_id_to'];
			
			//$query_select=mysqli_query($con,"SELECT * FROM temp_trans_mms");
		
//$result_select = mysqli_query($query_select) or die(mysql_error());
//$rows = array();
//while($row = mysqli_fetch_array($result_select))
    //$rows[] = $row;
	
	foreach($c as $row1):{
		  $prod = $row1['prod_id'];
		  $qty = $row1['qty'];
		  $price = $row1['price'];
		  $from = $row1['branch_id_from'];
		  $to = $row1['branch_id_to'];
		  $desc = $row1['description'];
		  $serial = $row1['serial'];
		  $reorder = $row1['reorder'];
		  $cat = $row1['cat_id'];
		  $initial = $row1['initial_qty'];
	      $issues = $row1['date_issue'];
		  $supp = $row1['supplier_id'];
		  $bal = $row1['balance_qty'];
	      $euser = $row1['e_user'];
		  $toname = $row1['branch_id_toname'];
		  $unit = $row1['unit_id'];
		  $batch = $row1['batch'];
		  $pr = $row1['pr'];
		  $po = $row1['po'];
		  $iar = $row1['iar'];
		  $expiry = $row1['expiry'];
		  $product = $row1['product_name'];
		  $ris = $row1['ris'];
          $rec = $row1['rec_qty'];
		  $receive = $row1['branch_receive'];
	      $bar = $row1['data1'];
					  
			
			
			$query2 = mysqli_query($con,"SELECT * FROM product_micro where serial ='$serial' and branch_id_to='$to'");
			
			$number=mysqli_num_rows($query2);
			
			if ($number > 0)
			{
					mysqli_query($con,"update product_micro set qty=qty+'$qty', initial_qty=initial_qty+'$qty' where serial ='$serial' and branch_id_to='$issue'")or die(mysqli_error());
				
			}
			else 
			{
				
				mysqli_query($con,"INSERT INTO product_micro (prod_id,price,qty,branch_id_from,branch_id_to,description,serial,reorder,cat_id,initial_qty,date_issue,supplier_id,balance_qty,e_user,branch_id_toname,unit_id,batch,pr,po,iar,expiry,product_name,ris,rec_qty,branch_receive,data1) VALUES ('$prod','$price','$qty','$from','$to','$desc','$serial','$reorder','$cat','$initial','$issues','$supp','$bal','$euser','$toname','$unit','$batch','$pr','$po','$iar','$expiry','$product','$ris','$rec','$receive','$bar')")or die(mysqli_error($con));
				
			}
			
	}

	
	// mysqli_query($con,"DELETE FROM temp_trans_mms WHERE branch_id_from ='$branch' and e_user='$user'");
	 endforeach;
	  mysqli_close($con); 
	  
echo "<script>document.location='add_issue_process_phar.php'</script>";  

?>