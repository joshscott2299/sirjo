<?php 
session_start();
$branch=$_SESSION['branch'];
include('../dist/includes/dbcon.php');

date_default_timezone_set('Asia/Manila');

$date = date("Y-m-d H:i:s");

	$name = $_POST['prod_name'];
	$price = $_POST['prod_price'];
	$desc = $_POST['prod_desc'];
	$supplier = $_POST['supplier'];
	$reorder = $_POST['reorder'];
	$category = $_POST['category'];
	$serial = $_POST['serial'];
	$po = $_POST['po'];
	$qty = $_POST['qty'];
	$unit = $_POST['unit'];
	$pr = $_POST['pr'];
	$iar = $_POST['iar'];
	$expire = $_POST['expire'];
	$batch = $_POST['batch'];
	

			mysqli_query($con,"INSERT INTO product(prod_name,unit_id,prod_price,prod_desc,cat_id,prod_qty,current_qty,reorder,supplier_id,branch_id,serial,po,pr,iar,expiry,date_created,batch_no)
			VALUES('$name','$unit','$price','$desc','$category','$qty','$qty','$reorder','$supplier','$branch','$serial','$po','$pr','$iar','$expire','$date','$batch')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new Item!');</script>";
					  echo "<script>document.location='product.php'</script>";  
		
?>