<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<?php

	include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	
	$rid=$_GET['id'];
	
	$riscode=$_POST['riscode'];
	
	$a=mysqli_query($con,"select * from request_itemmicro where requestid='$rid' and branch_id_to='$branch'");
	$b=mysqli_fetch_array($a);
	
	if ($b['ris_code']!=$riscode){
	?>
		<script>
			window.alert('RIS No. did not much!');
			window.history.back();
		</script>
	<?php
	}
	else{
	
	$c=mysqli_query($con,"select * from request_detailmicro where requestid='$rid'");
	$arr=array();
	while($d=mysqli_fetch_array($c)){
		$arr[]=$d['detail_id'];
	}
	
	foreach($arr as $resid):
		$e=mysqli_query($con,"select * from request_detailmicro where detail_id='$resid'");
		$f=mysqli_fetch_array($e);
		$item=$f['stock_name'];
		$req=$f['request_qty'];
		$me=$f['branch_refer'];
		
		mysqli_query($con,"update product_dept set qty=qty-'$req' where product_name='$item' and branch_id_to='$branch'");
		mysqli_query($con,"update product_micro set qty=qty+'$req', initial_qty=initial_qty+'$req' where product_name='$item' and branch_id_to='$me'");
		
	endforeach;
	
		$issues=mysqli_query($con,"select * from product_dept where product_name='$item' and branch_id_to='$branch'");
	$g=mysqli_fetch_array($issues);
	
	
	
	
	mysqli_query($con,"update request_itemmicro set request_status='Confirmed', action_date=NOW() where ris_code='$riscode' and branch_id_to='$branch'");

	
	?>
		<script>
			window.alert('Request Item Confirmed!');
			window.history.back();
		</script>
	<?php
	}
?>