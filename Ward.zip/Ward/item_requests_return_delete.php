<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemreturn_head_id = $_POST['itemreturn_head_id'] ?? 0;
$itemreturn_head_id = htmlspecialchars(trim($itemreturn_head_id));

mysqli_query(
  $con, "DELETE FROM itemreturn_head WHERE itemreturn_head_id='$itemreturn_head_id';"
);
mysqli_query(
  $con, "DELETE FROM itemreturn_line WHERE itemreturn_head_id='$itemreturn_head_id';"
);
