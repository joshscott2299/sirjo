<!-- Reserve Details -->
<div class="modal fade" id="item_requests_view_modal" 
	tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
	x-data="viewItemRequestState()"
	@trigger-get-items.window="getItems($event.detail)"
>
	<?php
	$branch = $_SESSION['branch'];
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content"
		>
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">
					Item Request 
					<span class="badge" x-text="status"></span>
				</h4>

			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-6">
						<div class="row">
							<div class="col-md-12">
								<label>Request To: <span x-text="request_to"></span></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<div class="col-md-12">
								<label>RIS #: <span x-text="ris"></span></label>
							</div>
							<div class="col-md-12">
								<label>Date: <span x-text="request_date"></span></label>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<hr>
						<em x-show="items.length<1">No items to display...</em>
						<table class="table table-bordered" x-show="items.length>0">
							<thead>
								<tr>
									<th>Serial</th>
									<th>Item</th>
									<th>Unit</th>
									<th>Requested Quantity</th>
									<th>Quantity Issued</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<template x-for="item in items" :key="item.prod_id">
									<tr>
										<td x-text="item.serial"></td>
										<td x-text="item.item"></td>
										<td x-text="item.unit_name"></td>
										<td x-text="item.qty"></td>
										<td x-text="item.qty_issued"></td>
										<td x-text="item.remarks"></td>
									</tr>
								</template>
							</tbody>
						</table>
					</div>
					<br>
					<div class="col-md-12">
						<div class="row">
							<div class="col-sm-4">
								<label>Ward/Unit: <span x-text="request_from_branch_id"></span></label>
								<br>
								<label>Requested By: <span x-text="requested_by_id"></span></label>
							</div>
							<div class="col-sm-4">
								<br>
								<label>Received By: <span x-text="received_by_id"></span></label>
							</div>
							<div class="col-sm-4">
								<br>
								<label>Issued By: <span x-text="issued_by_id"></span></label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>

			<script>

			</script>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

/**
Using AlpineJS (test) ***************************************
*/

// function viewItemRequestState() {
function viewItemRequestState() {
	return {
	// window.viewItemRequestState = {
		status: '',
		request_to: '',
		ris: '',
		request_date: '',
		items: [
			// {
				// prod_id: '',
				// serial: '',
				// item: '',
				// unit_name: '',
				// qty: '',
				// qty_issued: '',
				// remarks: '',
				// ward: '',
				// requested_by: '',
				// issued_by: '',
			// }
		],

		getItems(itemrequests_head_id) {
			console.log('getItemRequest invoked... ' + itemrequests_head_id);
			$.get(`item_requests_view.php?itemrequests_head_id=${itemrequests_head_id}`)
			.done(response=>{
				response = JSON.parse(response);
				console.log(response);
				// console.log(viewItemRequestState);
				this.ris = response.data.ris;
				this.request_to = response.data.request_to;
				this.request_date = response.data.request_date;
				this.items = response.data.items;
				this.status = response.data.status;
			});
		}
	}
}

// *****************************************************

</script>
	
