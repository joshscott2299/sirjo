<?php
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
include("../dist/includes/dbcon.php");
$id = $_REQUEST['id'];
$cid = $_POST['cid'];
$qty = $_REQUEST['qty'];
$name = $_REQUEST['name'];

mysqli_query($con,"UPDATE product_dept SET qty=qty+'$qty' where temp_trans_id='$name' and branch_id_to='$branch'") or die(mysqli_error($con)); 

mysqli_query($con,"DELETE FROM temp_trans WHERE temp_trans_id ='$id'")
	or die(mysqli_error($con));
	
echo "<script>document.location='cash_transaction.php?cid=$cid'</script>";  
?>
