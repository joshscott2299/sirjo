<?php
session_start();
$id=$_SESSION['id'];
$branch=$_SESSION['branch'];
include("../dist/includes/dbcon.php");
$cid = $_POST['cid'];
$qty = $_REQUEST['qty'];
$temp_trans_id = $_REQUEST['temp_trans_id'];

// mysqli_query($con,"UPDATE product_dept SET qty=qty+'$qty' where temp_trans_id='$temp_trans_id' and branch_id_to='$branch'") or die(mysqli_error($con)); 
mysqli_query($con,"UPDATE qty_ward SET qty=qty+'$qty' where qty_ward_id='$temp_trans_id' and branch_id='$branch'") or die(mysqli_error($con)); 

mysqli_query($con,"DELETE FROM temp_trans_patient_phar WHERE temp_trans_id ='$temp_trans_id'")
	or die(mysqli_error($con));
	
echo "<script>document.location='patient_issue.php?cid=$cid'</script>";  
?>
