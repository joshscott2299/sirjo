<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
if(empty($_SESSION['branch'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Issuances | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    
    <style type="text/css">
      tr td{
        padding-top:-10px!important;
        border: 1px solid #000;
        
      }
      @media print {
          .btn-print {
            display:none !important;
		  }
		  .main-footer	{
			display:none !important;
		  }
		  .main-title	{
			display:none !important;
		  }
		  .box.box-primary angel {
			  border-top:none !important;
		  }
		  
          
      }
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onfocus="window.close()">
<div class="wrapper">      
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="responsive">
          <section class="content">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-12">

                </div>
                
                <div class="box-body">

                  <!-- Date range -->
                  <form method="post" action="">
                    <?php
                    include('../dist/includes/dbcon.php');
                    $id=$_SESSION['id'];
                    
						
						$ward=$_POST['ward'];
                        $date=$_POST['date'];    
                        $date=explode('-',$date);
                        $start=date("Y/m/d",strtotime($date[0]));
                        $end=date("Y/m/d",strtotime($date[1]));
                       
                            
                    ?>
                    <table class="table">
                      <thead>
                          <pull-left><img src="/img/gcgmh.png" style="width:300px; height:50px;"></pull-left>                     
                        <center>    
											
                            <h5><b>WARD ISSUANCES REPORT (RIS)</b></h5>
                            <h6>CENTRAL SUPPLY ROOM</h6> 
							<h5 class="text-center"><b> <?php echo $ward;?></b></h5>
							
                            <h4 class="text-center">From <?php echo date("M d, Y",strtotime($start))." To ".date("M d, Y",strtotime($end));?></h4>
                        </center>                     
                      </thead>                    
                    </table>

                    <table width="100%" class="table-bordered" id="invent" style="font-size:11px;">
                      <thead>         
                        <tr style="border: solid 1px #000">
						  <td class="text-center"><b>Date Issue</b></td>  
						  <td class="text-center"><b>Stock Number</b></td>    
                          <td class="text-center"><b>Product Name</b></td>           
                          <td class="text-center"><b>Unit</b></td>                       
                          <td class="text-center"><b>RIS #</b></td>
                          
                          <td class="text-center"><b>Qty Issued</b></td>
                          <!--<td class="text-center"><b>Unit Cost</b></td>                      
                          <td class="text-center"><b>Total Cost</b></td>-->
                        </tr>
                      </thead>
                      <tbody>
                            <?php
                            $branch=$_SESSION['branch'];
                            $user=$_SESSION['id'];
                            $date=$_POST['date'];
                            $ward=$_POST['ward'];
                            $date=explode('-',$date);
                            $start=date("Y/m/d",strtotime($date[0]));
                            $end=date("Y/m/d",strtotime($date[1]));
                           
                            $grand=0;
                            $grand1=0;
                            if ($ward == '0') {
                                $query=mysqli_query($con,"SELECT `product_name`,`description`,`qty`,`ris`,`balance_qty`,`date_issue`,`serial`,`unit_name`,`branch_id_to`, SUM(qty) AS QTY from `issue_item_supply_issuance` NATURAL JOIN `unit_measure` NATURAL JOIN `supplier` WHERE date(date_issue)>='$start' AND date(date_issue)<='$end' GROUP BY product_name, serial ASC")or die(mysqli_error($con));
                            }else{
                                $query=mysqli_query($con,"SELECT `product_name`,`description`,`qty`,`ris`,`balance_qty`,`date_issue`,`serial`,`unit_name`,`branch_id_to`, SUM(qty) AS QTY from `issue_item_supply_issuance` NATURAL JOIN `unit_measure` NATURAL JOIN `supplier` WHERE (date(date_issue)>='$start' AND date(date_issue)<='$end') AND `branch_id_to`='$ward' GROUP BY `serial` ORDER BY 'product_name'")or die(mysqli_error($con));
                            }                                     
                                        
                            while($row=mysqli_fetch_array($query)){
                                //$id=$row['temp_trans_id'];
								
                                $qty= $row['QTY'];
                                $total= $row['balance_qty']-$row['QTY'];
                                //$total_cost= $qty * $row['price'];
                                //$grand+=$total_cost;
                                //$grand1+=$qty;
                            ?>
                            
                            <tr>
							  <td style="text-align:center"><?php echo $row['date_issue'];?></td> 
							  <td style="text-align:center"><?php echo $row['serial'];?></td> 
                              <td style="text-align:left"><?php echo $row['product_name'];?></td>                     
                              <td style="text-align:center"><?php echo $row['unit_name'];?></td>                     
                              <td style="text-align:center"><?php echo $row['ris'];?></td>
                              
                              <td style="text-align:center"><?php echo $row['qty'];?></td>
                              <!--<td style="text-align:center"><?php echo number_format($row['price'],2);?></td>                       
                              <td style="text-align:center"><?php echo number_format($total_cost,2);?></td>-->
                            </tr>
                            <?php }?>

                            <!--<tr>
                                <td colspan="3">Overall Total</td>
                                <td colspan="1" style="text-align:center"><?php echo number_format($grand1);?></td>
                                <td colspan="1"></td>             
                                <td colspan="1" style="text-align:center">&#8369;<?php echo number_format($grand,2);?></td>
                                      
                            </tr>-->
                      </tbody>           
                      <th colspan="3" style="font-size:9px"></th>                        
                      <th colspan="2" style="font-size:9px"></th>
                      <th colspan="1" style="font-size:9px"></th>                      
                    </table>
                  </form>
                </div><!-- /.box-body -->
              </div>          
            </div><!-- /.box-body -->
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-12">
                  <a class = "btn btn-primary btn-print" href = "report_ris.php"><i class ="glyphicon glyphicon-arrow-left"></i> Back to Homepage</a>
                  <button name="create_excel" id="create_excel" class="btn btn-success" onclick="create_Excel()">Export (for excel)</button>
                </div>
              </div>
            </div>
          </section><!-- /.content -->      
                
        </div><!-- /.box -->
      </div><!-- /.col (right) -->           
    </div>
	
	
	<script type="text/javascript" src="autosum.js"></script>
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<script src="../dist/js/jquery.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
   <script>
   $(document).ready(function() {
      $("#catList").on('change', function() {
        if ($(this).val() == 0) {
          window.location = 'stockcard_ris.php';
        } else {
          window.location = 'stockcard_ris.php?branch_id=' + $(this).val();
        }
      });
    });

    $(function() {
      $("#example1").DataTable();
      $('#invent').DataTable({
        "paging": false,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "deferRender": true,
        initComplete: function(){
          $("#loader").hide();
        }
      });


    });
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
  });
</script>
  </body>
</html>