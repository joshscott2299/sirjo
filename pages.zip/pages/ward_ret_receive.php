<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemreturn_head_id = $_POST['itemreturn_head_id'] ?? 0;
$itemreturn_head_id = htmlspecialchars(trim($itemreturn_head_id));

$received_by_id = $_POST['received_by_id'] ?? 0;
$received_by_id = htmlspecialchars(trim($received_by_id));

$dateToday = date('Y-m-d H:i:s', time());

mysqli_query(
  $con, "UPDATE itemreturn_head 
    SET status = 'Received', received_by_id = '$received_by_id',
      receive_date = '$dateToday'   
    WHERE itemreturn_head_id=$itemreturn_head_id;"
);
mysqli_query(
  $con, "UPDATE itemreturn_line 
    SET status = 'Received' 
    WHERE itemreturn_head_id=$itemreturn_head_id;"
);

echo 'Done';
