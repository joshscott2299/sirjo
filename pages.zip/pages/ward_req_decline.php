<?php
// header('Content-Type:application/json');
include_once('../dist/includes/dbcon.php');

$itemrequests_head_id = $_POST['itemrequests_head_id'] ?? 0;
$itemrequests_head_id = htmlspecialchars(trim($itemrequests_head_id));

$remarks = $_POST['remarks'] ?? 'N/A';
$remarks = htmlspecialchars(trim($remarks));

$dateToday = date('Y-m-d H:i:s', time());

mysqli_query(
  $con, "UPDATE itemrequests_head 
    SET status = 'Declined', remarks = '$remarks', decline_date='$dateToday'   
    WHERE itemrequests_head_id=$itemrequests_head_id;"
);
mysqli_query(
  $con, "UPDATE itemrequests_line 
    SET status = 'Declined' 
    WHERE itemrequests_head_id=$itemrequests_head_id;"
);

echo 'Done';
