<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;

include_once('../dist/includes/dbcon.php');

$itemreturn_head_id = $_GET['itemreturn_head_id'] ?? '';
$itemreturn_head_id = htmlspecialchars(trim($itemreturn_head_id));
$itemreturn_head_id = intval($itemreturn_head_id);

$query = mysqli_query(
  $con,
  "SELECT
      i.*,
      bf.branch_id as bf_branch_id,
      bf.branch_name as bf_branch_name,
      bt.branch_id as bt_branch_id,
      bt.branch_name as bt_branch_name,
      ureq.user_id, ureq.name as ureq_name,
      urec.user_id, urec.name as urec_name,
      uiss.user_id, uiss.name as uiss_name
    FROM itemreturn_head i 
    LEFT JOIN branch bf ON bf.branch_id=i.request_from_branch_id 
    LEFT JOIN branch bt ON bt.branch_id=i.request_to_branch_id 
    LEFT JOIN user ureq ON ureq.user_id=i.requested_by_id 
    LEFT JOIN user urec ON urec.user_id=i.received_by_id 
    LEFT JOIN user uiss ON uiss.user_id=i.issued_by_id 
    WHERE i.itemreturn_head_id = $itemreturn_head_id 
    LIMIT 1
  "
) or die(mysqli_error($con));

$item_query = mysqli_query(
  $con,
  "SELECT 
    i.*,
    q.ID, 
    q.item, 
    q.unit_id,
    q.cat_id,
    q.qty as remaining_qty,
    u.unit_id,
    u.unit_name,
    c.cat_id,
    c.cat_name 
  FROM itemreturn_line i
  LEFT JOIN qty_general q ON i.prod_id=q.ID
  LEFT JOIN unit_measure u ON q.unit_id=u.unit_id
  LEFT JOIN category c ON c.cat_id=q.cat_id
  WHERE i.itemreturn_head_id = $itemreturn_head_id"
);

$res = null;
$res['items'] = [];

while ($row = mysqli_fetch_array($query)) {
  $res['status'] = $row['status'];
  $res['request_from'] = $row['bf_branch_name'];
  $res['request_to'] = $row['bt_branch_name'];
  $res['request_from_branch_id'] = intval($row['request_from_branch_id']);
  $res['request_to_branch_id'] = intval($row['request_to_branch_id']);
  $res['ris'] = $row['ris'];
  $res['request_date'] = $row['request_date'];
  $res['issue_date'] = $row['issue_date'];
  $res['issued_by'] = $row['uiss_name'];
  $res['issued_by_id'] = intval($row['issued_by_id']);
  $res['received_by'] = $row['urec_name'];
  $res['received_by_id'] = intval($row['received_by_id']);
  $res['requested_by'] = $row['ureq_name'];
  $res['requested_by_id'] = intval($row['requested_by_id']);
  $res['itemreturn_head_id'] = intval($itemreturn_head_id);
}

while ($item = mysqli_fetch_array($item_query)) {
  $res['items'][] = [
    'prod_id' => $item['prod_id'],
    'serial' => $item['serial'],
    'item' => $item['item'],
    'unit_id' => $item['unit_id'],
    'unit_name' => $item['unit_name'],
    'remaining_qty' => intval($item['remaining_qty']),
    'qty' => intval($item['qty']),
    'qty_issued' => intval($item['qty_issued']),
    'remarks' => $item['remarks'],
    'itemreturn_head_id' => intval($itemreturn_head_id),
  ];
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>RETURNS | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">

  <style type="text/css">

    table.items-table tr td {
      /* padding-top: -10px !important; */
      border: 1px solid #000;
    }

    .header,
    .header-spacer,
    .footer,
    .footer-spacer {
      height: 150px;
    }

    .header {
      position: fixed;
      top: 0;
    }

    .footer {
      position: fixed;
      bottom: 0;
    }

    @media print {
      .btn-print {
        display: none !important;
      }
    }
  </style>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onafterprint="window.close()">

  <!-- HEAD //////////////////////////////////////////////////////////-->
  <div class="header">
    <h4 class="modal-title" id="myModalLabel">
      <img src="/img/gcgmh.png" style="width:250px; height:55px;">
    </h4>
    <br>
    <div class="row">
      <div class="col-xs-4">
        <div class="row">
          <div class="col-xs-12">
            <label>Name of Patient: __________ <span>
            
              </span></label>
          </div>
          <div class="col-xs-12">
            <label> <span>
                
              </span></label>
          </div>

        </div>
      </div>
      <div class="col-xs-4">
        <div class="row">
          <div class="col-xs-12 pull-right">
            <label class="pull-rightx">Hospital No.:________ <span>
              
              </span></label>
          </div>
          <div class="col-xs-12 pull-right">
            <label class="pull-rightx"><span>
              
              </span></label>
          </div>
        </div>
      </div>
       <div class="col-xs-4">
        <div class="row">
          <div class="col-xs-12 pull-right">
            <label class="pull-rightx">Ward/Unit:________ <span>
              
              </span></label>
          </div>
          <div class="col-xs-12 pull-right">
            <label class="pull-rightx"><span>
              
              </span></label>
          </div>
        </div>
      </div>

      <div class="col-xs-12" style="border-top:5px solid #f3f3f3;">
        
      </div>
    </div>
  </div>
  <!-- /HEAD //////////////////////////////////////////////////////////-->


  <!-- BODY ////////////////////////////////////////////////////////// -->
  <table>
    <thead>
      <tr>
        <td>
          <div class="header-spacer">&nbsp;</div>
        </td>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <div class="content">
            <div class="row">
              <div class="col-xs-12">
                <table class="table table-bordered table-hover items-table"">
                  <thead>
                    <tr>
                     <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;&nbsp;&nbsp;&nbsp;</th>
                      <center>
                        <th>Unit</th>
                      </center>
                      <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Medicine/Supplies Returned&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                      <center>
                        <th>Quantity Returned</th>
                      </center>
                      <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remarks&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($res['items'] as $item) : ?>
                        <tr>
                          
                          <td>
                            <center> <span><?php echo $item['qty']; ?></span> </center>
                          </td>
                          <td><?php echo $item['unit_name']; ?></td>
                          <td><?php echo $item['item']; ?></td>
                          <td>
                            <center> <span><?php echo $item['qty_issued']; ?></span></center>
                          </td>
                          <td>
                            <span><?php echo $item['remarks']; ?></span>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </td>
      </tr>
    </tbody>
    <tfoot>
      <tr>
        <td>
          <div class="footer-spacer">&nbsp;</div>
        </td>
      </tr>
    </tfoot>
  </table>
  <!-- /BODY ////////////////////////////////////////////////////////// -->
  <div class="col-xs-12">
      <!-- <div class="row"> -->
      <div class="col-xs-6">
        <label>Returned:_______________ </label><br><br>
        <span><?php echo $res['requested_by']; ?></span>
        <span>Signature over Printed Name (Ward Staff on Duty)</span>
      </div>
       <div class="col-xs-6">
        <label>Date & Time:_______________ </label>
        </div>
        </div>
        <div class="col-xs-12">
      <div class="col-xs-6">
       <br></br>
        <label>Received:</label><br><br>
        <span><?php echo $res['received_by']; ?></span>
        <span>Signature over Printed Name (Ward Staff on Duty)</span>
      </div>
      <br></br>
       <div class="col-xs-6">
        <label>Date & Time:_______________ </label>
        </div>
        </div>
        <div class="col-xs-12">
      <div class="col-xs-6">
        <br><br>
        <label class="pull-rightx">Encoded:________________ </label><br><br>
        <span><?php echo $res['issued_by']; ?></span>
        <span>Signature over Printed Name (Ward Staff on Duty)</span>
      </div>
      <br></br>
       <div class="col-xs-6">
        <label>Date & Time:_______________ </label>
        </div>
        </div>
      <!-- </div> -->
    </div>
    <div>&nbsp;</div>
    
     <Center>
      <th>
        <font size="1">Effectivity Date:</pull-left>
      </th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <th>
        <font size="1">Rev. No: 
      </th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <th>
        <font size="1">GCGMH-F-NUR-__
      </th>
    </center>

  <!-- FOOT /////////////////////////////////////////////////////////// -->
  <div class="footer">
  
   
  </div>
  <!-- /FOOT /////////////////////////////////////////////////////////// -->

  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
</body>

</html>