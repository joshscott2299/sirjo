<div class="modal fade" id="ward_ret_view_modal" 
	tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
	x-data="viewItemRetRequestState()"
	@trigger-get-items.window="getItems($event.detail)"
	@trigger-decline-request.window="declineRequest($event.detail)">
	<?php
	$branch = $_SESSION['branch'];
	?>
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">
					Item Return Request 
					<span class="badge" x-text="status"></span>
				</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-xs-6">
						<div class="row">
							<div class="col-xs-12">
								<label>Request To: <span x-text="request_to"></span></label>
							</div>
							<div class="col-xs-12">
								<label>Request Date: <span x-text="request_date"></span></label>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label style="">RTN NO. </label>
									<input type="text" 
										class="form-control form-control-sm" 
										x-model="ris"
										stylexxx="max-width: 200px;">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12" style="border-top:1px solid #f3f3f3;">
						<center>
							<h5 style="padding:0;margin-top:8px;">
								RETURN SLIP
							</h5>
						</center>
					</div>
					<div class="col-sm-12">
						<em x-show="items.length<1">No items to display...</em>

						<!-- predef remarks -->
						<datalist id="lstPredefRemarks">
						    <option>Ok</option>
							<option>Cancelled</option>
						</datalist>

						<table class="table table-bordered table-striped table-hover" 
							x-show="items.length > 0">
							<thead>
								<tr>
								    <th>Item</th>
									<th>Quantity</th>
									<th>Unit</th>
									<th>Qty. Issued</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<template x-for="item in items" :key="item.prod_id">
									<tr :style="item.error==1?'color:red;':''">
										<td x-text="item.item" :title="'Remaining stock quantity: ' + item.remaining_qty">
											<span>
										</td>
										<td>
											<span x-text="item.qty"></span>
											<button 
												title="Issue all qty"
												class="btn btn-xm btn-default pull-right"
												style="margin-left:8px;padding:0px 4px;"
												@click="
													if(item.qty > item.remaining_qty) {
														item.qty_issued=item.remaining_qty
													} else {
														item.qty_issued=item.qty;
													}
												">
												>>
											</button>
										</td>
										<td x-text="item.unit_name"></td>
										<td>
											<input type="number" 
												x-model="item.qty_issued"
												class="form-control form-control-sm"
												style="min-width:80px;"
												min="1"
												:max="item.qty"
												@keyup="
													if(item.qty_issued > item.remaining_qty || item.qty_issued > item.qty || item.qty_issued < 0) {
														item.qty_issued=item.remaining_qty;
													}
													if(item.qty_issued == '') {
														item.qty_issued = 0;
													}
												"
											/>
										</td>
										<td>
											<input type="text" 
												x-model="item.remarks"
												list="lstPredefRemarks" 
												class="form-control form-control-sm"
												style="max-width:100%;"
											/>
										</td>
									</tr>
								</template>
							</tbody>
						</table>
					</div>
					<br>
					<div class="col-sm-12">
						<div class="row">
							<div class="col-xs-4">
							    <label>Ward/Unit: 
								<span x-text="request_from"></span></label>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-4">
							    <label>Requested By:
								<span x-text="requested_by"></span></label>
							</div>
							<div class="col-xs-4">
								<label>Returned By:
								<span x-text="received_by"></span></label>
							</div>
							<div class="col-xs-4">
								<label class="pull-rightx">Received By:
								<span x-text="issued_by"></span></label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="height:5px;"></div>
			<div class="modal-footer">
				<button class="btn btn-success" @click="submit()"
					:disabled="ris==''">
					Submit
				</button>
				<button class="btn btn-default" data-dismiss="modal">
					<i class="fa fa-times"></i> Close
				</button>
			</div>

		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>

/**
Using AlpineJS (test) ***************************************
*/

// function viewItemRequestState() {
function viewItemRetRequestState() {
	return {
	// window.viewItemRequestState = {
		status: '',
		request_to: '',
		request_to_branch_id: '',
		request_from: '',
		request_from_branch_id: '',
		requested_by: '',
		received_by: '',
		issued_by: '',
		requested_by_id: '',
		received_by_id: '',
		issued_by_id: '',
		ris: '',
		request_date: '',
		issue_date: '',
		remarks: '',
		items: [
			// {
				// prod_id: '',
				// serial: '',
				// item: '',
				// unit_name: '',
				// remaining_qty: '',
				// qty: '',
				// qty_issued: '',
				// remarks: '',
				// error: 0,
			// }
		],
		itemreturn_head_id: 0,
		

		getItems(itemreturn_head_id) {
			console.log('getItems invoked... ' + itemreturn_head_id);
			$.get(`ward_ret_view.php?itemreturn_head_id=${itemreturn_head_id}`)
			.done(response=>{
				response = JSON.parse(response);
				console.log(response);
				// console.log(viewItemRequestState);
				this.ris = response.data.ris;
				this.request_date = response.data.request_date;
				this.items = response.data.items;
				this.status = response.data.status;
				this.request_from = response.data.request_from;
				this.request_to = response.data.request_to;
				this.request_from_branch_id = response.data.request_from_branch_id;
				this.request_to_branch_id = response.data.request_to_branch_id;
				this.requested_by = response.data.requested_by;
				this.issued_by = response.data.issued_by;
				this.requested_by_id = response.data.requested_by_id;
				this.issued_by_id = response.data.issued_by_id;
				this.issue_date = response.data.issue_date;

				this.itemreturn_head_id = response.data.itemreturn_head_id;
			});
		},

		declineRequest(itemreturn_head_id) {
			if(!confirm('Are you sure you want to decline this request?')) {
				return;
			}

			let remarks = prompt('Remarks:', '');
			if(remarks == null) {
				return;
			}

			$.post(`ward_ret_decline.php`,{
				itemreturn_head_id: itemreturn_head_id,
				remarks: remarks
			})
			.done(response => {
				window.location.reload(true);
			});
		},

		submit() {
			console.log('invoking submit()...');
			if(!confirm('Are you sure you want to confirm this request?')) {
				return;
			}
			$.post('ward_ret_submit.php', {
				request_to_branch_id: this.request_to_branch_id,
				ris: this.ris,
				request_date: this.request_date,
				issue_date: this.issue_date,
				request_from_branch_id: this.request_from_branch_id,
				request_from: this.request_from,
				requested_by_id: this.requested_by_id,
				received_by_id: this.received_by_id,
				issued_by_id: this.issued_by_id,
				status: 'Confirmed',
				remarks: this.remarks,
				items: this.items,
				itemreturn_head_id: this.itemreturn_head_id
			}).done(res => {
				res = JSON.parse(res);
				console.log(res);
				 window.location.reload(true);
			});
		}
	}
}

// ****************************************************

</script>
	
