<?php session_start();
if (empty($_SESSION['id'])) :
  header('Location:../index.php');
endif;
if (empty($_SESSION['branch'])) :
  header('Location:../index.php');
endif;

include_once('../dist/includes/dbcon.php');

$itemrequests_head_id = $_GET['itemrequests_head_id'] ?? '';
$itemrequests_head_id = htmlspecialchars(trim($itemrequests_head_id));
$itemrequests_head_id = intval($itemrequests_head_id);

$query = mysqli_query(
  $con,
  "SELECT
      i.*,
      bf.branch_id as bf_branch_id,
      bf.branch_name as bf_branch_name,
      bt.branch_id as bt_branch_id,
      bt.branch_name as bt_branch_name,
      ureq.user_id, ureq.name as ureq_name,
      urec.user_id, urec.name as urec_name,
      uiss.user_id, uiss.name as uiss_name
    FROM itemrequests_head i 
    LEFT JOIN branch bf ON bf.branch_id=i.request_from_branch_id 
    LEFT JOIN branch bt ON bt.branch_id=i.request_to_branch_id 
    LEFT JOIN user ureq ON ureq.user_id=i.requested_by_id 
    LEFT JOIN user urec ON urec.user_id=i.received_by_id 
    LEFT JOIN user uiss ON uiss.user_id=i.issued_by_id 
    WHERE i.itemrequests_head_id = $itemrequests_head_id 
    LIMIT 1
  "
) or die(mysqli_error($con));

$item_query = mysqli_query(
  $con,
  "SELECT 
    -- i.ris, 
    -- i.prod_id, 
    -- i.qty, 
    -- i.serial, 
    -- i.qty_issued, 
    -- i.remarks,
    --  
    i.*,
    -- 
    q.ID, 
    q.item, 
    q.unit_id,
    q.cat_id,
    q.qty as remaining_qty,
    -- 
    u.unit_id,
    u.unit_name,
    --  
    c.cat_id,
    c.cat_name 
  FROM itemrequests_line i
  LEFT JOIN qty_general q ON i.prod_id=q.ID
  LEFT JOIN unit_measure u ON q.unit_id=u.unit_id
  LEFT JOIN category c ON c.cat_id=q.cat_id
  WHERE i.itemrequests_head_id = $itemrequests_head_id"
);

$res = null;
$res['items'] = [];

while ($row = mysqli_fetch_array($query)) {
  $res['status'] = $row['status'];
  $res['request_from'] = $row['bf_branch_name'];
  $res['request_to'] = $row['bt_branch_name'];
  $res['request_from_branch_id'] = intval($row['request_from_branch_id']);
  $res['request_to_branch_id'] = intval($row['request_to_branch_id']);
  $res['ris'] = $row['ris'];
  $res['request_date'] = $row['request_date'];
  $res['issue_date'] = $row['issue_date'];
  $res['issued_by'] = $row['uiss_name'];
  $res['issued_by_id'] = intval($row['issued_by_id']);
  $res['received_by'] = $row['urec_name'];
  $res['received_by_id'] = intval($row['received_by_id']);
  $res['requested_by'] = $row['ureq_name'];
  $res['requested_by_id'] = intval($row['requested_by_id']);
  $res['itemrequests_head_id'] = intval($itemrequests_head_id);
}

while ($item = mysqli_fetch_array($item_query)) {
  $res['items'][] = [
    'prod_id' => $item['prod_id'],
    'serial' => $item['serial'],
    'item' => $item['item'],
    'unit_id' => $item['unit_id'],
    'unit_name' => $item['unit_name'],
    'remaining_qty' => intval($item['remaining_qty']),
    'qty' => intval($item['qty']),
    'qty_issued' => intval($item['qty_issued']),
    'remarks' => $item['remarks'],
    'itemrequests_head_id' => intval($itemrequests_head_id),
  ];
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>RIS | <?php include('../dist/includes/title.php'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">

  <style type="text/css">
    tr td {
      padding-top: -10px !important;
      border: 1px solid #000;
    }

    @media print {
      .btn-print {
        display: none !important;
      }
    }
  </style>
</head>

<body class="hold-transition skin-blue layout-top-nav" onload="window.print()" onafterprint="window.close()">
  <div class="wrapper">

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="container">

        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="col-md-12">

              </div>

              <div class="box-body">
                <!-- ********************************************** -->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close btn-print" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <div class="">
                      <h4 class="modal-title" id="myModalLabel">
                        <img src="/img/gcgmh.png" style="width:150px; height:55px;">
                      </h4>
                      <span class="badge badge-success btn-print pull-right" x-text="status"></span>
                    </div>

                  </div>
                  <div class="modal-body">
                    <div class="row">
                      <div class="col-xs-6">
                        <div class="row">
                          <div class="col-xs-12">
                            <label>Request To: <span>
                                <?php echo 'Central Supply Room'; ?>
                              </span></label>
                          </div>
                          <div class="col-xs-12">
                            <label>Request Date: <span>
                                <?php echo $res['request_date']; ?>
                              </span></label>
                          </div>

                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="row">
                          <div class="col-xs-12 pull-right">
                            <label class="pull-rightx">RIS NO: <span>
                                <?php echo $res['ris']; ?>
                              </span></label>
                          </div>
                          <div class="col-xs-12 pull-right">
                            <label class="pull-rightx">Issue Date: <span>
                                <?php echo $res['issue_date']; ?>
                              </span></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-xs-12" style="border-top:5px solid #f3f3f3;">
                        <center>
                          <h6 style="padding:0;margin-top:8px;">
                            <strong>REQUISITION SLIP</strong>
                          </h6>
                        </center>
                      </div>
                      <div class="col-xs-12">
                        <table class="<style>
         table {
            border: 1px solid black;
         }
      </style>">
                          <thead><p style="color:black;font-size:13px;">
                            <tr>
                              <th>Bal</th>
                              <th>SSL</th>
                              <center></center>
                              <th>Qty</th>
                              <center>
                                <th>Unit</th>
                              </center>
                              <th>Item</th>
                              <center>
                                <th>Issued</th>
                              </center>
                              <th>Remarks</th>
                            </tr></p>
                          </thead>
                          <tbody><p style="color:blue;font-size:11px;">
                            <?php foreach ($res['items'] as $item) : ?>
                              <tr>
                                <td></td>
                                <td></td>
                                <td>
                                  <center> <span><?php echo $item['qty']; ?></span> </center>
                                </td>
                                <td><?php echo $item['unit_name']; ?></td>
                                <td><?php echo $item['item']; ?></td>
                                <td>
                                  <center> <span><?php echo $item['qty_issued']; ?></span></center>
                                </td>
                                <td>
                                  <span><?php echo $item['remarks']; ?></span>
                                </td>
                              </tr>
                            <?php endforeach; ?></p>
                          </tbody>
                        </table>
                      </div>
                      
                      <div class="col-xs-12">
                        <!-- <div class="row"> -->
                        <div class="col-xs-4">
                          <label>Ward/Unit: <span><?php echo $res['request_from']; ?></span></label>
                          
                          <label>Requested By: </label><br><br>
                          <span><?php echo $res['requested_by']; ?></span>
                        </div>
                        <div class="col-xs-4">
                          <br>
                          <!-- <label>Received By: <span x-text="received_by"></span></label> -->
                          <label>Received By:</label><br><br>
                          <span><?php echo $res['received_by']; ?></span>
                        </div>
                        <div class="col-xs-4">
                          <br>
                          <label class="pull-rightx">Issued By: </label><br><br>
                          <span><?php echo $res['issued_by']; ?></span>
                        </div>
                        <!-- </div> -->
                      </div>
                    </div>
                  </div>
                  <br>
                  <div class="modal-footer"
                    style="position: fixed; bottom:0;"
                  >
                    <Center>
                      <th>
                        <font size="1">Effectivity Date:03/04/2020</pull-left>
                      </th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <th>
                        <font size="1">Rev. No: 01
                      </th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <th>
                        <font size="1">GCGMH-F-NUR-33
                      </th>
                    </center>
                  </div>
                </div>
                <!-- ********************************************** -->
              </div><!-- /.box-body -->
            </div>
            </form>
          </div><!-- /.box-body -->
          <a class="btn btn-success btn-print" href="" onclick="window.print()"><i class="glyphicon glyphicon-print"></i> Print</a>
      </div><!-- /.box -->
    </div><!-- /.col (right) -->

  </div><!-- /.row -->


  </section><!-- /.content -->
  </div><!-- /.container -->
  </div><!-- /.content-wrapper -->

  </div><!-- ./wrapper -->


  <!-- jQuery 2.1.4 -->
  <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="../dist/js/jquery.min.js"></script>
  <!-- Bootstrap 3.3.5 -->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <script src="../plugins/select2/select2.full.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/app.min.js"></script>
</body>

</html>