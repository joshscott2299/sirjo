<?php
// header('Content-Type:application/json');
include('../dist/includes/dbcon.php');

$searchKey = $_GET['ris'] ?? '';
$searchKey = htmlspecialchars(trim($searchKey));

$queryc = mysqli_query(
  $con,
  "SELECT * FROM issue_item_supply_issuance 
    WHERE ris 
    LIKE '%$searchKey%' 
    GROUP by ris 
    LIMIT 10;"
) or die(mysqli_error($con));

$temp = [];

while ($rowc = mysqli_fetch_array($queryc)) {
  $temp[] = $rowc['ris'];
}

echo json_encode($temp);