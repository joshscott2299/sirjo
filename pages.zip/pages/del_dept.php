<?php
session_start();
include("../dist/includes/dbcon.php");

$user=$_SESSION['id'];
$branch=$_SESSION['branch'];
	
		$query=mysqli_query($con,"select temp_id, branch_to from temp_dept natural join branch where branch_from='$branch'")or die(mysqli_error());
			$row=mysqli_fetch_array($query);

			///$query1=mysqli_query($con,"select temp_trans_id, prod_id from temp_trans natural join supplier natural join category where branch_id_from='$branch'")or die(mysqli_error());
			///$row1=mysqli_fetch_array($query1);
			

$result=mysqli_query($con,"DELETE FROM temp_dept WHERE e_user ='$user'")
	or die(mysqli_error());
	
	 $result=mysqli_query($con,"DELETE FROM issue_details WHERE e_user ='$user'")
	or die(mysqli_error());

	/////$result=mysqli_query($con,"DELETE FROM temp_trans WHERE branch_id_from ='$branch'")
	////or die(mysqli_error());


			

echo "<script>document.location='cust_new.php'</script>";  
?>