<?php
session_start();
$branch=$_SESSION['branch'];
$user=$_SESSION['id'];
	include('../dist/includes/dbcon.php');
	///$result=mysqli_query($con,"DELETE FROM temp_trans where branch_id_from='$branch' and e_user='$user'")	or die(mysqli_error());
	 echo "<script>document.location='home.php'</script>";  
?>